"""
Optimization Manager for AMD MI300x Hardware

This module implements comprehensive optimization strategies specifically
designed for AMD MI300x hardware, including ROCm optimizations, memory
management, and performance tuning.
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
import logging
import os
import subprocess
import psutil
from transformers import AutoModelForCausalLM

logger = logging.getLogger(__name__)


@dataclass
class OptimizationConfig:
    """Configuration for optimization manager."""
    
    # ROCm optimizations
    enable_rocm_optimizations: bool = True
    rocm_version: Optional[str] = None
    enable_miopen: bool = True
    enable_rocblas: bool = True
    
    # Memory optimizations
    enable_memory_optimization: bool = True
    memory_pool_size_gb: float = 32.0
    enable_memory_defragmentation: bool = True
    memory_growth_limit: float = 0.95
    
    # Compute optimizations
    enable_mixed_precision: bool = True
    enable_tensor_cores: bool = True
    enable_kernel_fusion: bool = True
    
    # Flash Attention optimizations
    enable_flash_attention: bool = True
    flash_attention_version: str = "2"
    attention_block_size: int = 128
    
    # Model optimizations
    enable_model_compilation: bool = True
    compilation_backend: str = "inductor"  # "inductor", "aot_autograd"
    enable_weight_quantization: bool = False
    quantization_dtype: str = "int8"
    
    # Performance monitoring
    enable_profiling: bool = False
    profile_memory: bool = True
    profile_compute: bool = True


class ROCmOptimizer:
    """ROCm-specific optimizations for AMD MI300x."""
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.rocm_available = self._check_rocm_availability()
        
        if self.rocm_available:
            self._setup_rocm_environment()
    
    def _check_rocm_availability(self) -> bool:
        """Check if ROCm is available."""
        try:
            import torch
            return torch.cuda.is_available() and "rocm" in torch.version.hip
        except:
            return False
    
    def _setup_rocm_environment(self):
        """Setup ROCm environment variables."""
        # Set optimal ROCm environment variables for MI300x
        rocm_env_vars = {
            'HSA_FORCE_FINE_GRAIN_PCIE': '1',
            'HIP_VISIBLE_DEVICES': '0',  # Use first GPU by default
            'ROCBLAS_LAYER': '1' if self.config.enable_rocblas else '0',
            'MIOPEN_ENABLE_LOGGING': '1' if self.config.enable_miopen else '0',
            'MIOPEN_LOG_LEVEL': '3',
            'HIP_LAUNCH_BLOCKING': '0',  # Async execution
            'PYTORCH_HIP_ALLOC_CONF': 'max_split_size_mb:512',
        }
        
        for var, value in rocm_env_vars.items():
            if var not in os.environ:
                os.environ[var] = value
                logger.debug(f"Set {var}={value}")
        
        logger.info("ROCm environment configured for MI300x")
    
    def optimize_model_for_rocm(self, model: AutoModelForCausalLM) -> AutoModelForCausalLM:
        """Apply ROCm-specific model optimizations."""
        if not self.rocm_available:
            logger.warning("ROCm not available, skipping ROCm optimizations")
            return model
        
        # Enable ROCm-specific optimizations
        if hasattr(torch.backends, 'cudnn'):
            torch.backends.cudnn.benchmark = True
            torch.backends.cudnn.deterministic = False
        
        # Set memory format for optimal performance
        if hasattr(model, 'to'):
            model = model.to(memory_format=torch.channels_last)
        
        logger.info("Applied ROCm optimizations to model")
        return model
    
    def get_rocm_info(self) -> Dict[str, Any]:
        """Get ROCm system information."""
        info = {
            'rocm_available': self.rocm_available,
            'hip_version': None,
            'rocm_version': None,
            'device_count': 0,
            'device_names': []
        }
        
        if self.rocm_available:
            try:
                info['hip_version'] = torch.version.hip
                info['device_count'] = torch.cuda.device_count()
                
                for i in range(info['device_count']):
                    device_name = torch.cuda.get_device_name(i)
                    info['device_names'].append(device_name)
                
                # Try to get ROCm version
                try:
                    result = subprocess.run(['rocm-smi', '--version'], 
                                          capture_output=True, text=True)
                    if result.returncode == 0:
                        info['rocm_version'] = result.stdout.strip()
                except:
                    pass
                
            except Exception as e:
                logger.warning(f"Error getting ROCm info: {e}")
        
        return info


class MemoryOptimizer:
    """Memory optimization for AMD MI300x's 192GB HBM3."""
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.memory_pool_initialized = False
        
        # Memory statistics
        self.peak_memory_usage = 0.0
        self.memory_allocations = 0
        self.memory_deallocations = 0
    
    def initialize_memory_pool(self):
        """Initialize optimized memory pool."""
        if self.memory_pool_initialized:
            return
        
        try:
            # Set memory pool size (in bytes)
            pool_size = int(self.config.memory_pool_size_gb * 1024**3)
            
            # Configure PyTorch memory allocator
            if torch.cuda.is_available():
                # Set memory fraction
                torch.cuda.set_per_process_memory_fraction(self.config.memory_growth_limit)
                
                # Enable memory pool
                os.environ['PYTORCH_CUDA_ALLOC_CONF'] = f'max_split_size_mb:512,roundup_power2_divisions:16'
                
                logger.info(f"Initialized memory pool: {self.config.memory_pool_size_gb}GB")
                self.memory_pool_initialized = True
                
        except Exception as e:
            logger.error(f"Failed to initialize memory pool: {e}")
    
    def optimize_memory_layout(self, model: AutoModelForCausalLM) -> AutoModelForCausalLM:
        """Optimize model memory layout."""
        # Convert to channels_last for better memory access patterns
        try:
            for module in model.modules():
                if isinstance(module, (nn.Conv1d, nn.Conv2d, nn.Linear)):
                    if hasattr(module.weight, 'data'):
                        # Ensure contiguous memory layout
                        module.weight.data = module.weight.data.contiguous()
                        
                        if module.bias is not None:
                            module.bias.data = module.bias.data.contiguous()
            
            logger.info("Optimized model memory layout")
            
        except Exception as e:
            logger.warning(f"Memory layout optimization failed: {e}")
        
        return model
    
    def enable_memory_defragmentation(self):
        """Enable automatic memory defragmentation."""
        if not self.config.enable_memory_defragmentation:
            return
        
        try:
            # Clear cache periodically
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
                
                # Force garbage collection
                import gc
                gc.collect()
                
            logger.debug("Memory defragmentation completed")
            
        except Exception as e:
            logger.warning(f"Memory defragmentation failed: {e}")
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """Get comprehensive memory statistics."""
        stats = {
            'pool_initialized': self.memory_pool_initialized,
            'peak_memory_usage_gb': self.peak_memory_usage / 1024**3,
            'memory_allocations': self.memory_allocations,
            'memory_deallocations': self.memory_deallocations
        }
        
        if torch.cuda.is_available():
            stats.update({
                'allocated_gb': torch.cuda.memory_allocated() / 1024**3,
                'reserved_gb': torch.cuda.memory_reserved() / 1024**3,
                'max_allocated_gb': torch.cuda.max_memory_allocated() / 1024**3,
                'max_reserved_gb': torch.cuda.max_memory_reserved() / 1024**3
            })
        
        # System memory
        memory_info = psutil.virtual_memory()
        stats.update({
            'system_memory_total_gb': memory_info.total / 1024**3,
            'system_memory_available_gb': memory_info.available / 1024**3,
            'system_memory_percent': memory_info.percent
        })
        
        return stats
    
    def monitor_memory_usage(self):
        """Monitor and log memory usage."""
        if torch.cuda.is_available():
            current_memory = torch.cuda.memory_allocated()
            self.peak_memory_usage = max(self.peak_memory_usage, current_memory)
            
            # Log warning if memory usage is high
            memory_fraction = current_memory / torch.cuda.get_device_properties(0).total_memory
            if memory_fraction > 0.9:
                logger.warning(f"High memory usage: {memory_fraction:.1%}")


class ComputeOptimizer:
    """Compute optimizations for AMD MI300x."""
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
    
    def enable_mixed_precision(self, model: AutoModelForCausalLM) -> AutoModelForCausalLM:
        """Enable mixed precision training/inference."""
        if not self.config.enable_mixed_precision:
            return model
        
        try:
            # Convert model to half precision where appropriate
            for module in model.modules():
                if isinstance(module, (nn.Linear, nn.Conv1d, nn.Conv2d)):
                    # Keep certain layers in full precision for stability
                    if not any(name in str(module) for name in ['norm', 'embedding']):
                        module.half()
            
            logger.info("Enabled mixed precision")
            
        except Exception as e:
            logger.warning(f"Mixed precision setup failed: {e}")
        
        return model
    
    def enable_kernel_fusion(self):
        """Enable kernel fusion optimizations."""
        if not self.config.enable_kernel_fusion:
            return
        
        try:
            # Enable JIT fusion
            torch.jit.set_fusion_strategy([('STATIC', 20), ('DYNAMIC', 20)])
            
            # Enable autograd profiler optimizations
            torch.autograd.profiler.profile(enabled=False)
            torch.autograd.set_detect_anomaly(False)
            
            logger.info("Enabled kernel fusion optimizations")
            
        except Exception as e:
            logger.warning(f"Kernel fusion setup failed: {e}")
    
    def optimize_attention(self, model: AutoModelForCausalLM) -> AutoModelForCausalLM:
        """Optimize attention mechanisms."""
        if not self.config.enable_flash_attention:
            return model
        
        try:
            # Replace attention with Flash Attention if available
            for module in model.modules():
                if hasattr(module, 'attention') or 'attention' in str(type(module)).lower():
                    # This would require Flash Attention implementation
                    # For now, just ensure efficient attention settings
                    if hasattr(module, 'scale_attn_weights'):
                        module.scale_attn_weights = True
            
            logger.info("Optimized attention mechanisms")
            
        except Exception as e:
            logger.warning(f"Attention optimization failed: {e}")
        
        return model


class ModelCompiler:
    """Model compilation optimizations."""
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
    
    def compile_model(self, model: AutoModelForCausalLM) -> AutoModelForCausalLM:
        """Compile model for optimal performance."""
        if not self.config.enable_model_compilation:
            return model
        
        try:
            if hasattr(torch, 'compile'):
                # Use PyTorch 2.0 compilation
                compiled_model = torch.compile(
                    model,
                    backend=self.config.compilation_backend,
                    mode="max-autotune"  # Optimize for performance
                )
                
                logger.info(f"Compiled model with {self.config.compilation_backend} backend")
                return compiled_model
            else:
                logger.warning("torch.compile not available, skipping compilation")
                
        except Exception as e:
            logger.warning(f"Model compilation failed: {e}")
        
        return model
    
    def apply_quantization(self, model: AutoModelForCausalLM) -> AutoModelForCausalLM:
        """Apply weight quantization."""
        if not self.config.enable_weight_quantization:
            return model
        
        try:
            # Apply dynamic quantization
            if self.config.quantization_dtype == "int8":
                quantized_model = torch.quantization.quantize_dynamic(
                    model,
                    {nn.Linear},
                    dtype=torch.qint8
                )
                
                logger.info("Applied INT8 quantization")
                return quantized_model
            
        except Exception as e:
            logger.warning(f"Quantization failed: {e}")
        
        return model


class PerformanceProfiler:
    """Performance profiling and monitoring."""
    
    def __init__(self, config: OptimizationConfig):
        self.config = config
        self.profiling_enabled = config.enable_profiling
        
        # Profiling data
        self.compute_times = []
        self.memory_snapshots = []
        self.kernel_times = []
    
    def start_profiling(self):
        """Start performance profiling."""
        if not self.profiling_enabled:
            return
        
        try:
            # Start PyTorch profiler
            self.profiler = torch.profiler.profile(
                activities=[
                    torch.profiler.ProfilerActivity.CPU,
                    torch.profiler.ProfilerActivity.CUDA,
                ],
                record_shapes=True,
                profile_memory=self.config.profile_memory,
                with_stack=True
            )
            
            self.profiler.start()
            logger.info("Started performance profiling")
            
        except Exception as e:
            logger.warning(f"Failed to start profiling: {e}")
    
    def stop_profiling(self) -> Optional[str]:
        """Stop profiling and return trace file path."""
        if not self.profiling_enabled or not hasattr(self, 'profiler'):
            return None
        
        try:
            self.profiler.stop()
            
            # Export trace
            trace_path = "amd_mi300x_trace.json"
            self.profiler.export_chrome_trace(trace_path)
            
            logger.info(f"Profiling trace saved to {trace_path}")
            return trace_path
            
        except Exception as e:
            logger.warning(f"Failed to stop profiling: {e}")
            return None
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance summary."""
        summary = {
            'profiling_enabled': self.profiling_enabled,
            'compute_samples': len(self.compute_times),
            'memory_samples': len(self.memory_snapshots)
        }
        
        if self.compute_times:
            summary.update({
                'avg_compute_time_ms': np.mean(self.compute_times),
                'max_compute_time_ms': np.max(self.compute_times),
                'min_compute_time_ms': np.min(self.compute_times)
            })
        
        return summary


class OptimizationManager:
    """
    Main optimization manager that orchestrates all optimizations.
    
    Provides comprehensive optimization strategies specifically designed
    for AMD MI300x hardware, including ROCm, memory, compute, and model
    optimizations.
    """
    
    def __init__(self, config: OptimizationConfig):
        """
        Initialize optimization manager.
        
        Args:
            config: Optimization configuration
        """
        self.config = config
        
        # Initialize optimizers
        self.rocm_optimizer = ROCmOptimizer(config)
        self.memory_optimizer = MemoryOptimizer(config)
        self.compute_optimizer = ComputeOptimizer(config)
        self.model_compiler = ModelCompiler(config)
        self.profiler = PerformanceProfiler(config)
        
        # Optimization state
        self.optimizations_applied = False
        
        logger.info("Optimization Manager initialized for AMD MI300x")
    
    def apply_optimizations(self, model: AutoModelForCausalLM) -> AutoModelForCausalLM:
        """
        Apply all optimizations to the model.
        
        Args:
            model: Model to optimize
            
        Returns:
            Optimized model
        """
        logger.info("Applying AMD MI300x optimizations...")
        
        # Initialize memory pool
        self.memory_optimizer.initialize_memory_pool()
        
        # Apply ROCm optimizations
        if self.config.enable_rocm_optimizations:
            model = self.rocm_optimizer.optimize_model_for_rocm(model)
        
        # Apply memory optimizations
        if self.config.enable_memory_optimization:
            model = self.memory_optimizer.optimize_memory_layout(model)
        
        # Apply compute optimizations
        if self.config.enable_mixed_precision:
            model = self.compute_optimizer.enable_mixed_precision(model)
        
        if self.config.enable_kernel_fusion:
            self.compute_optimizer.enable_kernel_fusion()
        
        # Optimize attention
        model = self.compute_optimizer.optimize_attention(model)
        
        # Apply model compilation
        if self.config.enable_model_compilation:
            model = self.model_compiler.compile_model(model)
        
        # Apply quantization
        if self.config.enable_weight_quantization:
            model = self.model_compiler.apply_quantization(model)
        
        self.optimizations_applied = True
        logger.info("AMD MI300x optimizations applied successfully")
        
        return model
    
    def start_monitoring(self):
        """Start performance monitoring."""
        if self.config.enable_profiling:
            self.profiler.start_profiling()
        
        logger.info("Performance monitoring started")
    
    def stop_monitoring(self) -> Optional[str]:
        """Stop performance monitoring and return trace file."""
        trace_path = None
        
        if self.config.enable_profiling:
            trace_path = self.profiler.stop_profiling()
        
        logger.info("Performance monitoring stopped")
        return trace_path
    
    def optimize_for_inference(self):
        """Apply inference-specific optimizations."""
        # Enable memory defragmentation
        self.memory_optimizer.enable_memory_defragmentation()
        
        # Set inference mode
        torch.set_grad_enabled(False)
        
        # Optimize for inference
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        logger.info("Inference optimizations applied")
    
    def get_system_info(self) -> Dict[str, Any]:
        """Get comprehensive system information."""
        info = {
            'optimizations_applied': self.optimizations_applied,
            'rocm_info': self.rocm_optimizer.get_rocm_info(),
            'memory_stats': self.memory_optimizer.get_memory_stats(),
            'performance_summary': self.profiler.get_performance_summary()
        }
        
        # Add hardware info
        if torch.cuda.is_available():
            device_props = torch.cuda.get_device_properties(0)
            info['hardware_info'] = {
                'device_name': device_props.name,
                'total_memory_gb': device_props.total_memory / 1024**3,
                'multiprocessor_count': device_props.multi_processor_count,
                'major': device_props.major,
                'minor': device_props.minor
            }
        
        return info
    
    def benchmark_performance(self, model: AutoModelForCausalLM, 
                            input_shape: Tuple[int, int] = (1, 512)) -> Dict[str, float]:
        """
        Benchmark model performance.
        
        Args:
            model: Model to benchmark
            input_shape: Input tensor shape (batch_size, sequence_length)
            
        Returns:
            Performance metrics
        """
        logger.info("Starting performance benchmark...")
        
        # Create dummy input
        dummy_input = torch.randint(0, 1000, input_shape).to(model.device)
        
        # Warmup
        with torch.no_grad():
            for _ in range(5):
                _ = model(dummy_input)
        
        # Benchmark
        torch.cuda.synchronize()
        start_time = time.time()
        
        num_iterations = 10
        with torch.no_grad():
            for _ in range(num_iterations):
                _ = model(dummy_input)
        
        torch.cuda.synchronize()
        end_time = time.time()
        
        # Calculate metrics
        total_time = end_time - start_time
        avg_time_per_iteration = total_time / num_iterations
        throughput = input_shape[0] / avg_time_per_iteration  # samples per second
        
        metrics = {
            'avg_inference_time_ms': avg_time_per_iteration * 1000,
            'throughput_samples_per_sec': throughput,
            'total_benchmark_time_s': total_time,
            'memory_usage_gb': torch.cuda.memory_allocated() / 1024**3 if torch.cuda.is_available() else 0
        }
        
        logger.info(f"Benchmark completed: {avg_time_per_iteration*1000:.2f}ms per iteration")
        return metrics
    
    def cleanup(self):
        """Clean up optimization resources."""
        # Stop monitoring
        self.stop_monitoring()
        
        # Clear memory
        self.memory_optimizer.enable_memory_defragmentation()
        
        # Reset optimizations
        self.optimizations_applied = False
        
        logger.info("Optimization manager cleanup completed")


def create_optimization_manager(config_overrides: Optional[Dict[str, Any]] = None) -> OptimizationManager:
    """
    Create an optimization manager with optional configuration overrides.
    
    Args:
        config_overrides: Optional configuration overrides
        
    Returns:
        Configured OptimizationManager
    """
    config = OptimizationConfig()
    
    if config_overrides:
        for key, value in config_overrides.items():
            if hasattr(config, key):
                setattr(config, key, value)
    
    return OptimizationManager(config)

