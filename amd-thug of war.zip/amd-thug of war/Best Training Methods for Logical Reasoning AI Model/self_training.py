"""
Self-Training with Iterative Improvement

This module implements advanced self-training strategies that iteratively
improve the model using its own generated data, with quality filtering
and ensemble-based validation.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
import logging
import json
from pathlib import Path
import random
from transformers import AutoModelForCausalLM, AutoTokenizer
from torch.utils.data import Dataset

from .training_config import SelfTrainingConfig
from .grpo_trainer import GRPOTrainer, create_grpo_dataset
from .dpo_trainer import DPOTrainer, create_dpo_dataset
from .training_utils import TrainingMetrics, ModelEvaluator, MetricsLogger
from .optimization_utils import AMDOptimizer, MemoryOptimizer
from ..data_generation.base_generator import GeneratedProblem, DifficultyLevel

logger = logging.getLogger(__name__)


@dataclass
class SelfTrainingIteration:
    """Represents a self-training iteration."""
    iteration_id: int
    generated_problems: List[Dict[str, Any]]
    filtered_problems: List[Dict[str, Any]]
    training_metrics: Dict[str, float]
    evaluation_metrics: Dict[str, float]
    model_checkpoint_path: str
    quality_scores: List[float]
    confidence_scores: List[float]


class QualityFilter:
    """Filter generated problems based on quality metrics."""
    
    def __init__(self, config: SelfTrainingConfig):
        self.config = config
        self.quality_threshold = config.quality_threshold
        self.confidence_threshold = config.confidence_threshold
        
    def filter_problems(self, 
                       problems: List[Dict[str, Any]],
                       model: AutoModelForCausalLM,
                       tokenizer: AutoTokenizer) -> Tuple[List[Dict[str, Any]], List[float], List[float]]:
        """
        Filter problems based on quality and confidence metrics.
        
        Args:
            problems: List of generated problems
            model: Model for confidence estimation
            tokenizer: Tokenizer
            
        Returns:
            Tuple of (filtered_problems, quality_scores, confidence_scores)
        """
        filtered_problems = []
        quality_scores = []
        confidence_scores = []
        
        for problem in problems:
            # Compute quality score
            quality_score = self._compute_quality_score(problem)
            
            # Compute confidence score
            confidence_score = self._compute_confidence_score(problem, model, tokenizer)
            
            # Apply filtering criteria
            if (quality_score >= self.quality_threshold and 
                confidence_score >= self.confidence_threshold):
                filtered_problems.append(problem)
            
            quality_scores.append(quality_score)
            confidence_scores.append(confidence_score)
        
        logger.info(f"Filtered {len(filtered_problems)}/{len(problems)} problems")
        logger.info(f"Average quality score: {np.mean(quality_scores):.3f}")
        logger.info(f"Average confidence score: {np.mean(confidence_scores):.3f}")
        
        return filtered_problems, quality_scores, confidence_scores
    
    def _compute_quality_score(self, problem: Dict[str, Any]) -> float:
        """Compute quality score for a problem."""
        score = 0.0
        
        # Check for required fields
        required_fields = ['question', 'answer', 'reasoning']
        for field in required_fields:
            if field in problem and problem[field]:
                score += 0.2
        
        # Check question length (not too short or too long)
        question_length = len(problem.get('question', '').split())
        if 10 <= question_length <= 200:
            score += 0.2
        
        # Check answer length
        answer_length = len(problem.get('answer', '').split())
        if 1 <= answer_length <= 50:
            score += 0.2
        
        # Check for logical structure indicators
        question = problem.get('question', '').lower()
        logical_indicators = ['if', 'then', 'because', 'therefore', 'since', 'given', 'suppose']
        if any(indicator in question for indicator in logical_indicators):
            score += 0.1
        
        # Check for reasoning quality
        reasoning = problem.get('reasoning', '').lower()
        reasoning_indicators = ['step', 'first', 'second', 'next', 'finally', 'conclude']
        if any(indicator in reasoning for indicator in reasoning_indicators):
            score += 0.1
        
        return min(score, 1.0)
    
    def _compute_confidence_score(self, 
                                 problem: Dict[str, Any],
                                 model: AutoModelForCausalLM,
                                 tokenizer: AutoTokenizer) -> float:
        """Compute model confidence score for a problem."""
        question = problem.get('question', '')
        answer = problem.get('answer', '')
        
        if not question or not answer:
            return 0.0
        
        # Prepare input
        prompt = f"{question}\n\nAnswer:"
        inputs = tokenizer(prompt, return_tensors="pt").to(model.device)
        
        # Get model prediction
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=100,
                temperature=0.1,
                do_sample=False,
                return_dict_in_generate=True,
                output_scores=True
            )
        
        # Compute confidence based on token probabilities
        if hasattr(outputs, 'scores') and outputs.scores:
            # Average probability of generated tokens
            token_probs = []
            for score in outputs.scores:
                probs = F.softmax(score, dim=-1)
                max_prob = torch.max(probs, dim=-1)[0]
                token_probs.append(max_prob.item())
            
            confidence = np.mean(token_probs) if token_probs else 0.0
        else:
            confidence = 0.5  # Default confidence
        
        return confidence


class EnsembleFilter:
    """Use ensemble of models for quality filtering."""
    
    def __init__(self, 
                 models: List[AutoModelForCausalLM],
                 tokenizer: AutoTokenizer,
                 config: SelfTrainingConfig):
        self.models = models
        self.tokenizer = tokenizer
        self.config = config
    
    def filter_with_ensemble(self, problems: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Filter problems using ensemble agreement."""
        filtered_problems = []
        
        for problem in problems:
            question = problem.get('question', '')
            correct_answer = problem.get('answer', '')
            
            if not question or not correct_answer:
                continue
            
            # Get predictions from all models
            predictions = []
            for model in self.models:
                prediction = self._get_model_prediction(question, model)
                predictions.append(prediction)
            
            # Check ensemble agreement
            agreement_score = self._compute_agreement_score(predictions, correct_answer)
            
            if agreement_score >= self.config.confidence_threshold:
                filtered_problems.append(problem)
        
        logger.info(f"Ensemble filtered {len(filtered_problems)}/{len(problems)} problems")
        return filtered_problems
    
    def _get_model_prediction(self, question: str, model: AutoModelForCausalLM) -> str:
        """Get prediction from a single model."""
        prompt = f"{question}\n\nAnswer:"
        inputs = self.tokenizer(prompt, return_tensors="pt").to(model.device)
        
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=50,
                temperature=0.1,
                do_sample=False
            )
        
        response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract answer
        if "Answer:" in response:
            answer = response.split("Answer:")[-1].strip()
        else:
            answer = response.strip()
        
        return answer
    
    def _compute_agreement_score(self, predictions: List[str], correct_answer: str) -> float:
        """Compute agreement score between predictions and correct answer."""
        # Normalize answers
        normalized_predictions = [self._normalize_answer(pred) for pred in predictions]
        normalized_correct = self._normalize_answer(correct_answer)
        
        # Count agreements
        agreements = sum(1 for pred in normalized_predictions if pred == normalized_correct)
        
        return agreements / len(predictions)
    
    def _normalize_answer(self, answer: str) -> str:
        """Normalize answer for comparison."""
        normalized = answer.strip().lower()
        
        # Remove common prefixes
        prefixes = ["the answer is", "answer:", "the correct answer is"]
        for prefix in prefixes:
            if normalized.startswith(prefix):
                normalized = normalized[len(prefix):].strip()
        
        # Extract choice letter if present
        if len(normalized) >= 1 and normalized[0] in 'abcd':
            return normalized[0]
        
        return normalized


class DataAugmenter:
    """Augment training data with variations."""
    
    def __init__(self, config: SelfTrainingConfig):
        self.config = config
        self.augmentation_methods = config.augmentation_methods
    
    def augment_problems(self, problems: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Augment problems with variations."""
        augmented_problems = problems.copy()
        
        if not self.config.enable_augmentation:
            return augmented_problems
        
        num_augmentations = int(len(problems) * self.config.augmentation_ratio)
        
        for _ in range(num_augmentations):
            # Select random problem to augment
            base_problem = random.choice(problems)
            
            # Apply random augmentation method
            method = random.choice(self.augmentation_methods)
            
            if method == "paraphrase":
                augmented_problem = self._paraphrase_problem(base_problem)
            elif method == "difficulty_adjust":
                augmented_problem = self._adjust_difficulty(base_problem)
            else:
                continue
            
            if augmented_problem:
                augmented_problems.append(augmented_problem)
        
        logger.info(f"Augmented dataset from {len(problems)} to {len(augmented_problems)} problems")
        return augmented_problems
    
    def _paraphrase_problem(self, problem: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Create a paraphrased version of the problem."""
        # Simple paraphrasing by modifying question structure
        question = problem.get('question', '')
        
        # Basic paraphrasing patterns
        paraphrase_patterns = [
            ("What is", "Determine"),
            ("Find", "Calculate"),
            ("Which", "What"),
            ("How many", "What is the number of"),
            ("Can you", "Please"),
        ]
        
        paraphrased_question = question
        for original, replacement in paraphrase_patterns:
            if original in question:
                paraphrased_question = question.replace(original, replacement, 1)
                break
        
        if paraphrased_question != question:
            augmented_problem = problem.copy()
            augmented_problem['question'] = paraphrased_question
            augmented_problem['augmented'] = True
            augmented_problem['augmentation_method'] = 'paraphrase'
            return augmented_problem
        
        return None
    
    def _adjust_difficulty(self, problem: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Adjust problem difficulty."""
        # This is a simplified version - in practice, would use more sophisticated methods
        question = problem.get('question', '')
        
        # Add complexity by introducing additional constraints
        complexity_additions = [
            "Additionally, consider that",
            "Furthermore,",
            "Also note that",
            "Given the constraint that"
        ]
        
        if len(question.split()) < 50:  # Only add complexity to shorter questions
            addition = random.choice(complexity_additions)
            # This is a placeholder - would need domain-specific logic
            modified_question = f"{question} {addition} all conditions must be satisfied."
            
            augmented_problem = problem.copy()
            augmented_problem['question'] = modified_question
            augmented_problem['augmented'] = True
            augmented_problem['augmentation_method'] = 'difficulty_adjust'
            return augmented_problem
        
        return None


class SelfTrainer:
    """
    Self-Training system with iterative improvement.
    
    Implements iterative self-training where the model generates its own
    training data, which is then filtered and used for further training.
    """
    
    def __init__(self,
                 config: SelfTrainingConfig,
                 model: Optional[AutoModelForCausalLM] = None,
                 tokenizer: Optional[AutoTokenizer] = None,
                 base_trainer: Optional[Union[GRPOTrainer, DPOTrainer]] = None):
        """
        Initialize self-trainer.
        
        Args:
            config: Self-training configuration
            model: Pre-trained model (will be loaded if None)
            tokenizer: Tokenizer (will be loaded if None)
            base_trainer: Base trainer for training iterations
        """
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Initialize model and tokenizer
        self.model = model or self._load_model()
        self.tokenizer = tokenizer or self._load_tokenizer()
        
        # Initialize base trainer
        self.base_trainer = base_trainer or self._create_base_trainer()
        
        # Initialize components
        self.quality_filter = QualityFilter(config)
        self.data_augmenter = DataAugmenter(config)
        
        # Initialize ensemble if configured
        self.ensemble_filter = None
        if config.use_ensemble_filtering:
            self.ensemble_filter = self._create_ensemble_filter()
        
        # Initialize metrics and logging
        self.metrics = TrainingMetrics()
        self.evaluator = ModelEvaluator(self.model, self.tokenizer)
        self.metrics_logger = MetricsLogger(
            log_to_wandb=getattr(config, 'enable_wandb', False),
            log_file=f"{config.output_dir}/self_training_metrics.json"
        )
        
        # Training state
        self.iteration_history = []
        self.global_step = 0
        
        logger.info("Self-Trainer initialized")
    
    def _load_model(self) -> AutoModelForCausalLM:
        """Load the pre-trained model."""
        model = AutoModelForCausalLM.from_pretrained(
            self.config.model_name,
            revision=self.config.model_revision,
            torch_dtype=getattr(torch, self.config.torch_dtype),
            attn_implementation=self.config.attn_implementation,
            device_map="auto",
            low_cpu_mem_usage=True,
            use_cache=False
        )
        
        if self.config.gradient_checkpointing:
            model.gradient_checkpointing_enable()
        
        return model
    
    def _load_tokenizer(self) -> AutoTokenizer:
        """Load the tokenizer."""
        tokenizer = AutoTokenizer.from_pretrained(
            self.config.model_name,
            revision=self.config.model_revision
        )
        
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        return tokenizer
    
    def _create_base_trainer(self):
        """Create base trainer for self-training iterations."""
        from .training_config import GRPOConfig
        
        grpo_config = GRPOConfig(
            model_name=self.config.model_name,
            learning_rate=self.config.learning_rate,
            num_train_epochs=1,  # Single epoch per iteration
            per_device_train_batch_size=self.config.per_device_train_batch_size,
            gradient_accumulation_steps=self.config.gradient_accumulation_steps,
            max_length=self.config.max_length,
            output_dir=self.config.output_dir,
            eval_steps=self.config.eval_steps,
            save_steps=self.config.save_steps,
            logging_steps=self.config.logging_steps
        )
        
        return GRPOTrainer(
            config=grpo_config,
            model=self.model,
            tokenizer=self.tokenizer
        )
    
    def _create_ensemble_filter(self) -> Optional[EnsembleFilter]:
        """Create ensemble filter with multiple model instances."""
        if not self.config.use_ensemble_filtering:
            return None
        
        # Create multiple model instances for ensemble
        ensemble_models = []
        for i in range(self.config.ensemble_size):
            # For simplicity, using the same model with different random seeds
            # In practice, could use different model checkpoints or architectures
            model_copy = AutoModelForCausalLM.from_pretrained(
                self.config.model_name,
                revision=self.config.model_revision,
                torch_dtype=getattr(torch, self.config.torch_dtype),
                device_map="auto"
            )
            ensemble_models.append(model_copy)
        
        return EnsembleFilter(ensemble_models, self.tokenizer, self.config)
    
    def train_iteratively(self, 
                         initial_data: List[Dict[str, Any]],
                         holdout_data: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """
        Perform iterative self-training.
        
        Args:
            initial_data: Initial training data
            holdout_data: Holdout data for evaluation
            
        Returns:
            Self-training results
        """
        logger.info(f"Starting iterative self-training for {self.config.num_iterations} iterations")
        
        # Prepare holdout data if provided
        if holdout_data and self.config.eval_on_holdout:
            holdout_ratio = self.config.holdout_ratio
            if len(initial_data) > 100:
                split_idx = int(len(initial_data) * (1 - holdout_ratio))
                training_data = initial_data[:split_idx]
                holdout_data = initial_data[split_idx:]
            else:
                training_data = initial_data
        else:
            training_data = initial_data
        
        current_data = training_data.copy()
        
        # Perform iterative training
        for iteration in range(self.config.num_iterations):
            logger.info(f"Starting self-training iteration {iteration + 1}/{self.config.num_iterations}")
            
            iteration_result = self._perform_iteration(
                iteration_id=iteration,
                current_data=current_data,
                holdout_data=holdout_data
            )
            
            self.iteration_history.append(iteration_result)
            
            # Update current data with filtered generated data
            if iteration_result['filtered_problems']:
                # Mix original and generated data
                synthetic_weight = self.config.synthetic_data_weight
                num_synthetic = int(len(current_data) * synthetic_weight)
                
                if len(iteration_result['filtered_problems']) >= num_synthetic:
                    selected_synthetic = random.sample(iteration_result['filtered_problems'], num_synthetic)
                else:
                    selected_synthetic = iteration_result['filtered_problems']
                
                current_data = current_data + selected_synthetic
                
                logger.info(f"Updated training data: {len(current_data)} problems (including {len(selected_synthetic)} synthetic)")
        
        # Final evaluation
        final_results = self._compute_final_results(holdout_data)
        
        return {
            'iteration_history': self.iteration_history,
            'final_results': final_results,
            'total_iterations': len(self.iteration_history)
        }
    
    def _perform_iteration(self, 
                          iteration_id: int,
                          current_data: List[Dict[str, Any]],
                          holdout_data: Optional[List[Dict[str, Any]]]) -> SelfTrainingIteration:
        """Perform a single self-training iteration."""
        logger.info(f"Iteration {iteration_id}: Training on {len(current_data)} problems")
        
        # Step 1: Train on current data
        train_dataset = create_grpo_dataset(current_data, self.tokenizer, self.base_trainer.config)
        training_result = self.base_trainer.train(train_dataset=train_dataset, num_epochs=1)
        
        # Step 2: Generate new problems
        generated_problems = self._generate_problems(self.config.problems_per_iteration)
        
        # Step 3: Filter generated problems
        filtered_problems, quality_scores, confidence_scores = self.quality_filter.filter_problems(
            generated_problems, self.model, self.tokenizer
        )
        
        # Step 4: Apply ensemble filtering if configured
        if self.ensemble_filter and filtered_problems:
            filtered_problems = self.ensemble_filter.filter_with_ensemble(filtered_problems)
        
        # Step 5: Augment data if configured
        if self.config.enable_augmentation and filtered_problems:
            filtered_problems = self.data_augmenter.augment_problems(filtered_problems)
        
        # Step 6: Evaluate on holdout data
        evaluation_metrics = {}
        if holdout_data:
            evaluation_metrics = self._evaluate_on_holdout(holdout_data)
        
        # Step 7: Save iteration checkpoint
        checkpoint_path = f"{self.config.output_dir}/iteration_{iteration_id}_checkpoint"
        self.base_trainer.save_checkpoint(checkpoint_path)
        
        # Create iteration result
        iteration_result = SelfTrainingIteration(
            iteration_id=iteration_id,
            generated_problems=generated_problems,
            filtered_problems=filtered_problems,
            training_metrics=training_result.get('final_metrics', {}),
            evaluation_metrics=evaluation_metrics,
            model_checkpoint_path=checkpoint_path,
            quality_scores=quality_scores,
            confidence_scores=confidence_scores
        )
        
        # Log iteration metrics
        self.metrics_logger.log_metrics(
            {
                'iteration': iteration_id,
                'generated_problems': len(generated_problems),
                'filtered_problems': len(filtered_problems),
                'avg_quality_score': np.mean(quality_scores) if quality_scores else 0.0,
                'avg_confidence_score': np.mean(confidence_scores) if confidence_scores else 0.0,
                **evaluation_metrics
            },
            step=self.global_step,
            prefix='self_training'
        )
        
        self.global_step += 1
        
        logger.info(f"Iteration {iteration_id} completed: {len(filtered_problems)}/{len(generated_problems)} problems retained")
        
        return iteration_result
    
    def _generate_problems(self, num_problems: int) -> List[Dict[str, Any]]:
        """Generate new problems using the current model."""
        generated_problems = []
        
        # Problem generation prompts
        generation_prompts = [
            "Generate a logical reasoning problem involving truth-tellers and liars:",
            "Create a seating arrangement puzzle with the following constraints:",
            "Design a blood relations problem with multiple family members:",
            "Formulate a logical puzzle that requires step-by-step reasoning:"
        ]
        
        problems_per_prompt = num_problems // len(generation_prompts)
        
        for prompt in generation_prompts:
            for _ in range(problems_per_prompt):
                try:
                    problem = self._generate_single_problem(prompt)
                    if problem:
                        generated_problems.append(problem)
                except Exception as e:
                    logger.warning(f"Failed to generate problem: {e}")
                    continue
        
        logger.info(f"Generated {len(generated_problems)} problems")
        return generated_problems
    
    def _generate_single_problem(self, prompt: str) -> Optional[Dict[str, Any]]:
        """Generate a single problem using the model."""
        # Prepare generation input
        full_prompt = f"{prompt}\n\nProblem:\nQuestion:"
        inputs = self.tokenizer(full_prompt, return_tensors="pt").to(self.device)
        
        # Generate problem
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=self.config.generation_max_length,
                temperature=self.config.generation_temperature,
                top_p=self.config.generation_top_p,
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id
            )
        
        # Decode generated text
        generated_text = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract problem components
        problem = self._parse_generated_problem(generated_text)
        
        return problem
    
    def _parse_generated_problem(self, generated_text: str) -> Optional[Dict[str, Any]]:
        """Parse generated text into problem components."""
        try:
            # Simple parsing - in practice would use more sophisticated methods
            lines = generated_text.split('\n')
            
            question = ""
            answer = ""
            reasoning = ""
            
            current_section = None
            
            for line in lines:
                line = line.strip()
                
                if line.lower().startswith('question:'):
                    current_section = 'question'
                    question = line[9:].strip()
                elif line.lower().startswith('answer:'):
                    current_section = 'answer'
                    answer = line[7:].strip()
                elif line.lower().startswith('reasoning:') or line.lower().startswith('explanation:'):
                    current_section = 'reasoning'
                    reasoning = line.split(':', 1)[1].strip()
                elif current_section == 'question' and line:
                    question += " " + line
                elif current_section == 'answer' and line:
                    answer += " " + line
                elif current_section == 'reasoning' and line:
                    reasoning += " " + line
            
            if question and answer:
                return {
                    'question': question.strip(),
                    'answer': answer.strip(),
                    'reasoning': reasoning.strip(),
                    'generated': True,
                    'generation_method': 'self_training'
                }
        
        except Exception as e:
            logger.warning(f"Failed to parse generated problem: {e}")
        
        return None
    
    def _evaluate_on_holdout(self, holdout_data: List[Dict[str, Any]]) -> Dict[str, float]:
        """Evaluate current model on holdout data."""
        questions = [item['question'] for item in holdout_data]
        correct_answers = [item['answer'] for item in holdout_data]
        
        performance = self.evaluator.evaluate_reasoning_accuracy(
            questions=questions,
            correct_answers=correct_answers
        )
        
        return {
            'holdout_accuracy': performance['exact_accuracy'],
            'holdout_partial_accuracy': performance['partial_accuracy']
        }
    
    def _compute_final_results(self, holdout_data: Optional[List[Dict[str, Any]]]) -> Dict[str, Any]:
        """Compute final self-training results."""
        results = {
            'total_iterations': len(self.iteration_history),
            'total_generated_problems': sum(len(it.generated_problems) for it in self.iteration_history),
            'total_filtered_problems': sum(len(it.filtered_problems) for it in self.iteration_history),
            'average_quality_score': 0.0,
            'average_confidence_score': 0.0,
            'performance_progression': []
        }
        
        # Compute averages
        all_quality_scores = []
        all_confidence_scores = []
        
        for iteration in self.iteration_history:
            all_quality_scores.extend(iteration.quality_scores)
            all_confidence_scores.extend(iteration.confidence_scores)
            
            # Track performance progression
            if iteration.evaluation_metrics:
                results['performance_progression'].append(
                    iteration.evaluation_metrics.get('holdout_accuracy', 0.0)
                )
        
        if all_quality_scores:
            results['average_quality_score'] = np.mean(all_quality_scores)
        if all_confidence_scores:
            results['average_confidence_score'] = np.mean(all_confidence_scores)
        
        # Final evaluation
        if holdout_data:
            final_performance = self._evaluate_on_holdout(holdout_data)
            results['final_performance'] = final_performance
        
        return results
    
    def save_self_training_state(self, output_path: str):
        """Save self-training state."""
        state = {
            'iteration_history': [
                {
                    'iteration_id': it.iteration_id,
                    'num_generated': len(it.generated_problems),
                    'num_filtered': len(it.filtered_problems),
                    'training_metrics': it.training_metrics,
                    'evaluation_metrics': it.evaluation_metrics,
                    'checkpoint_path': it.model_checkpoint_path,
                    'avg_quality_score': np.mean(it.quality_scores) if it.quality_scores else 0.0,
                    'avg_confidence_score': np.mean(it.confidence_scores) if it.confidence_scores else 0.0
                }
                for it in self.iteration_history
            ],
            'config': self.config.to_dict() if hasattr(self.config, 'to_dict') else self.config.__dict__,
            'global_step': self.global_step
        }
        
        with open(output_path, 'w') as f:
            json.dump(state, f, indent=2)
        
        logger.info(f"Self-training state saved to {output_path}")


def create_self_trainer(config: SelfTrainingConfig,
                       model_path: Optional[str] = None) -> SelfTrainer:
    """Create a self-trainer with optional pre-trained model."""
    model = None
    tokenizer = None
    
    if model_path:
        model = AutoModelForCausalLM.from_pretrained(model_path)
        tokenizer = AutoTokenizer.from_pretrained(model_path)
    
    return SelfTrainer(
        config=config,
        model=model,
        tokenizer=tokenizer
    )

