"""
Batch Processor for Efficient Batch Inference

This module implements dynamic batching and efficient batch processing
optimized for AMD MI300x hardware, including adaptive batch sizing,
request scheduling, and memory-efficient batch execution.
"""

import torch
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, field
import logging
import time
import threading
import queue
from concurrent.futures import ThreadPoolExecutor, Future
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig

logger = logging.getLogger(__name__)


@dataclass
class BatchConfig:
    """Configuration for batch processing."""
    
    # Batch settings
    max_batch_size: int = 32
    min_batch_size: int = 1
    dynamic_batching: bool = True
    timeout_ms: int = 100
    
    # Adaptive batching
    adaptive_batch_sizing: bool = True
    target_latency_ms: float = 500.0
    latency_tolerance: float = 0.2
    
    # Memory management
    max_memory_usage_gb: float = 16.0
    memory_safety_margin: float = 0.1
    
    # Scheduling
    scheduling_strategy: str = "fifo"  # "fifo", "shortest_first", "priority"
    max_queue_size: int = 1000
    
    # Performance optimization
    enable_padding_optimization: bool = True
    enable_sequence_bucketing: bool = True
    bucket_boundaries: List[int] = field(default_factory=lambda: [64, 128, 256, 512, 1024, 2048])
    
    # Parallel processing
    num_worker_threads: int = 4
    enable_async_processing: bool = True


@dataclass
class BatchRequest:
    """Represents a batch inference request."""
    
    request_id: str
    prompt: str
    generation_config: GenerationConfig
    priority: int = 0
    timestamp: float = field(default_factory=time.time)
    max_wait_time: Optional[float] = None
    callback: Optional[callable] = None
    
    # Request metadata
    expected_length: Optional[int] = None
    reasoning_task: bool = False
    
    def __post_init__(self):
        if self.max_wait_time is None:
            self.max_wait_time = 30.0  # Default 30 seconds


@dataclass
class BatchResult:
    """Result of batch processing."""
    
    request_id: str
    generated_text: str
    input_tokens: int
    output_tokens: int
    processing_time: float
    queue_time: float
    batch_size: int
    confidence_score: float = 0.0
    reasoning_steps: List[str] = field(default_factory=list)


class RequestQueue:
    """Thread-safe request queue with scheduling."""
    
    def __init__(self, config: BatchConfig):
        self.config = config
        self.queue = queue.PriorityQueue(maxsize=config.max_queue_size)
        self.lock = threading.RLock()
        
        # Statistics
        self.total_requests = 0
        self.processed_requests = 0
        self.dropped_requests = 0
    
    def add_request(self, request: BatchRequest) -> bool:
        """Add request to queue."""
        try:
            # Priority queue uses (priority, timestamp, request) for ordering
            priority_item = (
                -request.priority,  # Negative for max-heap behavior
                request.timestamp,
                request
            )
            
            self.queue.put(priority_item, block=False)
            
            with self.lock:
                self.total_requests += 1
            
            return True
            
        except queue.Full:
            with self.lock:
                self.dropped_requests += 1
            logger.warning(f"Request queue full, dropping request {request.request_id}")
            return False
    
    def get_batch(self, max_size: int, timeout_ms: int) -> List[BatchRequest]:
        """Get a batch of requests."""
        batch = []
        deadline = time.time() + timeout_ms / 1000.0
        
        # Get first request (blocking with timeout)
        try:
            timeout = max(0.001, deadline - time.time())
            priority_item = self.queue.get(timeout=timeout)
            batch.append(priority_item[2])  # Extract request from priority tuple
        except queue.Empty:
            return batch
        
        # Get additional requests (non-blocking)
        while len(batch) < max_size and time.time() < deadline:
            try:
                priority_item = self.queue.get(block=False)
                batch.append(priority_item[2])
            except queue.Empty:
                break
        
        return batch
    
    def size(self) -> int:
        """Get current queue size."""
        return self.queue.qsize()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get queue statistics."""
        with self.lock:
            return {
                'queue_size': self.queue.qsize(),
                'total_requests': self.total_requests,
                'processed_requests': self.processed_requests,
                'dropped_requests': self.dropped_requests,
                'drop_rate': self.dropped_requests / max(1, self.total_requests)
            }


class SequenceBucketer:
    """Groups requests by sequence length for efficient batching."""
    
    def __init__(self, bucket_boundaries: List[int]):
        self.bucket_boundaries = sorted(bucket_boundaries)
        self.buckets = {boundary: [] for boundary in bucket_boundaries}
        self.buckets[float('inf')] = []  # For sequences longer than max boundary
    
    def add_request(self, request: BatchRequest, sequence_length: int):
        """Add request to appropriate bucket."""
        bucket = self._find_bucket(sequence_length)
        self.buckets[bucket].append((request, sequence_length))
    
    def get_batch(self, max_size: int) -> List[Tuple[BatchRequest, int]]:
        """Get a batch from the most suitable bucket."""
        # Find bucket with most requests
        best_bucket = None
        max_requests = 0
        
        for bucket, requests in self.buckets.items():
            if len(requests) > max_requests:
                max_requests = len(requests)
                best_bucket = bucket
        
        if best_bucket is None or max_requests == 0:
            return []
        
        # Extract batch
        batch = self.buckets[best_bucket][:max_size]
        self.buckets[best_bucket] = self.buckets[best_bucket][max_size:]
        
        return batch
    
    def _find_bucket(self, sequence_length: int) -> Union[int, float]:
        """Find appropriate bucket for sequence length."""
        for boundary in self.bucket_boundaries:
            if sequence_length <= boundary:
                return boundary
        return float('inf')
    
    def get_total_requests(self) -> int:
        """Get total number of requests across all buckets."""
        return sum(len(requests) for requests in self.buckets.values())


class AdaptiveBatchSizer:
    """Dynamically adjusts batch size based on performance metrics."""
    
    def __init__(self, config: BatchConfig):
        self.config = config
        self.current_batch_size = config.max_batch_size // 2
        self.target_latency = config.target_latency_ms
        self.tolerance = config.latency_tolerance
        
        # Performance tracking
        self.latency_history = []
        self.throughput_history = []
        self.memory_usage_history = []
        
        # Adjustment parameters
        self.adjustment_frequency = 10  # Adjust every N batches
        self.batch_count = 0
        self.min_samples = 5
    
    def update_metrics(self, 
                      latency_ms: float,
                      throughput: float,
                      memory_usage_gb: float):
        """Update performance metrics."""
        self.latency_history.append(latency_ms)
        self.throughput_history.append(throughput)
        self.memory_usage_history.append(memory_usage_gb)
        
        # Keep only recent history
        max_history = 50
        if len(self.latency_history) > max_history:
            self.latency_history = self.latency_history[-max_history:]
            self.throughput_history = self.throughput_history[-max_history:]
            self.memory_usage_history = self.memory_usage_history[-max_history:]
        
        self.batch_count += 1
        
        # Adjust batch size periodically
        if self.batch_count % self.adjustment_frequency == 0:
            self._adjust_batch_size()
    
    def _adjust_batch_size(self):
        """Adjust batch size based on recent performance."""
        if len(self.latency_history) < self.min_samples:
            return
        
        # Calculate recent averages
        recent_latency = np.mean(self.latency_history[-self.min_samples:])
        recent_memory = np.mean(self.memory_usage_history[-self.min_samples:])
        
        # Check memory constraints
        if recent_memory > self.config.max_memory_usage_gb * (1 - self.config.memory_safety_margin):
            # Reduce batch size due to memory pressure
            self.current_batch_size = max(
                self.config.min_batch_size,
                int(self.current_batch_size * 0.8)
            )
            logger.info(f"Reduced batch size to {self.current_batch_size} due to memory pressure")
            return
        
        # Adjust based on latency
        latency_ratio = recent_latency / self.target_latency
        
        if latency_ratio > (1 + self.tolerance):
            # Latency too high, reduce batch size
            self.current_batch_size = max(
                self.config.min_batch_size,
                int(self.current_batch_size * 0.9)
            )
            logger.debug(f"Reduced batch size to {self.current_batch_size} (latency: {recent_latency:.1f}ms)")
            
        elif latency_ratio < (1 - self.tolerance):
            # Latency acceptable, try increasing batch size
            self.current_batch_size = min(
                self.config.max_batch_size,
                int(self.current_batch_size * 1.1)
            )
            logger.debug(f"Increased batch size to {self.current_batch_size} (latency: {recent_latency:.1f}ms)")
    
    def get_current_batch_size(self) -> int:
        """Get current optimal batch size."""
        return self.current_batch_size
    
    def get_performance_summary(self) -> Dict[str, Any]:
        """Get performance summary."""
        if not self.latency_history:
            return {}
        
        return {
            'current_batch_size': self.current_batch_size,
            'average_latency_ms': np.mean(self.latency_history),
            'average_throughput': np.mean(self.throughput_history),
            'average_memory_usage_gb': np.mean(self.memory_usage_history),
            'latency_p95_ms': np.percentile(self.latency_history, 95),
            'total_batches': self.batch_count
        }


class BatchProcessor:
    """
    Main batch processor for efficient batch inference.
    
    Implements dynamic batching, adaptive batch sizing, and optimized
    batch execution for AMD MI300x hardware.
    """
    
    def __init__(self,
                 model: AutoModelForCausalLM,
                 tokenizer: AutoTokenizer,
                 config: BatchConfig):
        """
        Initialize batch processor.
        
        Args:
            model: Language model
            tokenizer: Tokenizer
            config: Batch configuration
        """
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        self.device = model.device
        
        # Initialize components
        self.request_queue = RequestQueue(config)
        
        if config.enable_sequence_bucketing:
            self.sequence_bucketer = SequenceBucketer(config.bucket_boundaries)
        else:
            self.sequence_bucketer = None
        
        if config.adaptive_batch_sizing:
            self.adaptive_sizer = AdaptiveBatchSizer(config)
        else:
            self.adaptive_sizer = None
        
        # Processing state
        self.is_running = False
        self.worker_threads = []
        self.executor = None
        
        # Performance tracking
        self.batch_stats = {
            'total_batches': 0,
            'total_requests': 0,
            'total_processing_time': 0.0,
            'average_batch_size': 0.0,
            'average_latency': 0.0
        }
        
        logger.info("Batch Processor initialized")
        logger.info(f"  Max batch size: {config.max_batch_size}")
        logger.info(f"  Dynamic batching: {config.dynamic_batching}")
        logger.info(f"  Adaptive sizing: {config.adaptive_batch_sizing}")
    
    def start(self):
        """Start batch processing."""
        if self.is_running:
            return
        
        self.is_running = True
        
        if self.config.enable_async_processing:
            self.executor = ThreadPoolExecutor(max_workers=self.config.num_worker_threads)
            
            # Start worker threads
            for i in range(self.config.num_worker_threads):
                thread = threading.Thread(target=self._worker_loop, args=(i,))
                thread.daemon = True
                thread.start()
                self.worker_threads.append(thread)
        
        logger.info("Batch processor started")
    
    def stop(self):
        """Stop batch processing."""
        self.is_running = False
        
        if self.executor:
            self.executor.shutdown(wait=True)
        
        for thread in self.worker_threads:
            thread.join(timeout=5.0)
        
        logger.info("Batch processor stopped")
    
    def submit_request(self, request: BatchRequest) -> Future[BatchResult]:
        """
        Submit a request for batch processing.
        
        Args:
            request: Batch request
            
        Returns:
            Future that will contain the result
        """
        if not self.is_running:
            self.start()
        
        # Create future for result
        future = Future()
        request.callback = lambda result: future.set_result(result)
        
        # Add to queue
        success = self.request_queue.add_request(request)
        
        if not success:
            # Queue full, return error
            future.set_exception(RuntimeError("Request queue full"))
        
        return future
    
    def process_batch(self, 
                     prompts: List[str],
                     **generation_kwargs) -> List[BatchResult]:
        """
        Process a batch of prompts synchronously.
        
        Args:
            prompts: List of prompts
            **generation_kwargs: Generation parameters
            
        Returns:
            List of batch results
        """
        # Create generation config
        gen_config = GenerationConfig(**generation_kwargs)
        
        # Create batch requests
        requests = []
        for i, prompt in enumerate(prompts):
            request = BatchRequest(
                request_id=f"sync_batch_{i}",
                prompt=prompt,
                generation_config=gen_config
            )
            requests.append(request)
        
        # Process batch directly
        return self._process_batch_requests(requests)
    
    def _worker_loop(self, worker_id: int):
        """Main worker loop for processing batches."""
        logger.debug(f"Worker {worker_id} started")
        
        while self.is_running:
            try:
                # Get current batch size
                if self.adaptive_sizer:
                    max_batch_size = self.adaptive_sizer.get_current_batch_size()
                else:
                    max_batch_size = self.config.max_batch_size
                
                # Get batch of requests
                requests = self.request_queue.get_batch(
                    max_size=max_batch_size,
                    timeout_ms=self.config.timeout_ms
                )
                
                if not requests:
                    continue
                
                # Process batch
                results = self._process_batch_requests(requests)
                
                # Send results to callbacks
                for request, result in zip(requests, results):
                    if request.callback:
                        try:
                            request.callback(result)
                        except Exception as e:
                            logger.error(f"Error in callback for request {request.request_id}: {e}")
                
                # Update queue statistics
                with self.request_queue.lock:
                    self.request_queue.processed_requests += len(requests)
                
            except Exception as e:
                logger.error(f"Error in worker {worker_id}: {e}")
                time.sleep(0.1)  # Brief pause on error
        
        logger.debug(f"Worker {worker_id} stopped")
    
    def _process_batch_requests(self, requests: List[BatchRequest]) -> List[BatchResult]:
        """Process a batch of requests."""
        if not requests:
            return []
        
        start_time = time.time()
        
        # Prepare batch inputs
        batch_inputs = self._prepare_batch_inputs(requests)
        
        # Generate batch outputs
        batch_outputs = self._generate_batch(batch_inputs, requests)
        
        # Create results
        results = []
        for i, request in enumerate(requests):
            processing_time = time.time() - start_time
            queue_time = start_time - request.timestamp
            
            result = BatchResult(
                request_id=request.request_id,
                generated_text=batch_outputs[i]['generated_text'],
                input_tokens=batch_outputs[i]['input_tokens'],
                output_tokens=batch_outputs[i]['output_tokens'],
                processing_time=processing_time,
                queue_time=queue_time,
                batch_size=len(requests),
                confidence_score=batch_outputs[i].get('confidence_score', 0.0),
                reasoning_steps=batch_outputs[i].get('reasoning_steps', [])
            )
            results.append(result)
        
        # Update statistics
        self._update_batch_stats(requests, results, processing_time)
        
        return results
    
    def _prepare_batch_inputs(self, requests: List[BatchRequest]) -> Dict[str, torch.Tensor]:
        """Prepare batch inputs from requests."""
        prompts = [request.prompt for request in requests]
        
        # Tokenize all prompts
        tokenized = self.tokenizer(
            prompts,
            padding=True,
            truncation=True,
            return_tensors="pt",
            max_length=2048  # Reasonable default
        )
        
        # Move to device
        batch_inputs = {k: v.to(self.device) for k, v in tokenized.items()}
        
        return batch_inputs
    
    def _generate_batch(self, 
                       batch_inputs: Dict[str, torch.Tensor],
                       requests: List[BatchRequest]) -> List[Dict[str, Any]]:
        """Generate outputs for a batch."""
        # Use generation config from first request (assuming similar configs)
        gen_config = requests[0].generation_config
        
        # Generate
        with torch.no_grad():
            outputs = self.model.generate(
                **batch_inputs,
                generation_config=gen_config,
                return_dict_in_generate=True,
                output_scores=True,
                use_cache=True
            )
        
        # Process outputs
        batch_outputs = []
        input_lengths = batch_inputs['input_ids'].shape[1]
        
        for i in range(len(requests)):
            # Decode generated text
            generated_ids = outputs.sequences[i]
            full_text = self.tokenizer.decode(generated_ids, skip_special_tokens=True)
            
            # Extract generated part
            input_text = requests[i].prompt
            if full_text.startswith(input_text):
                generated_text = full_text[len(input_text):].strip()
            else:
                generated_text = full_text.strip()
            
            # Calculate token counts
            input_tokens = batch_inputs['input_ids'][i].ne(self.tokenizer.pad_token_id).sum().item()
            output_tokens = generated_ids.shape[0] - input_tokens
            
            # Compute confidence
            confidence_score = self._compute_confidence(outputs, i)
            
            batch_outputs.append({
                'generated_text': generated_text,
                'input_tokens': input_tokens,
                'output_tokens': output_tokens,
                'confidence_score': confidence_score,
                'reasoning_steps': []  # Would be populated by reasoning engine
            })
        
        return batch_outputs
    
    def _compute_confidence(self, outputs, sequence_index: int) -> float:
        """Compute confidence score for a sequence."""
        if not hasattr(outputs, 'scores') or not outputs.scores:
            return 0.5
        
        # Compute average probability of generated tokens
        token_probs = []
        for score in outputs.scores:
            if sequence_index < score.shape[0]:
                probs = F.softmax(score[sequence_index], dim=-1)
                max_prob = torch.max(probs)
                token_probs.append(max_prob.item())
        
        return np.mean(token_probs) if token_probs else 0.5
    
    def _update_batch_stats(self, 
                           requests: List[BatchRequest],
                           results: List[BatchResult],
                           processing_time: float):
        """Update batch processing statistics."""
        batch_size = len(requests)
        
        self.batch_stats['total_batches'] += 1
        self.batch_stats['total_requests'] += batch_size
        self.batch_stats['total_processing_time'] += processing_time
        
        # Update averages
        total_batches = self.batch_stats['total_batches']
        
        # Exponential moving average for batch size
        alpha = 0.1
        self.batch_stats['average_batch_size'] = (
            alpha * batch_size + 
            (1 - alpha) * self.batch_stats['average_batch_size']
        )
        
        # Average latency
        avg_latency = np.mean([result.processing_time for result in results])
        self.batch_stats['average_latency'] = (
            alpha * avg_latency + 
            (1 - alpha) * self.batch_stats['average_latency']
        )
        
        # Update adaptive sizer if enabled
        if self.adaptive_sizer:
            throughput = batch_size / processing_time
            memory_usage = self._get_memory_usage()
            
            self.adaptive_sizer.update_metrics(
                latency_ms=avg_latency * 1000,
                throughput=throughput,
                memory_usage_gb=memory_usage
            )
    
    def _get_memory_usage(self) -> float:
        """Get current memory usage in GB."""
        if torch.cuda.is_available():
            return torch.cuda.memory_allocated() / 1024**3
        return 0.0
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive batch processing statistics."""
        stats = self.batch_stats.copy()
        
        # Add queue statistics
        queue_stats = self.request_queue.get_stats()
        stats.update({f"queue_{k}": v for k, v in queue_stats.items()})
        
        # Add adaptive sizer statistics
        if self.adaptive_sizer:
            sizer_stats = self.adaptive_sizer.get_performance_summary()
            stats.update({f"adaptive_{k}": v for k, v in sizer_stats.items()})
        
        # Calculate derived metrics
        if stats['total_batches'] > 0:
            stats['overall_throughput'] = (
                stats['total_requests'] / stats['total_processing_time']
                if stats['total_processing_time'] > 0 else 0
            )
        
        return stats
    
    def reset_statistics(self):
        """Reset all statistics."""
        self.batch_stats = {
            'total_batches': 0,
            'total_requests': 0,
            'total_processing_time': 0.0,
            'average_batch_size': 0.0,
            'average_latency': 0.0
        }
        
        if self.adaptive_sizer:
            self.adaptive_sizer.latency_history.clear()
            self.adaptive_sizer.throughput_history.clear()
            self.adaptive_sizer.memory_usage_history.clear()
            self.adaptive_sizer.batch_count = 0
        
        logger.info("Batch processor statistics reset")


def create_batch_processor(model: AutoModelForCausalLM,
                         tokenizer: AutoTokenizer,
                         config_overrides: Optional[Dict[str, Any]] = None) -> BatchProcessor:
    """
    Create a batch processor with optional configuration overrides.
    
    Args:
        model: Language model
        tokenizer: Tokenizer
        config_overrides: Optional configuration overrides
        
    Returns:
        Configured BatchProcessor
    """
    config = BatchConfig()
    
    if config_overrides:
        for key, value in config_overrides.items():
            if hasattr(config, key):
                setattr(config, key, value)
    
    return BatchProcessor(model, tokenizer, config)

