"""
Group Relative Policy Optimization (GRPO) Trainer

This module implements the GRPO training algorithm, which provides significant
memory efficiency improvements over traditional PPO while maintaining or
improving training quality through group-relative advantage computation.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
import logging
from transformers import (
    AutoModelForCausalLM, 
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling
)
from transformers.trainer_utils import EvalPrediction
from torch.utils.data import DataLoader, Dataset
import wandb

from .training_config import GRPOConfig
from .training_utils import TrainingMetrics, ModelEvaluator
from .optimization_utils import AMDOptimizer, MemoryOptimizer

logger = logging.getLogger(__name__)


@dataclass
class GRPOBatch:
    """Batch data structure for GRPO training."""
    queries: torch.Tensor
    responses: torch.Tensor
    scores: torch.Tensor
    attention_mask: torch.Tensor
    group_ids: torch.Tensor
    
    def to(self, device: torch.device):
        """Move batch to device."""
        return GRPOBatch(
            queries=self.queries.to(device),
            responses=self.responses.to(device),
            scores=self.scores.to(device),
            attention_mask=self.attention_mask.to(device),
            group_ids=self.group_ids.to(device)
        )


class GRPOLoss(nn.Module):
    """GRPO loss function with group-relative advantages."""
    
    def __init__(self, config: GRPOConfig):
        super().__init__()
        self.config = config
        self.beta = config.beta
        self.clip_range = config.clip_range
        self.vf_coef = config.vf_coef
        
    def compute_group_advantages(self, scores: torch.Tensor, group_ids: torch.Tensor) -> torch.Tensor:
        """
        Compute group-relative advantages.
        
        Args:
            scores: Reward scores for each response
            group_ids: Group assignment for each response
            
        Returns:
            Group-relative advantages
        """
        advantages = torch.zeros_like(scores)
        
        for group_id in torch.unique(group_ids):
            group_mask = group_ids == group_id
            group_scores = scores[group_mask]
            
            if len(group_scores) > 1:
                # Compute relative advantages within group
                group_mean = group_scores.mean()
                group_advantages = group_scores - group_mean
                
                # Apply normalization if configured
                if self.config.advantage_normalization == "group":
                    group_std = group_scores.std() + 1e-8
                    group_advantages = group_advantages / group_std
                
                advantages[group_mask] = group_advantages
            else:
                # Single item in group, advantage is 0
                advantages[group_mask] = 0.0
        
        # Apply clipping
        if self.config.group_advantage_clip > 0:
            advantages = torch.clamp(
                advantages, 
                -self.config.group_advantage_clip, 
                self.config.group_advantage_clip
            )
        
        return advantages
    
    def forward(self, 
                logits: torch.Tensor,
                old_logits: torch.Tensor,
                scores: torch.Tensor,
                group_ids: torch.Tensor,
                attention_mask: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Compute GRPO loss.
        
        Args:
            logits: Current model logits
            old_logits: Reference model logits
            scores: Reward scores
            group_ids: Group assignments
            attention_mask: Attention mask
            
        Returns:
            Dictionary of loss components
        """
        # Compute group-relative advantages
        advantages = self.compute_group_advantages(scores, group_ids)
        
        # Compute log probabilities
        log_probs = F.log_softmax(logits, dim=-1)
        old_log_probs = F.log_softmax(old_logits, dim=-1)
        
        # Compute KL divergence
        kl_div = F.kl_div(log_probs, old_log_probs.exp(), reduction='none')
        kl_div = (kl_div * attention_mask.unsqueeze(-1)).sum(dim=-1)
        
        # Compute policy ratio
        ratio = torch.exp(log_probs.sum(dim=-1) - old_log_probs.sum(dim=-1))
        
        # Compute clipped policy loss
        policy_loss_1 = advantages * ratio
        policy_loss_2 = advantages * torch.clamp(ratio, 1 - self.clip_range, 1 + self.clip_range)
        policy_loss = -torch.min(policy_loss_1, policy_loss_2).mean()
        
        # Compute KL penalty
        kl_penalty = self.beta * kl_div.mean()
        
        # Total loss
        total_loss = policy_loss + kl_penalty
        
        return {
            'loss': total_loss,
            'policy_loss': policy_loss,
            'kl_penalty': kl_penalty,
            'advantages': advantages,
            'kl_div': kl_div.mean(),
            'ratio': ratio.mean()
        }


class GRPODataset(Dataset):
    """Dataset for GRPO training."""
    
    def __init__(self, 
                 data: List[Dict[str, Any]], 
                 tokenizer: AutoTokenizer,
                 config: GRPOConfig):
        self.data = data
        self.tokenizer = tokenizer
        self.config = config
        
        # Preprocess data
        self.processed_data = self._preprocess_data()
    
    def _preprocess_data(self) -> List[Dict[str, Any]]:
        """Preprocess the training data."""
        processed = []
        
        for i, item in enumerate(self.data):
            # Tokenize query and response
            query_text = item['question']
            response_text = item['answer']
            
            # Combine query and response
            full_text = f"{query_text}\n\nAnswer: {response_text}"
            
            # Tokenize
            encoding = self.tokenizer(
                full_text,
                max_length=self.config.max_length,
                padding='max_length',
                truncation=True,
                return_tensors='pt'
            )
            
            # Extract query length for masking
            query_encoding = self.tokenizer(
                query_text,
                max_length=self.config.max_prompt_length,
                truncation=True,
                return_tensors='pt'
            )
            query_length = query_encoding['input_ids'].shape[1]
            
            processed_item = {
                'input_ids': encoding['input_ids'].squeeze(0),
                'attention_mask': encoding['attention_mask'].squeeze(0),
                'query_length': query_length,
                'score': item.get('score', 0.0),
                'group_id': i // self.config.group_size,  # Assign to groups
                'metadata': item.get('metadata', {})
            }
            
            processed.append(processed_item)
        
        return processed
    
    def __len__(self) -> int:
        return len(self.processed_data)
    
    def __getitem__(self, idx: int) -> Dict[str, Any]:
        return self.processed_data[idx]


class GRPOTrainer:
    """
    Group Relative Policy Optimization Trainer.
    
    Implements the GRPO algorithm with memory-efficient group-relative
    advantage computation and AMD MI300x optimizations.
    """
    
    def __init__(self, 
                 config: GRPOConfig,
                 model: Optional[AutoModelForCausalLM] = None,
                 tokenizer: Optional[AutoTokenizer] = None,
                 train_dataset: Optional[Dataset] = None,
                 eval_dataset: Optional[Dataset] = None):
        """
        Initialize GRPO trainer.
        
        Args:
            config: GRPO training configuration
            model: Pre-trained model (will be loaded if None)
            tokenizer: Tokenizer (will be loaded if None)
            train_dataset: Training dataset
            eval_dataset: Evaluation dataset
        """
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Initialize model and tokenizer
        self.model = model or self._load_model()
        self.tokenizer = tokenizer or self._load_tokenizer()
        
        # Create reference model for KL computation
        self.ref_model = self._create_reference_model()
        
        # Initialize datasets
        self.train_dataset = train_dataset
        self.eval_dataset = eval_dataset
        
        # Initialize loss function
        self.loss_fn = GRPOLoss(config)
        
        # Initialize optimizer
        self.optimizer = self._create_optimizer()
        self.scheduler = self._create_scheduler()
        
        # Initialize metrics tracking
        self.metrics = TrainingMetrics()
        self.evaluator = ModelEvaluator(self.model, self.tokenizer)
        
        # AMD optimizations
        if config.use_rocm_optimizations:
            self.amd_optimizer = AMDOptimizer(config)
            self.memory_optimizer = MemoryOptimizer(config)
            self._apply_amd_optimizations()
        
        logger.info("GRPO Trainer initialized")
    
    def _load_model(self) -> AutoModelForCausalLM:
        """Load the pre-trained model."""
        model = AutoModelForCausalLM.from_pretrained(
            self.config.model_name,
            revision=self.config.model_revision,
            torch_dtype=getattr(torch, self.config.torch_dtype),
            attn_implementation=self.config.attn_implementation,
            device_map=self.config.device_map if hasattr(self.config, 'device_map') else "auto",
            low_cpu_mem_usage=True,
            use_cache=False  # Disable for training
        )
        
        # Enable gradient checkpointing for memory efficiency
        if self.config.gradient_checkpointing:
            model.gradient_checkpointing_enable()
        
        return model
    
    def _load_tokenizer(self) -> AutoTokenizer:
        """Load the tokenizer."""
        tokenizer = AutoTokenizer.from_pretrained(
            self.config.model_name,
            revision=self.config.model_revision
        )
        
        # Add padding token if not present
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        return tokenizer
    
    def _create_reference_model(self) -> AutoModelForCausalLM:
        """Create reference model for KL computation."""
        ref_model = AutoModelForCausalLM.from_pretrained(
            self.config.model_name,
            revision=self.config.model_revision,
            torch_dtype=getattr(torch, self.config.torch_dtype),
            attn_implementation=self.config.attn_implementation,
            device_map=self.config.device_map if hasattr(self.config, 'device_map') else "auto",
            low_cpu_mem_usage=True,
            use_cache=False
        )
        
        # Freeze reference model
        for param in ref_model.parameters():
            param.requires_grad = False
        
        ref_model.eval()
        return ref_model
    
    def _create_optimizer(self) -> torch.optim.Optimizer:
        """Create optimizer."""
        if self.config.optimizer_type.value == "adamw":
            return torch.optim.AdamW(
                self.model.parameters(),
                lr=self.config.learning_rate,
                betas=(self.config.adam_beta1, self.config.adam_beta2),
                eps=self.config.adam_epsilon,
                weight_decay=self.config.weight_decay
            )
        else:
            raise ValueError(f"Unsupported optimizer: {self.config.optimizer_type}")
    
    def _create_scheduler(self) -> torch.optim.lr_scheduler._LRScheduler:
        """Create learning rate scheduler."""
        if self.config.lr_scheduler_type.value == "cosine":
            return torch.optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=self.config.num_train_epochs,
                **self.config.lr_scheduler_kwargs
            )
        elif self.config.lr_scheduler_type.value == "linear":
            return torch.optim.lr_scheduler.LinearLR(
                self.optimizer,
                **self.config.lr_scheduler_kwargs
            )
        else:
            return torch.optim.lr_scheduler.ConstantLR(self.optimizer)
    
    def _apply_amd_optimizations(self):
        """Apply AMD MI300x specific optimizations."""
        # Memory optimizations
        if hasattr(torch.backends, 'cuda') and torch.backends.cuda.is_available():
            torch.backends.cuda.matmul.allow_tf32 = self.config.tf32
            torch.backends.cudnn.allow_tf32 = self.config.tf32
        
        # ROCm specific optimizations
        if hasattr(torch, 'cuda') and torch.cuda.is_available():
            # Set memory fraction
            torch.cuda.set_per_process_memory_fraction(self.config.rocm_memory_fraction)
            
            # Enable memory pool
            torch.cuda.empty_cache()
    
    def create_dataloader(self, dataset: Dataset, is_training: bool = True) -> DataLoader:
        """Create data loader for training or evaluation."""
        batch_size = (self.config.per_device_train_batch_size if is_training 
                     else self.config.per_device_eval_batch_size)
        
        return DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=is_training,
            num_workers=self.config.dataloader_num_workers,
            pin_memory=self.config.dataloader_pin_memory,
            collate_fn=self._collate_fn
        )
    
    def _collate_fn(self, batch: List[Dict[str, Any]]) -> GRPOBatch:
        """Collate function for GRPO batches."""
        # Extract components
        input_ids = torch.stack([item['input_ids'] for item in batch])
        attention_mask = torch.stack([item['attention_mask'] for item in batch])
        scores = torch.tensor([item['score'] for item in batch], dtype=torch.float32)
        group_ids = torch.tensor([item['group_id'] for item in batch], dtype=torch.long)
        
        # Split into queries and responses based on query_length
        queries = []
        responses = []
        
        for i, item in enumerate(batch):
            query_length = item['query_length']
            query = input_ids[i, :query_length]
            response = input_ids[i, query_length:]
            
            queries.append(query)
            responses.append(response)
        
        # Pad sequences
        queries = torch.nn.utils.rnn.pad_sequence(queries, batch_first=True, padding_value=self.tokenizer.pad_token_id)
        responses = torch.nn.utils.rnn.pad_sequence(responses, batch_first=True, padding_value=self.tokenizer.pad_token_id)
        
        return GRPOBatch(
            queries=queries,
            responses=responses,
            scores=scores,
            attention_mask=attention_mask,
            group_ids=group_ids
        )
    
    def train_step(self, batch: GRPOBatch) -> Dict[str, float]:
        """Perform a single training step."""
        self.model.train()
        batch = batch.to(self.device)
        
        # Forward pass through current model
        with torch.cuda.amp.autocast(enabled=self.config.bf16):
            outputs = self.model(
                input_ids=torch.cat([batch.queries, batch.responses], dim=1),
                attention_mask=batch.attention_mask,
                return_dict=True
            )
            current_logits = outputs.logits
            
            # Forward pass through reference model
            with torch.no_grad():
                ref_outputs = self.ref_model(
                    input_ids=torch.cat([batch.queries, batch.responses], dim=1),
                    attention_mask=batch.attention_mask,
                    return_dict=True
                )
                ref_logits = ref_outputs.logits
            
            # Compute GRPO loss
            loss_dict = self.loss_fn(
                logits=current_logits,
                old_logits=ref_logits,
                scores=batch.scores,
                group_ids=batch.group_ids,
                attention_mask=batch.attention_mask
            )
        
        # Backward pass
        loss = loss_dict['loss']
        loss.backward()
        
        # Gradient clipping
        if self.config.max_grad_norm > 0:
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
        
        # Optimizer step
        self.optimizer.step()
        self.scheduler.step()
        self.optimizer.zero_grad()
        
        # Convert tensors to floats for logging
        step_metrics = {k: v.item() if torch.is_tensor(v) else v for k, v in loss_dict.items()}
        step_metrics['learning_rate'] = self.scheduler.get_last_lr()[0]
        
        return step_metrics
    
    def evaluate(self, eval_dataloader: DataLoader) -> Dict[str, float]:
        """Evaluate the model."""
        self.model.eval()
        eval_metrics = []
        
        with torch.no_grad():
            for batch in eval_dataloader:
                batch = batch.to(self.device)
                
                # Forward pass
                outputs = self.model(
                    input_ids=torch.cat([batch.queries, batch.responses], dim=1),
                    attention_mask=batch.attention_mask,
                    return_dict=True
                )
                
                # Compute evaluation metrics
                batch_metrics = self.evaluator.compute_batch_metrics(
                    outputs.logits, batch.responses, batch.attention_mask
                )
                eval_metrics.append(batch_metrics)
        
        # Aggregate metrics
        aggregated_metrics = {}
        for key in eval_metrics[0].keys():
            aggregated_metrics[f"eval_{key}"] = np.mean([m[key] for m in eval_metrics])
        
        return aggregated_metrics
    
    def train(self, 
              train_dataset: Optional[Dataset] = None,
              eval_dataset: Optional[Dataset] = None,
              num_epochs: Optional[int] = None) -> Dict[str, Any]:
        """
        Train the model using GRPO.
        
        Args:
            train_dataset: Training dataset
            eval_dataset: Evaluation dataset
            num_epochs: Number of training epochs
            
        Returns:
            Training results and metrics
        """
        # Use provided datasets or fall back to instance datasets
        train_dataset = train_dataset or self.train_dataset
        eval_dataset = eval_dataset or self.eval_dataset
        num_epochs = num_epochs or self.config.num_train_epochs
        
        if train_dataset is None:
            raise ValueError("No training dataset provided")
        
        # Create data loaders
        train_dataloader = self.create_dataloader(train_dataset, is_training=True)
        eval_dataloader = self.create_dataloader(eval_dataset, is_training=False) if eval_dataset else None
        
        # Initialize tracking
        global_step = 0
        best_metric = float('-inf')
        training_history = []
        
        logger.info(f"Starting GRPO training for {num_epochs} epochs")
        logger.info(f"Training dataset size: {len(train_dataset)}")
        logger.info(f"Batch size: {self.config.per_device_train_batch_size}")
        logger.info(f"Group size: {self.config.group_size}")
        
        for epoch in range(num_epochs):
            epoch_metrics = []
            
            for step, batch in enumerate(train_dataloader):
                # Training step
                step_metrics = self.train_step(batch)
                epoch_metrics.append(step_metrics)
                global_step += 1
                
                # Logging
                if global_step % self.config.logging_steps == 0:
                    avg_metrics = {k: np.mean([m[k] for m in epoch_metrics[-self.config.logging_steps:]])
                                 for k in step_metrics.keys()}
                    
                    logger.info(f"Step {global_step}: {avg_metrics}")
                    
                    if self.config.enable_wandb:
                        wandb.log(avg_metrics, step=global_step)
                
                # Evaluation
                if (eval_dataloader and global_step % self.config.eval_steps == 0):
                    eval_metrics = self.evaluate(eval_dataloader)
                    logger.info(f"Evaluation at step {global_step}: {eval_metrics}")
                    
                    if self.config.enable_wandb:
                        wandb.log(eval_metrics, step=global_step)
                    
                    # Save best model
                    current_metric = eval_metrics.get(f"eval_{self.config.metric_for_best_model}", 0)
                    if current_metric > best_metric:
                        best_metric = current_metric
                        self.save_model(f"{self.config.output_dir}/best_model")
                
                # Save checkpoint
                if global_step % self.config.save_steps == 0:
                    self.save_checkpoint(f"{self.config.output_dir}/checkpoint-{global_step}")
            
            # End of epoch evaluation
            if eval_dataloader:
                eval_metrics = self.evaluate(eval_dataloader)
                logger.info(f"End of epoch {epoch + 1}: {eval_metrics}")
                
                training_history.append({
                    'epoch': epoch + 1,
                    'train_metrics': {k: np.mean([m[k] for m in epoch_metrics]) for k in epoch_metrics[0].keys()},
                    'eval_metrics': eval_metrics
                })
        
        # Final model save
        self.save_model(f"{self.config.output_dir}/final_model")
        
        logger.info("GRPO training completed")
        
        return {
            'training_history': training_history,
            'best_metric': best_metric,
            'final_metrics': training_history[-1] if training_history else {}
        }
    
    def save_model(self, output_dir: str):
        """Save the trained model."""
        self.model.save_pretrained(output_dir, safe_serialization=self.config.save_safetensors)
        self.tokenizer.save_pretrained(output_dir)
        logger.info(f"Model saved to {output_dir}")
    
    def save_checkpoint(self, output_dir: str):
        """Save training checkpoint."""
        checkpoint = {
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'config': self.config.to_dict() if hasattr(self.config, 'to_dict') else self.config.__dict__
        }
        
        torch.save(checkpoint, f"{output_dir}/training_state.pt")
        self.save_model(output_dir)
        logger.info(f"Checkpoint saved to {output_dir}")
    
    def load_checkpoint(self, checkpoint_dir: str):
        """Load training checkpoint."""
        checkpoint = torch.load(f"{checkpoint_dir}/training_state.pt", map_location=self.device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        
        logger.info(f"Checkpoint loaded from {checkpoint_dir}")


def create_grpo_dataset(data: List[Dict[str, Any]], 
                       tokenizer: AutoTokenizer,
                       config: GRPOConfig) -> GRPODataset:
    """Create a GRPO dataset from training data."""
    return GRPODataset(data, tokenizer, config)

