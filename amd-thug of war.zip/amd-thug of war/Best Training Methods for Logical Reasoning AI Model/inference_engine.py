"""
AMD MI300x Optimized Inference Engine

This module provides the main inference engine optimized for AMD MI300x hardware,
integrating speculative decoding, KV cache optimization, and reasoning-aware
inference strategies for maximum performance.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, field
import logging
import time
from pathlib import Path
import json
from transformers import (
    AutoModelForCausalLM, 
    AutoTokenizer,
    GenerationConfig,
    StoppingCriteria,
    StoppingCriteriaList
)

from .speculative_decoder import SpeculativeDecoder, SpeculativeConfig
from .kv_cache_manager import KVCacheManager, CacheConfig
from .reasoning_engine import ReasoningEngine, ReasoningConfig
from .batch_processor import BatchProcessor, BatchConfig
from .optimization_manager import OptimizationManager

logger = logging.getLogger(__name__)


@dataclass
class InferenceConfig:
    """Configuration for inference engine."""
    
    # Model settings
    model_path: str = "Qwen/Qwen2.5-4B"
    tokenizer_path: Optional[str] = None
    torch_dtype: str = "bfloat16"
    device_map: str = "auto"
    
    # Generation settings
    max_new_tokens: int = 512
    temperature: float = 0.1
    top_p: float = 0.9
    top_k: int = 50
    do_sample: bool = True
    repetition_penalty: float = 1.1
    
    # AMD MI300x optimizations
    enable_rocm_optimizations: bool = True
    enable_flash_attention: bool = True
    enable_kv_cache_optimization: bool = True
    enable_speculative_decoding: bool = True
    enable_batch_processing: bool = True
    
    # Speculative decoding
    draft_model_path: Optional[str] = None
    lookahead_steps: int = 4
    acceptance_threshold: float = 0.8
    
    # KV cache settings
    cache_implementation: str = "flash_attention"
    max_cache_length: int = 4096
    cache_dtype: str = "bfloat16"
    enable_cache_quantization: bool = True
    
    # Batch processing
    max_batch_size: int = 32
    dynamic_batching: bool = True
    batch_timeout_ms: int = 100
    
    # Reasoning optimization
    enable_reasoning_optimization: bool = True
    reasoning_strategy: str = "step_by_step"  # "step_by_step", "chain_of_thought", "direct"
    max_reasoning_steps: int = 10
    
    # Performance monitoring
    enable_performance_monitoring: bool = True
    log_inference_metrics: bool = True
    
    # Memory management
    memory_fraction: float = 0.95
    enable_memory_optimization: bool = True
    
    def __post_init__(self):
        if self.tokenizer_path is None:
            self.tokenizer_path = self.model_path


@dataclass
class InferenceResult:
    """Result of inference operation."""
    
    generated_text: str
    input_tokens: int
    output_tokens: int
    total_time: float
    tokens_per_second: float
    reasoning_steps: List[str] = field(default_factory=list)
    confidence_score: float = 0.0
    cache_hits: int = 0
    cache_misses: int = 0
    speculative_acceptance_rate: float = 0.0
    memory_usage: Dict[str, float] = field(default_factory=dict)


class ReasoningStoppingCriteria(StoppingCriteria):
    """Custom stopping criteria for reasoning tasks."""
    
    def __init__(self, tokenizer: AutoTokenizer, max_reasoning_steps: int = 10):
        self.tokenizer = tokenizer
        self.max_reasoning_steps = max_reasoning_steps
        self.step_count = 0
        
        # Define reasoning completion indicators
        self.completion_phrases = [
            "therefore", "thus", "in conclusion", "the answer is",
            "final answer", "conclusion", "result"
        ]
    
    def __call__(self, input_ids: torch.LongTensor, scores: torch.FloatTensor, **kwargs) -> bool:
        # Decode the latest generated text
        latest_text = self.tokenizer.decode(input_ids[0], skip_special_tokens=True)
        
        # Check for completion phrases
        latest_text_lower = latest_text.lower()
        for phrase in self.completion_phrases:
            if phrase in latest_text_lower:
                return True
        
        # Check step count
        step_indicators = ["step", "first", "second", "third", "next", "finally"]
        for indicator in step_indicators:
            if indicator in latest_text_lower:
                self.step_count += 1
                break
        
        return self.step_count >= self.max_reasoning_steps


class InferenceEngine:
    """
    High-performance inference engine optimized for AMD MI300x.
    
    Integrates multiple optimization techniques including speculative decoding,
    KV cache optimization, reasoning-aware generation, and batch processing.
    """
    
    def __init__(self, config: InferenceConfig):
        """
        Initialize inference engine.
        
        Args:
            config: Inference configuration
        """
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Load model and tokenizer
        self.model = self._load_model()
        self.tokenizer = self._load_tokenizer()
        
        # Initialize optimization components
        self.optimization_manager = OptimizationManager(config)
        self.optimization_manager.apply_optimizations(self.model)
        
        # Initialize KV cache manager
        if config.enable_kv_cache_optimization:
            cache_config = CacheConfig(
                implementation=config.cache_implementation,
                max_length=config.max_cache_length,
                dtype=getattr(torch, config.cache_dtype),
                enable_quantization=config.enable_cache_quantization
            )
            self.kv_cache_manager = KVCacheManager(cache_config)
        else:
            self.kv_cache_manager = None
        
        # Initialize speculative decoder
        if config.enable_speculative_decoding:
            spec_config = SpeculativeConfig(
                draft_model_path=config.draft_model_path,
                lookahead_steps=config.lookahead_steps,
                acceptance_threshold=config.acceptance_threshold
            )
            self.speculative_decoder = SpeculativeDecoder(
                main_model=self.model,
                tokenizer=self.tokenizer,
                config=spec_config
            )
        else:
            self.speculative_decoder = None
        
        # Initialize reasoning engine
        if config.enable_reasoning_optimization:
            reasoning_config = ReasoningConfig(
                strategy=config.reasoning_strategy,
                max_steps=config.max_reasoning_steps
            )
            self.reasoning_engine = ReasoningEngine(
                model=self.model,
                tokenizer=self.tokenizer,
                config=reasoning_config
            )
        else:
            self.reasoning_engine = None
        
        # Initialize batch processor
        if config.enable_batch_processing:
            batch_config = BatchConfig(
                max_batch_size=config.max_batch_size,
                dynamic_batching=config.dynamic_batching,
                timeout_ms=config.batch_timeout_ms
            )
            self.batch_processor = BatchProcessor(
                model=self.model,
                tokenizer=self.tokenizer,
                config=batch_config
            )
        else:
            self.batch_processor = None
        
        # Performance monitoring
        self.inference_stats = {
            'total_inferences': 0,
            'total_tokens_generated': 0,
            'total_time': 0.0,
            'cache_hit_rate': 0.0,
            'speculative_acceptance_rate': 0.0
        }
        
        logger.info("Inference Engine initialized with AMD MI300x optimizations")
        self._log_configuration()
    
    def _load_model(self) -> AutoModelForCausalLM:
        """Load the model with AMD optimizations."""
        model = AutoModelForCausalLM.from_pretrained(
            self.config.model_path,
            torch_dtype=getattr(torch, self.config.torch_dtype),
            device_map=self.config.device_map,
            attn_implementation="flash_attention_2" if self.config.enable_flash_attention else None,
            low_cpu_mem_usage=True,
            use_cache=True  # Enable for inference
        )
        
        # Set to evaluation mode
        model.eval()
        
        # Disable gradient computation
        for param in model.parameters():
            param.requires_grad = False
        
        return model
    
    def _load_tokenizer(self) -> AutoTokenizer:
        """Load the tokenizer."""
        tokenizer = AutoTokenizer.from_pretrained(self.config.tokenizer_path)
        
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        return tokenizer
    
    def _log_configuration(self):
        """Log the current configuration."""
        logger.info("Inference Engine Configuration:")
        logger.info(f"  Model: {self.config.model_path}")
        logger.info(f"  Device: {self.device}")
        logger.info(f"  Torch dtype: {self.config.torch_dtype}")
        logger.info(f"  Flash Attention: {self.config.enable_flash_attention}")
        logger.info(f"  KV Cache Optimization: {self.config.enable_kv_cache_optimization}")
        logger.info(f"  Speculative Decoding: {self.config.enable_speculative_decoding}")
        logger.info(f"  Batch Processing: {self.config.enable_batch_processing}")
        logger.info(f"  Reasoning Optimization: {self.config.enable_reasoning_optimization}")
    
    def generate(self, 
                prompt: str,
                **generation_kwargs) -> InferenceResult:
        """
        Generate text for a single prompt.
        
        Args:
            prompt: Input prompt
            **generation_kwargs: Additional generation parameters
            
        Returns:
            InferenceResult with generated text and metrics
        """
        start_time = time.time()
        
        # Prepare input
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        input_length = inputs['input_ids'].shape[1]
        
        # Merge generation config
        gen_config = self._create_generation_config(**generation_kwargs)
        
        # Choose generation strategy
        if self.config.enable_reasoning_optimization and self._is_reasoning_task(prompt):
            result = self._generate_with_reasoning(inputs, gen_config)
        elif self.config.enable_speculative_decoding and self.speculative_decoder:
            result = self._generate_with_speculation(inputs, gen_config)
        else:
            result = self._generate_standard(inputs, gen_config)
        
        # Process result
        generated_text = self.tokenizer.decode(result['output_ids'][0], skip_special_tokens=True)
        
        # Remove input prompt from output
        if generated_text.startswith(prompt):
            generated_text = generated_text[len(prompt):].strip()
        
        # Calculate metrics
        end_time = time.time()
        total_time = end_time - start_time
        output_length = result['output_ids'].shape[1] - input_length
        tokens_per_second = output_length / total_time if total_time > 0 else 0
        
        # Create inference result
        inference_result = InferenceResult(
            generated_text=generated_text,
            input_tokens=input_length,
            output_tokens=output_length,
            total_time=total_time,
            tokens_per_second=tokens_per_second,
            reasoning_steps=result.get('reasoning_steps', []),
            confidence_score=result.get('confidence_score', 0.0),
            cache_hits=result.get('cache_hits', 0),
            cache_misses=result.get('cache_misses', 0),
            speculative_acceptance_rate=result.get('speculative_acceptance_rate', 0.0),
            memory_usage=self._get_memory_usage()
        )
        
        # Update statistics
        self._update_stats(inference_result)
        
        # Log metrics if enabled
        if self.config.log_inference_metrics:
            self._log_inference_metrics(inference_result)
        
        return inference_result
    
    def generate_batch(self, 
                      prompts: List[str],
                      **generation_kwargs) -> List[InferenceResult]:
        """
        Generate text for multiple prompts using batch processing.
        
        Args:
            prompts: List of input prompts
            **generation_kwargs: Additional generation parameters
            
        Returns:
            List of InferenceResult objects
        """
        if not self.config.enable_batch_processing or not self.batch_processor:
            # Fall back to sequential processing
            return [self.generate(prompt, **generation_kwargs) for prompt in prompts]
        
        return self.batch_processor.process_batch(prompts, **generation_kwargs)
    
    def _create_generation_config(self, **kwargs) -> GenerationConfig:
        """Create generation configuration."""
        config_dict = {
            'max_new_tokens': self.config.max_new_tokens,
            'temperature': self.config.temperature,
            'top_p': self.config.top_p,
            'top_k': self.config.top_k,
            'do_sample': self.config.do_sample,
            'repetition_penalty': self.config.repetition_penalty,
            'pad_token_id': self.tokenizer.eos_token_id,
            'eos_token_id': self.tokenizer.eos_token_id,
            'return_dict_in_generate': True,
            'output_scores': True
        }
        
        # Override with provided kwargs
        config_dict.update(kwargs)
        
        return GenerationConfig(**config_dict)
    
    def _is_reasoning_task(self, prompt: str) -> bool:
        """Determine if the prompt requires reasoning."""
        reasoning_indicators = [
            "solve", "find", "calculate", "determine", "prove", "explain",
            "why", "how", "what", "which", "reasoning", "logic", "puzzle"
        ]
        
        prompt_lower = prompt.lower()
        return any(indicator in prompt_lower for indicator in reasoning_indicators)
    
    def _generate_with_reasoning(self, 
                               inputs: Dict[str, torch.Tensor],
                               gen_config: GenerationConfig) -> Dict[str, Any]:
        """Generate with reasoning optimization."""
        return self.reasoning_engine.generate_with_reasoning(inputs, gen_config)
    
    def _generate_with_speculation(self, 
                                 inputs: Dict[str, torch.Tensor],
                                 gen_config: GenerationConfig) -> Dict[str, Any]:
        """Generate with speculative decoding."""
        return self.speculative_decoder.generate_speculative(inputs, gen_config)
    
    def _generate_standard(self, 
                         inputs: Dict[str, torch.Tensor],
                         gen_config: GenerationConfig) -> Dict[str, Any]:
        """Standard generation with optimizations."""
        # Add reasoning stopping criteria for logical reasoning tasks
        stopping_criteria = StoppingCriteriaList([
            ReasoningStoppingCriteria(self.tokenizer, self.config.max_reasoning_steps)
        ])
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                generation_config=gen_config,
                stopping_criteria=stopping_criteria,
                use_cache=True
            )
        
        return {
            'output_ids': outputs.sequences,
            'scores': outputs.scores if hasattr(outputs, 'scores') else None,
            'confidence_score': self._compute_confidence_score(outputs),
            'cache_hits': 0,  # Would be populated by cache manager
            'cache_misses': 0,
            'speculative_acceptance_rate': 0.0
        }
    
    def _compute_confidence_score(self, outputs) -> float:
        """Compute confidence score from generation outputs."""
        if not hasattr(outputs, 'scores') or not outputs.scores:
            return 0.5  # Default confidence
        
        # Compute average probability of generated tokens
        token_probs = []
        for score in outputs.scores:
            probs = F.softmax(score, dim=-1)
            max_prob = torch.max(probs, dim=-1)[0]
            token_probs.append(max_prob.mean().item())
        
        return np.mean(token_probs) if token_probs else 0.5
    
    def _get_memory_usage(self) -> Dict[str, float]:
        """Get current memory usage."""
        if torch.cuda.is_available():
            return {
                'allocated_gb': torch.cuda.memory_allocated() / 1024**3,
                'reserved_gb': torch.cuda.memory_reserved() / 1024**3,
                'max_allocated_gb': torch.cuda.max_memory_allocated() / 1024**3
            }
        return {}
    
    def _update_stats(self, result: InferenceResult):
        """Update inference statistics."""
        self.inference_stats['total_inferences'] += 1
        self.inference_stats['total_tokens_generated'] += result.output_tokens
        self.inference_stats['total_time'] += result.total_time
        
        # Update cache hit rate
        total_cache_ops = result.cache_hits + result.cache_misses
        if total_cache_ops > 0:
            cache_hit_rate = result.cache_hits / total_cache_ops
            # Exponential moving average
            alpha = 0.1
            self.inference_stats['cache_hit_rate'] = (
                alpha * cache_hit_rate + 
                (1 - alpha) * self.inference_stats['cache_hit_rate']
            )
        
        # Update speculative acceptance rate
        if result.speculative_acceptance_rate > 0:
            alpha = 0.1
            self.inference_stats['speculative_acceptance_rate'] = (
                alpha * result.speculative_acceptance_rate + 
                (1 - alpha) * self.inference_stats['speculative_acceptance_rate']
            )
    
    def _log_inference_metrics(self, result: InferenceResult):
        """Log inference metrics."""
        logger.debug(f"Inference completed:")
        logger.debug(f"  Tokens/sec: {result.tokens_per_second:.2f}")
        logger.debug(f"  Total time: {result.total_time:.3f}s")
        logger.debug(f"  Input tokens: {result.input_tokens}")
        logger.debug(f"  Output tokens: {result.output_tokens}")
        logger.debug(f"  Confidence: {result.confidence_score:.3f}")
        
        if result.reasoning_steps:
            logger.debug(f"  Reasoning steps: {len(result.reasoning_steps)}")
        
        if result.memory_usage:
            logger.debug(f"  Memory usage: {result.memory_usage}")
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get comprehensive performance statistics."""
        stats = self.inference_stats.copy()
        
        # Calculate derived metrics
        if stats['total_inferences'] > 0:
            stats['avg_tokens_per_inference'] = (
                stats['total_tokens_generated'] / stats['total_inferences']
            )
            stats['avg_time_per_inference'] = (
                stats['total_time'] / stats['total_inferences']
            )
            stats['overall_tokens_per_second'] = (
                stats['total_tokens_generated'] / stats['total_time']
                if stats['total_time'] > 0 else 0
            )
        
        # Add memory statistics
        stats['memory_usage'] = self._get_memory_usage()
        
        # Add model information
        stats['model_info'] = {
            'model_path': self.config.model_path,
            'torch_dtype': self.config.torch_dtype,
            'device': str(self.device)
        }
        
        return stats
    
    def reset_stats(self):
        """Reset performance statistics."""
        self.inference_stats = {
            'total_inferences': 0,
            'total_tokens_generated': 0,
            'total_time': 0.0,
            'cache_hit_rate': 0.0,
            'speculative_acceptance_rate': 0.0
        }
        
        logger.info("Performance statistics reset")
    
    def save_stats(self, output_path: str):
        """Save performance statistics to file."""
        stats = self.get_performance_stats()
        
        with open(output_path, 'w') as f:
            json.dump(stats, f, indent=2)
        
        logger.info(f"Performance statistics saved to {output_path}")
    
    def optimize_for_throughput(self):
        """Optimize engine configuration for maximum throughput."""
        logger.info("Optimizing for throughput...")
        
        # Increase batch size
        if self.batch_processor:
            self.batch_processor.config.max_batch_size = min(
                self.batch_processor.config.max_batch_size * 2, 64
            )
        
        # Reduce generation quality for speed
        self.config.temperature = 0.0  # Greedy decoding
        self.config.do_sample = False
        self.config.top_k = 1
        
        # Enable all optimizations
        self.config.enable_speculative_decoding = True
        self.config.enable_kv_cache_optimization = True
        
        logger.info("Throughput optimization applied")
    
    def optimize_for_quality(self):
        """Optimize engine configuration for maximum quality."""
        logger.info("Optimizing for quality...")
        
        # Reduce batch size for better attention
        if self.batch_processor:
            self.batch_processor.config.max_batch_size = max(
                self.batch_processor.config.max_batch_size // 2, 1
            )
        
        # Increase generation quality
        self.config.temperature = 0.7
        self.config.do_sample = True
        self.config.top_k = 50
        self.config.top_p = 0.9
        
        # Enable reasoning optimization
        self.config.enable_reasoning_optimization = True
        
        logger.info("Quality optimization applied")
    
    def cleanup(self):
        """Clean up resources."""
        # Clear CUDA cache
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        # Clean up components
        if self.kv_cache_manager:
            self.kv_cache_manager.clear_cache()
        
        logger.info("Inference engine cleanup completed")


def create_inference_engine(model_path: str, 
                          config_overrides: Optional[Dict[str, Any]] = None) -> InferenceEngine:
    """
    Create an inference engine with optional configuration overrides.
    
    Args:
        model_path: Path to the model
        config_overrides: Optional configuration overrides
        
    Returns:
        Configured InferenceEngine
    """
    config = InferenceConfig(model_path=model_path)
    
    if config_overrides:
        for key, value in config_overrides.items():
            if hasattr(config, key):
                setattr(config, key, value)
    
    return InferenceEngine(config)

