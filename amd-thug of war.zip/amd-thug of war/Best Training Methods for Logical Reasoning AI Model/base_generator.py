"""
Base Generator Class for Synthetic Data Generation

This module provides the foundational classes and interfaces for generating
high-quality synthetic reasoning problems with systematic difficulty progression
and comprehensive quality validation.
"""

import random
import json
import hashlib
from abc import ABC, abstractmethod
from enum import Enum
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass, asdict
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DifficultyLevel(Enum):
    """Enumeration of difficulty levels for curriculum learning."""
    BEGINNER = 1      # Simple, single-step reasoning
    INTERMEDIATE = 2  # Multi-step reasoning with clear constraints
    ADVANCED = 3      # Complex reasoning with multiple constraints
    EXPERT = 4        # Highly complex reasoning with intricate relationships


class ProblemQuality(Enum):
    """Enumeration of problem quality levels."""
    EXCELLENT = 5     # Perfect logical consistency, clear explanation
    GOOD = 4          # Good logical consistency, adequate explanation
    ACCEPTABLE = 3    # Acceptable logical consistency, basic explanation
    POOR = 2          # Some logical issues, unclear explanation
    INVALID = 1       # Logical inconsistencies, invalid problem


@dataclass
class GeneratedProblem:
    """Data class representing a generated reasoning problem."""
    topic: str
    question: str
    choices: List[str]
    answer: str
    explanation: str
    difficulty: DifficultyLevel
    quality_score: float
    constraints: List[str]
    reasoning_steps: List[str]
    metadata: Dict[str, Any]
    generation_timestamp: str
    problem_id: str

    def to_dict(self) -> Dict[str, Any]:
        """Convert problem to dictionary format."""
        return {
            'topic': self.topic,
            'question': self.question,
            'choices': self.choices,
            'answer': self.answer,
            'explanation': self.explanation,
            'difficulty': self.difficulty.name,
            'quality_score': self.quality_score,
            'constraints': self.constraints,
            'reasoning_steps': self.reasoning_steps,
            'metadata': self.metadata,
            'generation_timestamp': self.generation_timestamp,
            'problem_id': self.problem_id
        }

    def to_competition_format(self) -> Dict[str, Any]:
        """Convert to competition-required format."""
        return {
            'topic': self.topic,
            'question': self.question,
            'choices': self.choices,
            'answer': self.answer,
            'explanation': self.explanation
        }


@dataclass
class GenerationConfig:
    """Configuration for problem generation."""
    difficulty_level: DifficultyLevel
    num_problems: int
    quality_threshold: float = 3.0
    max_attempts: int = 100
    seed: Optional[int] = None
    enable_validation: bool = True
    include_metadata: bool = True
    unique_problems_only: bool = True


class BaseGenerator(ABC):
    """
    Abstract base class for all problem generators.
    
    Provides common functionality for:
    - Problem generation with difficulty control
    - Quality validation and scoring
    - Constraint satisfaction
    - Uniqueness verification
    - Metadata tracking
    """

    def __init__(self, topic: str, config: Optional[GenerationConfig] = None):
        """
        Initialize the base generator.
        
        Args:
            topic: The topic/domain for problem generation
            config: Generation configuration
        """
        self.topic = topic
        self.config = config or GenerationConfig(
            difficulty_level=DifficultyLevel.INTERMEDIATE,
            num_problems=100
        )
        
        # Set random seed for reproducibility
        if self.config.seed is not None:
            random.seed(self.config.seed)
        
        # Track generated problems for uniqueness
        self.generated_problems: Set[str] = set()
        self.generation_stats = {
            'total_attempts': 0,
            'successful_generations': 0,
            'quality_failures': 0,
            'uniqueness_failures': 0,
            'validation_failures': 0
        }
        
        logger.info(f"Initialized {self.__class__.__name__} for topic: {topic}")

    @abstractmethod
    def generate_problem_core(self, difficulty: DifficultyLevel) -> GeneratedProblem:
        """
        Core problem generation method to be implemented by subclasses.
        
        Args:
            difficulty: Target difficulty level
            
        Returns:
            Generated problem instance
        """
        pass

    @abstractmethod
    def validate_problem_logic(self, problem: GeneratedProblem) -> Tuple[bool, List[str]]:
        """
        Validate the logical consistency of a generated problem.
        
        Args:
            problem: Problem to validate
            
        Returns:
            Tuple of (is_valid, error_messages)
        """
        pass

    @abstractmethod
    def calculate_difficulty_score(self, problem: GeneratedProblem) -> float:
        """
        Calculate the actual difficulty score of a problem.
        
        Args:
            problem: Problem to score
            
        Returns:
            Difficulty score (1.0 = easiest, 5.0 = hardest)
        """
        pass

    def generate_problem_id(self, problem: GeneratedProblem) -> str:
        """Generate a unique ID for the problem based on its content."""
        content = f"{problem.question}{problem.choices}{problem.answer}"
        return hashlib.md5(content.encode()).hexdigest()[:12]

    def is_problem_unique(self, problem: GeneratedProblem) -> bool:
        """Check if the problem is unique among generated problems."""
        problem_signature = f"{problem.question}|{problem.answer}"
        signature_hash = hashlib.md5(problem_signature.encode()).hexdigest()
        
        if signature_hash in self.generated_problems:
            return False
        
        self.generated_problems.add(signature_hash)
        return True

    def calculate_quality_score(self, problem: GeneratedProblem) -> float:
        """
        Calculate overall quality score for a problem.
        
        Considers:
        - Logical consistency
        - Explanation clarity
        - Difficulty appropriateness
        - Constraint satisfaction
        """
        # Validate logical consistency
        is_valid, errors = self.validate_problem_logic(problem)
        if not is_valid:
            return 1.0  # Invalid problems get lowest score
        
        # Base score for valid problems
        quality_score = 3.0
        
        # Bonus for clear explanation
        if len(problem.explanation) > 50 and len(problem.explanation) < 200:
            quality_score += 0.5
        
        # Bonus for appropriate number of reasoning steps
        if 2 <= len(problem.reasoning_steps) <= 5:
            quality_score += 0.3
        
        # Bonus for appropriate constraint complexity
        constraint_complexity = len(problem.constraints)
        if problem.difficulty == DifficultyLevel.BEGINNER and constraint_complexity <= 2:
            quality_score += 0.2
        elif problem.difficulty == DifficultyLevel.INTERMEDIATE and 2 <= constraint_complexity <= 4:
            quality_score += 0.2
        elif problem.difficulty == DifficultyLevel.ADVANCED and 3 <= constraint_complexity <= 6:
            quality_score += 0.2
        elif problem.difficulty == DifficultyLevel.EXPERT and constraint_complexity >= 4:
            quality_score += 0.2
        
        # Ensure score is within valid range
        return min(5.0, max(1.0, quality_score))

    def generate_choices(self, correct_answer: str, distractors: List[str]) -> List[str]:
        """
        Generate multiple choice options with the correct answer randomly placed.
        
        Args:
            correct_answer: The correct answer
            distractors: List of incorrect but plausible options
            
        Returns:
            List of formatted choices
        """
        # Ensure we have exactly 3 distractors
        if len(distractors) < 3:
            # Generate additional generic distractors if needed
            while len(distractors) < 3:
                distractors.append(f"Option {len(distractors) + 1}")
        elif len(distractors) > 3:
            distractors = distractors[:3]
        
        # Create all options
        all_options = [correct_answer] + distractors
        random.shuffle(all_options)
        
        # Format as A), B), C), D)
        choices = []
        correct_letter = None
        
        for i, option in enumerate(all_options):
            letter = chr(65 + i)  # A, B, C, D
            choices.append(f"{letter}) {option}")
            if option == correct_answer:
                correct_letter = letter
        
        return choices, correct_letter

    def generate_single_problem(self, difficulty: DifficultyLevel) -> Optional[GeneratedProblem]:
        """
        Generate a single problem with quality validation.
        
        Args:
            difficulty: Target difficulty level
            
        Returns:
            Generated problem or None if generation failed
        """
        max_attempts = self.config.max_attempts
        
        for attempt in range(max_attempts):
            self.generation_stats['total_attempts'] += 1
            
            try:
                # Generate core problem
                problem = self.generate_problem_core(difficulty)
                
                # Add metadata
                problem.generation_timestamp = datetime.now().isoformat()
                problem.problem_id = self.generate_problem_id(problem)
                
                # Validate quality
                if self.config.enable_validation:
                    is_valid, errors = self.validate_problem_logic(problem)
                    if not is_valid:
                        self.generation_stats['validation_failures'] += 1
                        logger.debug(f"Validation failed: {errors}")
                        continue
                
                # Calculate quality score
                quality_score = self.calculate_quality_score(problem)
                problem.quality_score = quality_score
                
                if quality_score < self.config.quality_threshold:
                    self.generation_stats['quality_failures'] += 1
                    continue
                
                # Check uniqueness
                if self.config.unique_problems_only and not self.is_problem_unique(problem):
                    self.generation_stats['uniqueness_failures'] += 1
                    continue
                
                # Success!
                self.generation_stats['successful_generations'] += 1
                logger.debug(f"Generated problem with quality score: {quality_score}")
                return problem
                
            except Exception as e:
                logger.warning(f"Problem generation attempt {attempt + 1} failed: {e}")
                continue
        
        logger.warning(f"Failed to generate problem after {max_attempts} attempts")
        return None

    def generate_problems(self, num_problems: int, difficulty: DifficultyLevel) -> List[GeneratedProblem]:
        """
        Generate multiple problems of specified difficulty.
        
        Args:
            num_problems: Number of problems to generate
            difficulty: Target difficulty level
            
        Returns:
            List of generated problems
        """
        problems = []
        
        logger.info(f"Generating {num_problems} {difficulty.name} problems for {self.topic}")
        
        for i in range(num_problems):
            problem = self.generate_single_problem(difficulty)
            if problem:
                problems.append(problem)
                if (i + 1) % 10 == 0:
                    logger.info(f"Generated {i + 1}/{num_problems} problems")
            else:
                logger.warning(f"Failed to generate problem {i + 1}")
        
        logger.info(f"Successfully generated {len(problems)}/{num_problems} problems")
        self.log_generation_stats()
        
        return problems

    def generate_curriculum_dataset(self, problems_per_level: int = 25) -> List[GeneratedProblem]:
        """
        Generate a complete curriculum dataset with all difficulty levels.
        
        Args:
            problems_per_level: Number of problems per difficulty level
            
        Returns:
            List of problems across all difficulty levels
        """
        all_problems = []
        
        for difficulty in DifficultyLevel:
            logger.info(f"Generating {difficulty.name} level problems...")
            problems = self.generate_problems(problems_per_level, difficulty)
            all_problems.extend(problems)
        
        logger.info(f"Generated complete curriculum dataset: {len(all_problems)} total problems")
        return all_problems

    def log_generation_stats(self):
        """Log generation statistics."""
        stats = self.generation_stats
        total = stats['total_attempts']
        success_rate = (stats['successful_generations'] / total * 100) if total > 0 else 0
        
        logger.info(f"Generation Statistics:")
        logger.info(f"  Total attempts: {total}")
        logger.info(f"  Successful generations: {stats['successful_generations']}")
        logger.info(f"  Success rate: {success_rate:.1f}%")
        logger.info(f"  Quality failures: {stats['quality_failures']}")
        logger.info(f"  Uniqueness failures: {stats['uniqueness_failures']}")
        logger.info(f"  Validation failures: {stats['validation_failures']}")

    def save_problems(self, problems: List[GeneratedProblem], filepath: str, format: str = 'json'):
        """
        Save generated problems to file.
        
        Args:
            problems: List of problems to save
            filepath: Output file path
            format: Output format ('json' or 'competition')
        """
        if format == 'competition':
            # Save in competition format
            data = [problem.to_competition_format() for problem in problems]
        else:
            # Save in full format with metadata
            data = [problem.to_dict() for problem in problems]
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Saved {len(problems)} problems to {filepath}")

    def load_problems(self, filepath: str) -> List[GeneratedProblem]:
        """
        Load problems from file.
        
        Args:
            filepath: Input file path
            
        Returns:
            List of loaded problems
        """
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        problems = []
        for item in data:
            if 'difficulty' in item and isinstance(item['difficulty'], str):
                # Convert string difficulty back to enum
                item['difficulty'] = DifficultyLevel[item['difficulty']]
            
            # Create GeneratedProblem instance
            problem = GeneratedProblem(**item)
            problems.append(problem)
        
        logger.info(f"Loaded {len(problems)} problems from {filepath}")
        return problems

