"""
Direct Preference Optimization (DPO) Trainer

This module implements the DPO training algorithm with self-training integration
for logical reasoning tasks. DPO provides a stable alternative to RLHF by
directly optimizing the policy using preference data.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
import logging
from transformers import (
    AutoModelForCausalLM, 
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling
)
from torch.utils.data import DataLoader, Dataset
import wandb

from .training_config import DPOConfig
from .training_utils import TrainingMetrics, ModelEvaluator
from .optimization_utils import AMDOptimizer, MemoryOptimizer

logger = logging.getLogger(__name__)


@dataclass
class DPOBatch:
    """Batch data structure for DPO training."""
    chosen_input_ids: torch.Tensor
    chosen_attention_mask: torch.Tensor
    rejected_input_ids: torch.Tensor
    rejected_attention_mask: torch.Tensor
    chosen_labels: torch.Tensor
    rejected_labels: torch.Tensor
    
    def to(self, device: torch.device):
        """Move batch to device."""
        return DPOBatch(
            chosen_input_ids=self.chosen_input_ids.to(device),
            chosen_attention_mask=self.chosen_attention_mask.to(device),
            rejected_input_ids=self.rejected_input_ids.to(device),
            rejected_attention_mask=self.rejected_attention_mask.to(device),
            chosen_labels=self.chosen_labels.to(device),
            rejected_labels=self.rejected_labels.to(device)
        )


class DPOLoss(nn.Module):
    """DPO loss function."""
    
    def __init__(self, config: DPOConfig):
        super().__init__()
        self.config = config
        self.beta = config.beta
        self.label_smoothing = config.label_smoothing
        self.loss_type = config.loss_type
        
    def forward(self, 
                policy_chosen_logps: torch.Tensor,
                policy_rejected_logps: torch.Tensor,
                reference_chosen_logps: torch.Tensor,
                reference_rejected_logps: torch.Tensor) -> Dict[str, torch.Tensor]:
        """
        Compute DPO loss.
        
        Args:
            policy_chosen_logps: Log probabilities of chosen responses under policy
            policy_rejected_logps: Log probabilities of rejected responses under policy
            reference_chosen_logps: Log probabilities of chosen responses under reference
            reference_rejected_logps: Log probabilities of rejected responses under reference
            
        Returns:
            Dictionary of loss components
        """
        # Compute log ratios
        policy_logratios = policy_chosen_logps - policy_rejected_logps
        reference_logratios = reference_chosen_logps - reference_rejected_logps
        
        # Compute DPO loss
        if self.loss_type == "sigmoid":
            logits = self.beta * (policy_logratios - reference_logratios)
            
            if self.label_smoothing > 0:
                # Apply label smoothing
                loss = -F.logsigmoid(logits) * (1 - self.label_smoothing) - F.logsigmoid(-logits) * self.label_smoothing
            else:
                loss = -F.logsigmoid(logits)
        
        elif self.loss_type == "hinge":
            # Hinge loss variant
            logits = self.beta * (policy_logratios - reference_logratios)
            loss = torch.clamp(1 - logits, min=0)
        
        elif self.loss_type == "ipo":
            # Identity Preference Optimization (IPO) loss
            logits = self.beta * (policy_logratios - reference_logratios)
            loss = (logits - 1/(2 * self.beta)) ** 2
        
        else:
            raise ValueError(f"Unknown loss type: {self.loss_type}")
        
        # Compute additional metrics
        chosen_rewards = self.beta * (policy_chosen_logps - reference_chosen_logps)
        rejected_rewards = self.beta * (policy_rejected_logps - reference_rejected_logps)
        reward_accuracies = (chosen_rewards > rejected_rewards).float()
        
        return {
            'loss': loss.mean(),
            'policy_logratios': policy_logratios,
            'reference_logratios': reference_logratios,
            'chosen_rewards': chosen_rewards,
            'rejected_rewards': rejected_rewards,
            'reward_accuracies': reward_accuracies,
            'reward_margin': (chosen_rewards - rejected_rewards).mean()
        }


class DPODataset(Dataset):
    """Dataset for DPO training with preference pairs."""
    
    def __init__(self, 
                 data: List[Dict[str, Any]], 
                 tokenizer: AutoTokenizer,
                 config: DPOConfig):
        self.data = data
        self.tokenizer = tokenizer
        self.config = config
        
        # Preprocess data
        self.processed_data = self._preprocess_data()
    
    def _preprocess_data(self) -> List[Dict[str, Any]]:
        """Preprocess the preference data."""
        processed = []
        
        for item in self.data:
            # Extract components
            prompt = item['prompt'] if 'prompt' in item else item['question']
            chosen = item['chosen'] if 'chosen' in item else item['correct_answer']
            rejected = item['rejected'] if 'rejected' in item else item['incorrect_answer']
            
            # Tokenize chosen response
            chosen_text = f"{prompt}\n\nAnswer: {chosen}"
            chosen_encoding = self.tokenizer(
                chosen_text,
                max_length=self.config.max_length,
                padding='max_length',
                truncation=True,
                return_tensors='pt'
            )
            
            # Tokenize rejected response
            rejected_text = f"{prompt}\n\nAnswer: {rejected}"
            rejected_encoding = self.tokenizer(
                rejected_text,
                max_length=self.config.max_length,
                padding='max_length',
                truncation=True,
                return_tensors='pt'
            )
            
            # Create labels (mask prompt tokens)
            prompt_encoding = self.tokenizer(
                prompt,
                max_length=self.config.max_prompt_length,
                truncation=True,
                return_tensors='pt'
            )
            prompt_length = prompt_encoding['input_ids'].shape[1]
            
            # Create labels for chosen response
            chosen_labels = chosen_encoding['input_ids'].clone()
            chosen_labels[:, :prompt_length] = -100  # Mask prompt tokens
            
            # Create labels for rejected response
            rejected_labels = rejected_encoding['input_ids'].clone()
            rejected_labels[:, :prompt_length] = -100  # Mask prompt tokens
            
            processed_item = {
                'chosen_input_ids': chosen_encoding['input_ids'].squeeze(0),
                'chosen_attention_mask': chosen_encoding['attention_mask'].squeeze(0),
                'rejected_input_ids': rejected_encoding['input_ids'].squeeze(0),
                'rejected_attention_mask': rejected_encoding['attention_mask'].squeeze(0),
                'chosen_labels': chosen_labels.squeeze(0),
                'rejected_labels': rejected_labels.squeeze(0),
                'metadata': item.get('metadata', {})
            }
            
            processed.append(processed_item)
        
        return processed
    
    def __len__(self) -> int:
        return len(self.processed_data)
    
    def __getitem__(self, idx: int) -> Dict[str, Any]:
        return self.processed_data[idx]


class DPOTrainer:
    """
    Direct Preference Optimization Trainer.
    
    Implements the DPO algorithm with self-training capabilities
    and AMD MI300x optimizations.
    """
    
    def __init__(self, 
                 config: DPOConfig,
                 model: Optional[AutoModelForCausalLM] = None,
                 tokenizer: Optional[AutoTokenizer] = None,
                 train_dataset: Optional[Dataset] = None,
                 eval_dataset: Optional[Dataset] = None):
        """
        Initialize DPO trainer.
        
        Args:
            config: DPO training configuration
            model: Pre-trained model (will be loaded if None)
            tokenizer: Tokenizer (will be loaded if None)
            train_dataset: Training dataset
            eval_dataset: Evaluation dataset
        """
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Initialize model and tokenizer
        self.model = model or self._load_model()
        self.tokenizer = tokenizer or self._load_tokenizer()
        
        # Create reference model
        self.ref_model = self._create_reference_model()
        
        # Initialize datasets
        self.train_dataset = train_dataset
        self.eval_dataset = eval_dataset
        
        # Initialize loss function
        self.loss_fn = DPOLoss(config)
        
        # Initialize optimizer
        self.optimizer = self._create_optimizer()
        self.scheduler = self._create_scheduler()
        
        # Initialize metrics tracking
        self.metrics = TrainingMetrics()
        self.evaluator = ModelEvaluator(self.model, self.tokenizer)
        
        # AMD optimizations
        if hasattr(config, 'use_rocm_optimizations') and config.use_rocm_optimizations:
            self.amd_optimizer = AMDOptimizer(config)
            self.memory_optimizer = MemoryOptimizer(config)
            self._apply_amd_optimizations()
        
        logger.info("DPO Trainer initialized")
    
    def _load_model(self) -> AutoModelForCausalLM:
        """Load the pre-trained model."""
        model = AutoModelForCausalLM.from_pretrained(
            self.config.model_name,
            revision=self.config.model_revision,
            torch_dtype=getattr(torch, self.config.torch_dtype),
            attn_implementation=self.config.attn_implementation,
            device_map="auto",
            low_cpu_mem_usage=True,
            use_cache=False  # Disable for training
        )
        
        # Enable gradient checkpointing for memory efficiency
        if self.config.gradient_checkpointing:
            model.gradient_checkpointing_enable()
        
        return model
    
    def _load_tokenizer(self) -> AutoTokenizer:
        """Load the tokenizer."""
        tokenizer = AutoTokenizer.from_pretrained(
            self.config.model_name,
            revision=self.config.model_revision
        )
        
        # Add padding token if not present
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        return tokenizer
    
    def _create_reference_model(self) -> Optional[AutoModelForCausalLM]:
        """Create reference model for DPO."""
        if self.config.reference_free:
            return None
        
        if self.config.reference_model_path:
            ref_model = AutoModelForCausalLM.from_pretrained(
                self.config.reference_model_path,
                torch_dtype=getattr(torch, self.config.torch_dtype),
                attn_implementation=self.config.attn_implementation,
                device_map="auto",
                low_cpu_mem_usage=True,
                use_cache=False
            )
        else:
            # Use the same model as reference
            ref_model = AutoModelForCausalLM.from_pretrained(
                self.config.model_name,
                revision=self.config.model_revision,
                torch_dtype=getattr(torch, self.config.torch_dtype),
                attn_implementation=self.config.attn_implementation,
                device_map="auto",
                low_cpu_mem_usage=True,
                use_cache=False
            )
        
        # Freeze reference model
        for param in ref_model.parameters():
            param.requires_grad = False
        
        ref_model.eval()
        return ref_model
    
    def _create_optimizer(self) -> torch.optim.Optimizer:
        """Create optimizer."""
        if self.config.optimizer_type.value == "adamw":
            return torch.optim.AdamW(
                self.model.parameters(),
                lr=self.config.learning_rate,
                betas=(self.config.adam_beta1, self.config.adam_beta2),
                eps=self.config.adam_epsilon,
                weight_decay=self.config.weight_decay
            )
        else:
            raise ValueError(f"Unsupported optimizer: {self.config.optimizer_type}")
    
    def _create_scheduler(self) -> torch.optim.lr_scheduler._LRScheduler:
        """Create learning rate scheduler."""
        if self.config.lr_scheduler_type.value == "cosine":
            return torch.optim.lr_scheduler.CosineAnnealingLR(
                self.optimizer,
                T_max=self.config.num_train_epochs,
                **self.config.lr_scheduler_kwargs
            )
        elif self.config.lr_scheduler_type.value == "linear":
            return torch.optim.lr_scheduler.LinearLR(
                self.optimizer,
                **self.config.lr_scheduler_kwargs
            )
        else:
            return torch.optim.lr_scheduler.ConstantLR(self.optimizer)
    
    def _apply_amd_optimizations(self):
        """Apply AMD MI300x specific optimizations."""
        # Memory optimizations
        if hasattr(torch.backends, 'cuda') and torch.backends.cuda.is_available():
            torch.backends.cuda.matmul.allow_tf32 = self.config.tf32
            torch.backends.cudnn.allow_tf32 = self.config.tf32
        
        # ROCm specific optimizations
        if hasattr(torch, 'cuda') and torch.cuda.is_available():
            # Set memory fraction
            if hasattr(self.config, 'rocm_memory_fraction'):
                torch.cuda.set_per_process_memory_fraction(self.config.rocm_memory_fraction)
            
            # Enable memory pool
            torch.cuda.empty_cache()
    
    def create_dataloader(self, dataset: Dataset, is_training: bool = True) -> DataLoader:
        """Create data loader for training or evaluation."""
        batch_size = (self.config.per_device_train_batch_size if is_training 
                     else self.config.per_device_eval_batch_size)
        
        return DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=is_training,
            num_workers=self.config.dataloader_num_workers,
            pin_memory=self.config.dataloader_pin_memory,
            collate_fn=self._collate_fn
        )
    
    def _collate_fn(self, batch: List[Dict[str, Any]]) -> DPOBatch:
        """Collate function for DPO batches."""
        chosen_input_ids = torch.stack([item['chosen_input_ids'] for item in batch])
        chosen_attention_mask = torch.stack([item['chosen_attention_mask'] for item in batch])
        rejected_input_ids = torch.stack([item['rejected_input_ids'] for item in batch])
        rejected_attention_mask = torch.stack([item['rejected_attention_mask'] for item in batch])
        chosen_labels = torch.stack([item['chosen_labels'] for item in batch])
        rejected_labels = torch.stack([item['rejected_labels'] for item in batch])
        
        return DPOBatch(
            chosen_input_ids=chosen_input_ids,
            chosen_attention_mask=chosen_attention_mask,
            rejected_input_ids=rejected_input_ids,
            rejected_attention_mask=rejected_attention_mask,
            chosen_labels=chosen_labels,
            rejected_labels=rejected_labels
        )
    
    def compute_log_probs(self, 
                         model: AutoModelForCausalLM,
                         input_ids: torch.Tensor,
                         attention_mask: torch.Tensor,
                         labels: torch.Tensor) -> torch.Tensor:
        """Compute log probabilities for the given inputs."""
        with torch.cuda.amp.autocast(enabled=self.config.bf16):
            outputs = model(
                input_ids=input_ids,
                attention_mask=attention_mask,
                return_dict=True
            )
            logits = outputs.logits
        
        # Shift logits and labels for next token prediction
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = labels[..., 1:].contiguous()
        
        # Compute log probabilities
        log_probs = F.log_softmax(shift_logits, dim=-1)
        
        # Gather log probabilities for the actual tokens
        gathered_log_probs = log_probs.gather(dim=-1, index=shift_labels.unsqueeze(-1)).squeeze(-1)
        
        # Mask out padding tokens
        mask = (shift_labels != -100).float()
        gathered_log_probs = gathered_log_probs * mask
        
        # Sum log probabilities for each sequence
        sequence_log_probs = gathered_log_probs.sum(dim=-1)
        
        return sequence_log_probs
    
    def train_step(self, batch: DPOBatch) -> Dict[str, float]:
        """Perform a single training step."""
        self.model.train()
        batch = batch.to(self.device)
        
        # Compute log probabilities for chosen responses
        policy_chosen_logps = self.compute_log_probs(
            self.model, batch.chosen_input_ids, batch.chosen_attention_mask, batch.chosen_labels
        )
        
        # Compute log probabilities for rejected responses
        policy_rejected_logps = self.compute_log_probs(
            self.model, batch.rejected_input_ids, batch.rejected_attention_mask, batch.rejected_labels
        )
        
        # Compute reference log probabilities
        if self.ref_model is not None:
            with torch.no_grad():
                reference_chosen_logps = self.compute_log_probs(
                    self.ref_model, batch.chosen_input_ids, batch.chosen_attention_mask, batch.chosen_labels
                )
                reference_rejected_logps = self.compute_log_probs(
                    self.ref_model, batch.rejected_input_ids, batch.rejected_attention_mask, batch.rejected_labels
                )
        else:
            # Reference-free DPO
            reference_chosen_logps = torch.zeros_like(policy_chosen_logps)
            reference_rejected_logps = torch.zeros_like(policy_rejected_logps)
        
        # Compute DPO loss
        loss_dict = self.loss_fn(
            policy_chosen_logps=policy_chosen_logps,
            policy_rejected_logps=policy_rejected_logps,
            reference_chosen_logps=reference_chosen_logps,
            reference_rejected_logps=reference_rejected_logps
        )
        
        # Backward pass
        loss = loss_dict['loss']
        loss.backward()
        
        # Gradient clipping
        if self.config.max_grad_norm > 0:
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), self.config.max_grad_norm)
        
        # Optimizer step
        self.optimizer.step()
        self.scheduler.step()
        self.optimizer.zero_grad()
        
        # Convert tensors to floats for logging
        step_metrics = {k: v.mean().item() if torch.is_tensor(v) else v for k, v in loss_dict.items()}
        step_metrics['learning_rate'] = self.scheduler.get_last_lr()[0]
        
        return step_metrics
    
    def evaluate(self, eval_dataloader: DataLoader) -> Dict[str, float]:
        """Evaluate the model."""
        self.model.eval()
        eval_metrics = []
        
        with torch.no_grad():
            for batch in eval_dataloader:
                batch = batch.to(self.device)
                
                # Compute log probabilities
                policy_chosen_logps = self.compute_log_probs(
                    self.model, batch.chosen_input_ids, batch.chosen_attention_mask, batch.chosen_labels
                )
                policy_rejected_logps = self.compute_log_probs(
                    self.model, batch.rejected_input_ids, batch.rejected_attention_mask, batch.rejected_labels
                )
                
                if self.ref_model is not None:
                    reference_chosen_logps = self.compute_log_probs(
                        self.ref_model, batch.chosen_input_ids, batch.chosen_attention_mask, batch.chosen_labels
                    )
                    reference_rejected_logps = self.compute_log_probs(
                        self.ref_model, batch.rejected_input_ids, batch.rejected_attention_mask, batch.rejected_labels
                    )
                else:
                    reference_chosen_logps = torch.zeros_like(policy_chosen_logps)
                    reference_rejected_logps = torch.zeros_like(policy_rejected_logps)
                
                # Compute metrics
                loss_dict = self.loss_fn(
                    policy_chosen_logps=policy_chosen_logps,
                    policy_rejected_logps=policy_rejected_logps,
                    reference_chosen_logps=reference_chosen_logps,
                    reference_rejected_logps=reference_rejected_logps
                )
                
                batch_metrics = {k: v.mean().item() if torch.is_tensor(v) else v for k, v in loss_dict.items()}
                eval_metrics.append(batch_metrics)
        
        # Aggregate metrics
        aggregated_metrics = {}
        for key in eval_metrics[0].keys():
            aggregated_metrics[f"eval_{key}"] = np.mean([m[key] for m in eval_metrics])
        
        return aggregated_metrics
    
    def train(self, 
              train_dataset: Optional[Dataset] = None,
              eval_dataset: Optional[Dataset] = None,
              num_epochs: Optional[int] = None) -> Dict[str, Any]:
        """
        Train the model using DPO.
        
        Args:
            train_dataset: Training dataset
            eval_dataset: Evaluation dataset
            num_epochs: Number of training epochs
            
        Returns:
            Training results and metrics
        """
        # Use provided datasets or fall back to instance datasets
        train_dataset = train_dataset or self.train_dataset
        eval_dataset = eval_dataset or self.eval_dataset
        num_epochs = num_epochs or self.config.num_train_epochs
        
        if train_dataset is None:
            raise ValueError("No training dataset provided")
        
        # Create data loaders
        train_dataloader = self.create_dataloader(train_dataset, is_training=True)
        eval_dataloader = self.create_dataloader(eval_dataset, is_training=False) if eval_dataset else None
        
        # Initialize tracking
        global_step = 0
        best_metric = float('-inf')
        training_history = []
        
        logger.info(f"Starting DPO training for {num_epochs} epochs")
        logger.info(f"Training dataset size: {len(train_dataset)}")
        logger.info(f"Batch size: {self.config.per_device_train_batch_size}")
        logger.info(f"Loss type: {self.config.loss_type}")
        
        for epoch in range(num_epochs):
            epoch_metrics = []
            
            for step, batch in enumerate(train_dataloader):
                # Training step
                step_metrics = self.train_step(batch)
                epoch_metrics.append(step_metrics)
                global_step += 1
                
                # Logging
                if global_step % self.config.logging_steps == 0:
                    avg_metrics = {k: np.mean([m[k] for m in epoch_metrics[-self.config.logging_steps:]])
                                 for k in step_metrics.keys()}
                    
                    logger.info(f"Step {global_step}: {avg_metrics}")
                    
                    if self.config.enable_wandb:
                        wandb.log(avg_metrics, step=global_step)
                
                # Evaluation
                if (eval_dataloader and global_step % self.config.eval_steps == 0):
                    eval_metrics = self.evaluate(eval_dataloader)
                    logger.info(f"Evaluation at step {global_step}: {eval_metrics}")
                    
                    if self.config.enable_wandb:
                        wandb.log(eval_metrics, step=global_step)
                    
                    # Save best model
                    current_metric = eval_metrics.get(f"eval_{self.config.metric_for_best_model}", 0)
                    if current_metric > best_metric:
                        best_metric = current_metric
                        self.save_model(f"{self.config.output_dir}/best_model")
                
                # Save checkpoint
                if global_step % self.config.save_steps == 0:
                    self.save_checkpoint(f"{self.config.output_dir}/checkpoint-{global_step}")
            
            # End of epoch evaluation
            if eval_dataloader:
                eval_metrics = self.evaluate(eval_dataloader)
                logger.info(f"End of epoch {epoch + 1}: {eval_metrics}")
                
                training_history.append({
                    'epoch': epoch + 1,
                    'train_metrics': {k: np.mean([m[k] for m in epoch_metrics]) for k in epoch_metrics[0].keys()},
                    'eval_metrics': eval_metrics
                })
        
        # Final model save
        self.save_model(f"{self.config.output_dir}/final_model")
        
        logger.info("DPO training completed")
        
        return {
            'training_history': training_history,
            'best_metric': best_metric,
            'final_metrics': training_history[-1] if training_history else {}
        }
    
    def save_model(self, output_dir: str):
        """Save the trained model."""
        self.model.save_pretrained(output_dir, safe_serialization=self.config.save_safetensors)
        self.tokenizer.save_pretrained(output_dir)
        logger.info(f"Model saved to {output_dir}")
    
    def save_checkpoint(self, output_dir: str):
        """Save training checkpoint."""
        checkpoint = {
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'config': self.config.to_dict() if hasattr(self.config, 'to_dict') else self.config.__dict__
        }
        
        torch.save(checkpoint, f"{output_dir}/training_state.pt")
        self.save_model(output_dir)
        logger.info(f"Checkpoint saved to {output_dir}")
    
    def load_checkpoint(self, checkpoint_dir: str):
        """Load training checkpoint."""
        checkpoint = torch.load(f"{checkpoint_dir}/training_state.pt", map_location=self.device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        
        logger.info(f"Checkpoint loaded from {checkpoint_dir}")


def create_dpo_dataset(data: List[Dict[str, Any]], 
                      tokenizer: AutoTokenizer,
                      config: DPOConfig) -> DPODataset:
    """Create a DPO dataset from preference data."""
    return DPODataset(data, tokenizer, config)

