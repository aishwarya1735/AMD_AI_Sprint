"""
Training Utilities

This module provides comprehensive utilities for training including metrics
tracking, model evaluation, and performance monitoring for logical reasoning tasks.
"""

import torch
import torch.nn.functional as F
import numpy as np
import json
import time
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass, field
from collections import defaultdict
import logging
from transformers import AutoModelForCausalLM, AutoTokenizer
from sklearn.metrics import accuracy_score, precision_recall_fscore_support
import wandb

logger = logging.getLogger(__name__)


@dataclass
class TrainingMetrics:
    """Comprehensive training metrics tracking."""
    
    # Loss metrics
    total_loss: List[float] = field(default_factory=list)
    policy_loss: List[float] = field(default_factory=list)
    value_loss: List[float] = field(default_factory=list)
    kl_penalty: List[float] = field(default_factory=list)
    
    # Performance metrics
    accuracy: List[float] = field(default_factory=list)
    reward_accuracy: List[float] = field(default_factory=list)
    reward_margin: List[float] = field(default_factory=list)
    
    # Training dynamics
    learning_rates: List[float] = field(default_factory=list)
    gradient_norms: List[float] = field(default_factory=list)
    
    # Timing metrics
    step_times: List[float] = field(default_factory=list)
    epoch_times: List[float] = field(default_factory=list)
    
    # Memory metrics
    memory_usage: List[float] = field(default_factory=list)
    peak_memory: List[float] = field(default_factory=list)
    
    def update(self, metrics: Dict[str, float]):
        """Update metrics with new values."""
        for key, value in metrics.items():
            if hasattr(self, key) and isinstance(getattr(self, key), list):
                getattr(self, key).append(value)
    
    def get_latest(self, metric_name: str, n: int = 1) -> List[float]:
        """Get the latest n values of a metric."""
        if hasattr(self, metric_name):
            metric_list = getattr(self, metric_name)
            return metric_list[-n:] if metric_list else []
        return []
    
    def get_average(self, metric_name: str, n: int = 10) -> float:
        """Get the average of the latest n values of a metric."""
        latest_values = self.get_latest(metric_name, n)
        return np.mean(latest_values) if latest_values else 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metrics to dictionary."""
        return {
            'total_loss': self.total_loss,
            'policy_loss': self.policy_loss,
            'value_loss': self.value_loss,
            'kl_penalty': self.kl_penalty,
            'accuracy': self.accuracy,
            'reward_accuracy': self.reward_accuracy,
            'reward_margin': self.reward_margin,
            'learning_rates': self.learning_rates,
            'gradient_norms': self.gradient_norms,
            'step_times': self.step_times,
            'epoch_times': self.epoch_times,
            'memory_usage': self.memory_usage,
            'peak_memory': self.peak_memory
        }


class ModelEvaluator:
    """Comprehensive model evaluation for logical reasoning tasks."""
    
    def __init__(self, 
                 model: AutoModelForCausalLM,
                 tokenizer: AutoTokenizer,
                 device: Optional[torch.device] = None):
        self.model = model
        self.tokenizer = tokenizer
        self.device = device or torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Evaluation metrics
        self.metrics_history = defaultdict(list)
        
    def compute_batch_metrics(self, 
                            logits: torch.Tensor,
                            labels: torch.Tensor,
                            attention_mask: torch.Tensor) -> Dict[str, float]:
        """Compute metrics for a batch of predictions."""
        # Compute perplexity
        shift_logits = logits[..., :-1, :].contiguous()
        shift_labels = labels[..., 1:].contiguous()
        
        # Flatten for loss computation
        flat_logits = shift_logits.view(-1, shift_logits.size(-1))
        flat_labels = shift_labels.view(-1)
        
        # Compute cross-entropy loss
        loss = F.cross_entropy(flat_logits, flat_labels, ignore_index=-100, reduction='mean')
        perplexity = torch.exp(loss).item()
        
        # Compute accuracy
        predictions = torch.argmax(flat_logits, dim=-1)
        mask = flat_labels != -100
        correct = (predictions == flat_labels) & mask
        accuracy = correct.sum().float() / mask.sum().float()
        
        return {
            'loss': loss.item(),
            'perplexity': perplexity,
            'accuracy': accuracy.item()
        }
    
    def evaluate_reasoning_accuracy(self, 
                                  questions: List[str],
                                  correct_answers: List[str],
                                  max_length: int = 512,
                                  temperature: float = 0.1) -> Dict[str, float]:
        """
        Evaluate reasoning accuracy on a set of questions.
        
        Args:
            questions: List of questions to evaluate
            correct_answers: List of correct answers
            max_length: Maximum generation length
            temperature: Generation temperature
            
        Returns:
            Dictionary of evaluation metrics
        """
        self.model.eval()
        predictions = []
        
        with torch.no_grad():
            for question in questions:
                # Generate response
                response = self.generate_response(
                    question, 
                    max_length=max_length,
                    temperature=temperature
                )
                predictions.append(response)
        
        # Compute accuracy metrics
        exact_matches = sum(1 for pred, correct in zip(predictions, correct_answers) 
                          if self._normalize_answer(pred) == self._normalize_answer(correct))
        
        accuracy = exact_matches / len(questions)
        
        # Compute additional metrics
        partial_matches = sum(1 for pred, correct in zip(predictions, correct_answers)
                            if self._partial_match(pred, correct))
        partial_accuracy = partial_matches / len(questions)
        
        return {
            'exact_accuracy': accuracy,
            'partial_accuracy': partial_accuracy,
            'total_questions': len(questions),
            'exact_matches': exact_matches,
            'partial_matches': partial_matches
        }
    
    def generate_response(self, 
                         question: str,
                         max_length: int = 512,
                         temperature: float = 0.1,
                         top_p: float = 0.9) -> str:
        """Generate a response to a question."""
        # Prepare input
        prompt = f"{question}\n\nAnswer:"
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
        
        # Generate response
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=max_length,
                temperature=temperature,
                top_p=top_p,
                do_sample=temperature > 0,
                pad_token_id=self.tokenizer.eos_token_id,
                eos_token_id=self.tokenizer.eos_token_id
            )
        
        # Decode response
        response = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        
        # Extract answer part
        if "Answer:" in response:
            answer = response.split("Answer:")[-1].strip()
        else:
            answer = response.strip()
        
        return answer
    
    def _normalize_answer(self, answer: str) -> str:
        """Normalize answer for comparison."""
        # Remove extra whitespace and convert to lowercase
        normalized = answer.strip().lower()
        
        # Remove common prefixes
        prefixes = ["the answer is", "answer:", "the correct answer is"]
        for prefix in prefixes:
            if normalized.startswith(prefix):
                normalized = normalized[len(prefix):].strip()
        
        # Extract choice letter if present
        if len(normalized) >= 1 and normalized[0] in 'abcd':
            return normalized[0]
        
        return normalized
    
    def _partial_match(self, prediction: str, correct: str) -> bool:
        """Check if prediction partially matches the correct answer."""
        pred_norm = self._normalize_answer(prediction)
        correct_norm = self._normalize_answer(correct)
        
        # Check if correct answer is contained in prediction
        return correct_norm in pred_norm or pred_norm in correct_norm
    
    def evaluate_multiple_choice(self, 
                                questions: List[str],
                                choices: List[List[str]],
                                correct_answers: List[str]) -> Dict[str, float]:
        """
        Evaluate multiple choice questions.
        
        Args:
            questions: List of questions
            choices: List of choice lists for each question
            correct_answers: List of correct answer letters (A, B, C, D)
            
        Returns:
            Evaluation metrics
        """
        self.model.eval()
        predictions = []
        
        with torch.no_grad():
            for question, choice_list in zip(questions, choices):
                # Format question with choices
                formatted_question = self._format_multiple_choice(question, choice_list)
                
                # Generate response
                response = self.generate_response(formatted_question, max_length=50, temperature=0.0)
                
                # Extract choice
                predicted_choice = self._extract_choice(response)
                predictions.append(predicted_choice)
        
        # Compute accuracy
        correct_predictions = sum(1 for pred, correct in zip(predictions, correct_answers)
                                if pred.upper() == correct.upper())
        
        accuracy = correct_predictions / len(questions)
        
        # Compute per-choice accuracy
        choice_accuracy = {}
        for choice in ['A', 'B', 'C', 'D']:
            choice_questions = [i for i, ans in enumerate(correct_answers) if ans.upper() == choice]
            if choice_questions:
                choice_correct = sum(1 for i in choice_questions 
                                   if predictions[i].upper() == choice)
                choice_accuracy[choice] = choice_correct / len(choice_questions)
            else:
                choice_accuracy[choice] = 0.0
        
        return {
            'accuracy': accuracy,
            'total_questions': len(questions),
            'correct_predictions': correct_predictions,
            'choice_accuracy': choice_accuracy,
            'predictions': predictions
        }
    
    def _format_multiple_choice(self, question: str, choices: List[str]) -> str:
        """Format a multiple choice question."""
        formatted = f"{question}\n\n"
        for i, choice in enumerate(choices):
            letter = chr(ord('A') + i)
            formatted += f"{letter}. {choice}\n"
        formatted += "\nAnswer:"
        return formatted
    
    def _extract_choice(self, response: str) -> str:
        """Extract choice letter from response."""
        response = response.strip().upper()
        
        # Look for choice letters
        for char in response:
            if char in 'ABCD':
                return char
        
        # Default to A if no choice found
        return 'A'
    
    def compute_reasoning_metrics(self, 
                                eval_data: List[Dict[str, Any]]) -> Dict[str, float]:
        """
        Compute comprehensive reasoning metrics.
        
        Args:
            eval_data: List of evaluation examples with questions, answers, etc.
            
        Returns:
            Dictionary of reasoning metrics
        """
        # Separate by topic if available
        topic_metrics = defaultdict(list)
        overall_metrics = []
        
        for item in eval_data:
            question = item['question']
            correct_answer = item['answer']
            topic = item.get('topic', 'general')
            
            # Generate prediction
            prediction = self.generate_response(question)
            
            # Compute metrics
            exact_match = self._normalize_answer(prediction) == self._normalize_answer(correct_answer)
            partial_match = self._partial_match(prediction, correct_answer)
            
            metrics = {
                'exact_match': exact_match,
                'partial_match': partial_match
            }
            
            topic_metrics[topic].append(metrics)
            overall_metrics.append(metrics)
        
        # Aggregate metrics
        result = {}
        
        # Overall metrics
        result['overall_exact_accuracy'] = np.mean([m['exact_match'] for m in overall_metrics])
        result['overall_partial_accuracy'] = np.mean([m['partial_match'] for m in overall_metrics])
        
        # Topic-specific metrics
        for topic, metrics_list in topic_metrics.items():
            result[f'{topic}_exact_accuracy'] = np.mean([m['exact_match'] for m in metrics_list])
            result[f'{topic}_partial_accuracy'] = np.mean([m['partial_match'] for m in metrics_list])
        
        return result


class PerformanceMonitor:
    """Monitor training performance and system resources."""
    
    def __init__(self):
        self.start_time = time.time()
        self.step_times = []
        self.memory_usage = []
        
    def start_step(self):
        """Mark the start of a training step."""
        self.step_start_time = time.time()
    
    def end_step(self):
        """Mark the end of a training step and record metrics."""
        step_time = time.time() - self.step_start_time
        self.step_times.append(step_time)
        
        # Record memory usage if CUDA is available
        if torch.cuda.is_available():
            memory_used = torch.cuda.memory_allocated() / 1024**3  # GB
            self.memory_usage.append(memory_used)
    
    def get_performance_stats(self) -> Dict[str, float]:
        """Get current performance statistics."""
        stats = {}
        
        if self.step_times:
            stats['avg_step_time'] = np.mean(self.step_times[-100:])  # Last 100 steps
            stats['steps_per_second'] = 1.0 / stats['avg_step_time']
        
        if self.memory_usage:
            stats['avg_memory_usage'] = np.mean(self.memory_usage[-100:])
            stats['peak_memory_usage'] = max(self.memory_usage)
        
        stats['total_training_time'] = time.time() - self.start_time
        
        return stats


class MetricsLogger:
    """Advanced metrics logging with multiple backends."""
    
    def __init__(self, 
                 log_to_wandb: bool = True,
                 log_to_file: bool = True,
                 log_file: str = "training_metrics.json"):
        self.log_to_wandb = log_to_wandb
        self.log_to_file = log_to_file
        self.log_file = log_file
        
        self.metrics_history = []
        
        if self.log_to_wandb and wandb.run is None:
            logger.warning("Wandb logging enabled but no active run found")
    
    def log_metrics(self, 
                   metrics: Dict[str, float],
                   step: Optional[int] = None,
                   prefix: str = ""):
        """Log metrics to all configured backends."""
        # Add prefix if provided
        if prefix:
            metrics = {f"{prefix}_{k}": v for k, v in metrics.items()}
        
        # Add timestamp
        metrics['timestamp'] = time.time()
        if step is not None:
            metrics['step'] = step
        
        # Log to wandb
        if self.log_to_wandb and wandb.run is not None:
            wandb.log(metrics, step=step)
        
        # Log to file
        if self.log_to_file:
            self.metrics_history.append(metrics)
            with open(self.log_file, 'w') as f:
                json.dump(self.metrics_history, f, indent=2)
        
        # Log to console
        logger.info(f"Metrics: {metrics}")
    
    def log_model_performance(self, 
                            model_evaluator: ModelEvaluator,
                            eval_data: List[Dict[str, Any]],
                            step: Optional[int] = None):
        """Log comprehensive model performance metrics."""
        # Compute reasoning metrics
        reasoning_metrics = model_evaluator.compute_reasoning_metrics(eval_data)
        
        # Log metrics
        self.log_metrics(reasoning_metrics, step=step, prefix="eval")
    
    def save_final_report(self, output_path: str):
        """Save a final training report."""
        if not self.metrics_history:
            logger.warning("No metrics history to save")
            return
        
        # Compute summary statistics
        summary = {
            'total_steps': len(self.metrics_history),
            'training_duration': self.metrics_history[-1]['timestamp'] - self.metrics_history[0]['timestamp'],
            'final_metrics': self.metrics_history[-1],
            'best_metrics': {},
            'metrics_history': self.metrics_history
        }
        
        # Find best metrics
        metric_names = ['accuracy', 'eval_accuracy', 'reward_accuracy']
        for metric_name in metric_names:
            values = [m.get(metric_name) for m in self.metrics_history if metric_name in m]
            if values:
                best_value = max(values)
                best_step = next(i for i, m in enumerate(self.metrics_history) 
                               if m.get(metric_name) == best_value)
                summary['best_metrics'][metric_name] = {
                    'value': best_value,
                    'step': best_step
                }
        
        # Save report
        with open(output_path, 'w') as f:
            json.dump(summary, f, indent=2)
        
        logger.info(f"Final training report saved to {output_path}")


def compute_gradient_norm(model: torch.nn.Module) -> float:
    """Compute the gradient norm of a model."""
    total_norm = 0.0
    param_count = 0
    
    for param in model.parameters():
        if param.grad is not None:
            param_norm = param.grad.data.norm(2)
            total_norm += param_norm.item() ** 2
            param_count += 1
    
    if param_count > 0:
        total_norm = total_norm ** (1. / 2)
    
    return total_norm


def get_memory_usage() -> Dict[str, float]:
    """Get current memory usage statistics."""
    stats = {}
    
    if torch.cuda.is_available():
        stats['allocated_memory_gb'] = torch.cuda.memory_allocated() / 1024**3
        stats['reserved_memory_gb'] = torch.cuda.memory_reserved() / 1024**3
        stats['max_memory_gb'] = torch.cuda.max_memory_allocated() / 1024**3
    
    return stats


def log_system_info():
    """Log system information for debugging."""
    info = {
        'torch_version': torch.__version__,
        'cuda_available': torch.cuda.is_available(),
        'device_count': torch.cuda.device_count() if torch.cuda.is_available() else 0
    }
    
    if torch.cuda.is_available():
        info['cuda_version'] = torch.version.cuda
        info['device_name'] = torch.cuda.get_device_name(0)
        info['device_capability'] = torch.cuda.get_device_capability(0)
    
    logger.info(f"System info: {info}")
    return info

