"""
Reasoning Engine for Logical Reasoning Optimization

This module implements reasoning-aware inference strategies that optimize
generation for logical reasoning tasks, including step-by-step reasoning,
chain-of-thought prompting, and reasoning verification.
"""

import torch
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
import logging
import re
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig

logger = logging.getLogger(__name__)


@dataclass
class ReasoningConfig:
    """Configuration for reasoning engine."""
    
    # Reasoning strategy
    strategy: str = "step_by_step"  # "step_by_step", "chain_of_thought", "direct"
    max_steps: int = 10
    step_verification: bool = True
    
    # Step-by-step reasoning
    step_delimiter: str = "\nStep"
    reasoning_keywords: List[str] = None
    conclusion_keywords: List[str] = None
    
    # Chain-of-thought
    cot_prompt_template: str = "Let's think step by step."
    cot_verification: bool = True
    
    # Verification settings
    verification_threshold: float = 0.8
    self_consistency_checks: int = 3
    contradiction_detection: bool = True
    
    # Generation parameters
    reasoning_temperature: float = 0.3
    verification_temperature: float = 0.1
    max_reasoning_length: int = 1024
    
    def __post_init__(self):
        if self.reasoning_keywords is None:
            self.reasoning_keywords = [
                "because", "since", "therefore", "thus", "hence", "so",
                "given", "if", "then", "assuming", "suppose", "let"
            ]
        
        if self.conclusion_keywords is None:
            self.conclusion_keywords = [
                "therefore", "thus", "hence", "in conclusion", "finally",
                "the answer is", "result", "conclusion"
            ]


class ReasoningStep:
    """Represents a single reasoning step."""
    
    def __init__(self, 
                 step_id: int,
                 content: str,
                 confidence: float = 0.0,
                 verified: bool = False):
        self.step_id = step_id
        self.content = content
        self.confidence = confidence
        self.verified = verified
        self.dependencies = []  # Steps this step depends on
        self.contradictions = []  # Detected contradictions
    
    def __str__(self):
        return f"Step {self.step_id}: {self.content} (confidence: {self.confidence:.3f})"


class ReasoningChain:
    """Represents a chain of reasoning steps."""
    
    def __init__(self):
        self.steps = []
        self.conclusion = None
        self.overall_confidence = 0.0
        self.is_valid = True
        self.contradictions = []
    
    def add_step(self, step: ReasoningStep):
        """Add a reasoning step to the chain."""
        self.steps.append(step)
    
    def set_conclusion(self, conclusion: str, confidence: float = 0.0):
        """Set the conclusion of the reasoning chain."""
        self.conclusion = conclusion
        self.overall_confidence = confidence
    
    def validate_chain(self) -> bool:
        """Validate the reasoning chain for logical consistency."""
        # Check for contradictions
        for i, step1 in enumerate(self.steps):
            for j, step2 in enumerate(self.steps[i+1:], i+1):
                if self._detect_contradiction(step1.content, step2.content):
                    contradiction = f"Steps {i+1} and {j+1} contradict each other"
                    self.contradictions.append(contradiction)
                    step1.contradictions.append(j+1)
                    step2.contradictions.append(i+1)
        
        self.is_valid = len(self.contradictions) == 0
        return self.is_valid
    
    def _detect_contradiction(self, text1: str, text2: str) -> bool:
        """Detect if two text segments contradict each other."""
        # Simple contradiction detection based on negation patterns
        negation_patterns = [
            (r"is (\w+)", r"is not \1"),
            (r"(\w+) is true", r"\1 is false"),
            (r"(\w+) = (\w+)", r"\1 ≠ \2"),
            (r"(\w+) > (\w+)", r"\1 ≤ \2"),
            (r"(\w+) < (\w+)", r"\1 ≥ \2")
        ]
        
        text1_lower = text1.lower()
        text2_lower = text2.lower()
        
        for positive_pattern, negative_pattern in negation_patterns:
            if (re.search(positive_pattern, text1_lower) and 
                re.search(negative_pattern, text2_lower)):
                return True
            if (re.search(negative_pattern, text1_lower) and 
                re.search(positive_pattern, text2_lower)):
                return True
        
        return False
    
    def get_summary(self) -> Dict[str, Any]:
        """Get summary of the reasoning chain."""
        return {
            'num_steps': len(self.steps),
            'conclusion': self.conclusion,
            'overall_confidence': self.overall_confidence,
            'is_valid': self.is_valid,
            'contradictions': self.contradictions,
            'step_confidences': [step.confidence for step in self.steps]
        }


class StepByStepReasoner:
    """Implements step-by-step reasoning strategy."""
    
    def __init__(self, 
                 model: AutoModelForCausalLM,
                 tokenizer: AutoTokenizer,
                 config: ReasoningConfig):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
    
    def generate_reasoning(self, 
                         prompt: str,
                         generation_config: GenerationConfig) -> ReasoningChain:
        """Generate step-by-step reasoning for a prompt."""
        reasoning_chain = ReasoningChain()
        
        # Modify prompt to encourage step-by-step reasoning
        step_prompt = f"{prompt}\n\nLet me solve this step by step:\n\nStep 1:"
        
        current_prompt = step_prompt
        step_count = 0
        
        while step_count < self.config.max_steps:
            # Generate next step
            step_content = self._generate_step(current_prompt, generation_config)
            
            if not step_content or self._is_conclusion(step_content):
                # Reached conclusion
                if step_content:
                    reasoning_chain.set_conclusion(step_content, self._compute_confidence(step_content))
                break
            
            # Create reasoning step
            step = ReasoningStep(
                step_id=step_count + 1,
                content=step_content,
                confidence=self._compute_confidence(step_content)
            )
            
            # Verify step if enabled
            if self.config.step_verification:
                step.verified = self._verify_step(step, reasoning_chain)
            
            reasoning_chain.add_step(step)
            
            # Update prompt for next step
            current_prompt += f" {step_content}\n\nStep {step_count + 2}:"
            step_count += 1
        
        # Validate the reasoning chain
        reasoning_chain.validate_chain()
        
        return reasoning_chain
    
    def _generate_step(self, prompt: str, generation_config: GenerationConfig) -> str:
        """Generate a single reasoning step."""
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        
        # Modify generation config for reasoning
        reasoning_config = GenerationConfig(
            max_new_tokens=min(200, generation_config.max_new_tokens),
            temperature=self.config.reasoning_temperature,
            top_p=0.9,
            do_sample=True,
            pad_token_id=self.tokenizer.eos_token_id,
            eos_token_id=self.tokenizer.eos_token_id
        )
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                generation_config=reasoning_config,
                return_dict_in_generate=True
            )
        
        # Decode and extract step content
        generated_text = self.tokenizer.decode(outputs.sequences[0], skip_special_tokens=True)
        
        # Extract the new content
        if prompt in generated_text:
            step_content = generated_text[len(prompt):].strip()
        else:
            step_content = generated_text.strip()
        
        # Clean up step content
        step_content = self._clean_step_content(step_content)
        
        return step_content
    
    def _clean_step_content(self, content: str) -> str:
        """Clean and format step content."""
        # Remove step delimiters
        content = re.sub(r'^Step \d+:', '', content).strip()
        
        # Remove extra whitespace
        content = re.sub(r'\s+', ' ', content).strip()
        
        # Stop at next step or conclusion
        stop_patterns = [r'\nStep \d+:', r'\nTherefore', r'\nIn conclusion']
        for pattern in stop_patterns:
            match = re.search(pattern, content)
            if match:
                content = content[:match.start()].strip()
                break
        
        return content
    
    def _is_conclusion(self, content: str) -> bool:
        """Check if content represents a conclusion."""
        content_lower = content.lower()
        return any(keyword in content_lower for keyword in self.config.conclusion_keywords)
    
    def _compute_confidence(self, content: str) -> float:
        """Compute confidence score for step content."""
        # Simple confidence based on content characteristics
        confidence = 0.5  # Base confidence
        
        # Increase confidence for reasoning keywords
        reasoning_indicators = sum(1 for keyword in self.config.reasoning_keywords 
                                 if keyword in content.lower())
        confidence += min(reasoning_indicators * 0.1, 0.3)
        
        # Increase confidence for specific statements
        if any(pattern in content.lower() for pattern in ['=', '>', '<', 'equals', 'is']):
            confidence += 0.1
        
        # Decrease confidence for uncertainty indicators
        uncertainty_indicators = ['maybe', 'possibly', 'might', 'could', 'perhaps']
        if any(indicator in content.lower() for indicator in uncertainty_indicators):
            confidence -= 0.2
        
        return max(0.0, min(1.0, confidence))
    
    def _verify_step(self, step: ReasoningStep, chain: ReasoningChain) -> bool:
        """Verify a reasoning step against the existing chain."""
        # Check for consistency with previous steps
        for prev_step in chain.steps:
            if chain._detect_contradiction(step.content, prev_step.content):
                return False
        
        # Check confidence threshold
        return step.confidence >= self.config.verification_threshold


class ChainOfThoughtReasoner:
    """Implements chain-of-thought reasoning strategy."""
    
    def __init__(self, 
                 model: AutoModelForCausalLM,
                 tokenizer: AutoTokenizer,
                 config: ReasoningConfig):
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
    
    def generate_reasoning(self, 
                         prompt: str,
                         generation_config: GenerationConfig) -> ReasoningChain:
        """Generate chain-of-thought reasoning for a prompt."""
        # Add CoT prompt template
        cot_prompt = f"{prompt}\n\n{self.config.cot_prompt_template}\n\n"
        
        # Generate reasoning in one pass
        reasoning_text = self._generate_cot_reasoning(cot_prompt, generation_config)
        
        # Parse reasoning into steps
        reasoning_chain = self._parse_cot_reasoning(reasoning_text)
        
        # Verify if enabled
        if self.config.cot_verification:
            self._verify_cot_reasoning(reasoning_chain)
        
        return reasoning_chain
    
    def _generate_cot_reasoning(self, prompt: str, generation_config: GenerationConfig) -> str:
        """Generate chain-of-thought reasoning text."""
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.model.device)
        
        # Modify generation config for CoT
        cot_config = GenerationConfig(
            max_new_tokens=self.config.max_reasoning_length,
            temperature=self.config.reasoning_temperature,
            top_p=0.9,
            do_sample=True,
            pad_token_id=self.tokenizer.eos_token_id,
            eos_token_id=self.tokenizer.eos_token_id
        )
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                generation_config=cot_config,
                return_dict_in_generate=True
            )
        
        # Decode generated text
        generated_text = self.tokenizer.decode(outputs.sequences[0], skip_special_tokens=True)
        
        # Extract reasoning part
        if prompt in generated_text:
            reasoning_text = generated_text[len(prompt):].strip()
        else:
            reasoning_text = generated_text.strip()
        
        return reasoning_text
    
    def _parse_cot_reasoning(self, reasoning_text: str) -> ReasoningChain:
        """Parse chain-of-thought reasoning into steps."""
        reasoning_chain = ReasoningChain()
        
        # Split into sentences or logical units
        sentences = re.split(r'[.!?]+', reasoning_text)
        
        step_id = 1
        for sentence in sentences:
            sentence = sentence.strip()
            if not sentence:
                continue
            
            # Check if this is a conclusion
            if self._is_conclusion(sentence):
                reasoning_chain.set_conclusion(sentence, self._compute_confidence(sentence))
                break
            
            # Create reasoning step
            step = ReasoningStep(
                step_id=step_id,
                content=sentence,
                confidence=self._compute_confidence(sentence)
            )
            
            reasoning_chain.add_step(step)
            step_id += 1
        
        return reasoning_chain
    
    def _verify_cot_reasoning(self, chain: ReasoningChain):
        """Verify chain-of-thought reasoning."""
        # Validate logical consistency
        chain.validate_chain()
        
        # Self-consistency check if enabled
        if self.config.self_consistency_checks > 1:
            self._perform_self_consistency_check(chain)
    
    def _perform_self_consistency_check(self, chain: ReasoningChain):
        """Perform self-consistency check by generating multiple reasoning paths."""
        # This would involve generating multiple reasoning chains and checking consistency
        # Simplified implementation for now
        pass
    
    def _is_conclusion(self, content: str) -> bool:
        """Check if content represents a conclusion."""
        content_lower = content.lower()
        return any(keyword in content_lower for keyword in self.config.conclusion_keywords)
    
    def _compute_confidence(self, content: str) -> float:
        """Compute confidence score for content."""
        # Similar to step-by-step confidence computation
        confidence = 0.5
        
        reasoning_indicators = sum(1 for keyword in self.config.reasoning_keywords 
                                 if keyword in content.lower())
        confidence += min(reasoning_indicators * 0.1, 0.3)
        
        if any(pattern in content.lower() for pattern in ['=', '>', '<', 'equals', 'is']):
            confidence += 0.1
        
        uncertainty_indicators = ['maybe', 'possibly', 'might', 'could', 'perhaps']
        if any(indicator in content.lower() for indicator in uncertainty_indicators):
            confidence -= 0.2
        
        return max(0.0, min(1.0, confidence))


class ReasoningEngine:
    """
    Main reasoning engine that orchestrates different reasoning strategies.
    
    Provides reasoning-aware inference optimization for logical reasoning tasks,
    including step-by-step reasoning, chain-of-thought, and reasoning verification.
    """
    
    def __init__(self,
                 model: AutoModelForCausalLM,
                 tokenizer: AutoTokenizer,
                 config: ReasoningConfig):
        """
        Initialize reasoning engine.
        
        Args:
            model: Language model
            tokenizer: Tokenizer
            config: Reasoning configuration
        """
        self.model = model
        self.tokenizer = tokenizer
        self.config = config
        
        # Initialize reasoning strategies
        self.step_by_step_reasoner = StepByStepReasoner(model, tokenizer, config)
        self.cot_reasoner = ChainOfThoughtReasoner(model, tokenizer, config)
        
        # Performance tracking
        self.reasoning_stats = {
            'total_reasonings': 0,
            'successful_reasonings': 0,
            'average_steps': 0.0,
            'average_confidence': 0.0
        }
        
        logger.info(f"Reasoning Engine initialized with strategy: {config.strategy}")
    
    def generate_with_reasoning(self, 
                              inputs: Dict[str, torch.Tensor],
                              generation_config: GenerationConfig) -> Dict[str, Any]:
        """
        Generate text with reasoning optimization.
        
        Args:
            inputs: Input tensors
            generation_config: Generation configuration
            
        Returns:
            Dictionary with generation results and reasoning information
        """
        # Extract prompt
        input_ids = inputs['input_ids']
        prompt = self.tokenizer.decode(input_ids[0], skip_special_tokens=True)
        
        # Choose reasoning strategy
        if self.config.strategy == "step_by_step":
            reasoning_chain = self.step_by_step_reasoner.generate_reasoning(prompt, generation_config)
        elif self.config.strategy == "chain_of_thought":
            reasoning_chain = self.cot_reasoner.generate_reasoning(prompt, generation_config)
        else:
            # Direct generation without explicit reasoning
            return self._generate_direct(inputs, generation_config)
        
        # Convert reasoning chain to output
        output_text = self._format_reasoning_output(reasoning_chain)
        
        # Tokenize output
        output_tokens = self.tokenizer(output_text, return_tensors="pt").to(self.model.device)
        
        # Combine input and output
        full_output = torch.cat([input_ids, output_tokens['input_ids'][:, 1:]], dim=1)
        
        # Update statistics
        self._update_reasoning_stats(reasoning_chain)
        
        return {
            'output_ids': full_output,
            'reasoning_steps': [step.content for step in reasoning_chain.steps],
            'confidence_score': reasoning_chain.overall_confidence,
            'reasoning_summary': reasoning_chain.get_summary(),
            'cache_hits': 0,
            'cache_misses': 0
        }
    
    def _generate_direct(self, 
                        inputs: Dict[str, torch.Tensor],
                        generation_config: GenerationConfig) -> Dict[str, Any]:
        """Generate text directly without explicit reasoning."""
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                generation_config=generation_config,
                return_dict_in_generate=True,
                output_scores=True
            )
        
        return {
            'output_ids': outputs.sequences,
            'reasoning_steps': [],
            'confidence_score': self._compute_generation_confidence(outputs),
            'cache_hits': 0,
            'cache_misses': 0
        }
    
    def _format_reasoning_output(self, reasoning_chain: ReasoningChain) -> str:
        """Format reasoning chain into output text."""
        output_parts = []
        
        # Add reasoning steps
        for step in reasoning_chain.steps:
            output_parts.append(f"Step {step.step_id}: {step.content}")
        
        # Add conclusion
        if reasoning_chain.conclusion:
            output_parts.append(f"\nTherefore, {reasoning_chain.conclusion}")
        
        return "\n".join(output_parts)
    
    def _compute_generation_confidence(self, outputs) -> float:
        """Compute confidence from generation outputs."""
        if not hasattr(outputs, 'scores') or not outputs.scores:
            return 0.5
        
        # Compute average probability of generated tokens
        token_probs = []
        for score in outputs.scores:
            probs = F.softmax(score, dim=-1)
            max_prob = torch.max(probs, dim=-1)[0]
            token_probs.append(max_prob.mean().item())
        
        return np.mean(token_probs) if token_probs else 0.5
    
    def _update_reasoning_stats(self, reasoning_chain: ReasoningChain):
        """Update reasoning statistics."""
        self.reasoning_stats['total_reasonings'] += 1
        
        if reasoning_chain.is_valid:
            self.reasoning_stats['successful_reasonings'] += 1
        
        # Update averages
        num_steps = len(reasoning_chain.steps)
        total_reasonings = self.reasoning_stats['total_reasonings']
        
        # Exponential moving average for steps
        alpha = 0.1
        self.reasoning_stats['average_steps'] = (
            alpha * num_steps + 
            (1 - alpha) * self.reasoning_stats['average_steps']
        )
        
        # Exponential moving average for confidence
        self.reasoning_stats['average_confidence'] = (
            alpha * reasoning_chain.overall_confidence + 
            (1 - alpha) * self.reasoning_stats['average_confidence']
        )
    
    def analyze_reasoning_quality(self, reasoning_chain: ReasoningChain) -> Dict[str, Any]:
        """Analyze the quality of a reasoning chain."""
        analysis = {
            'num_steps': len(reasoning_chain.steps),
            'is_valid': reasoning_chain.is_valid,
            'has_conclusion': reasoning_chain.conclusion is not None,
            'overall_confidence': reasoning_chain.overall_confidence,
            'contradictions': len(reasoning_chain.contradictions),
            'step_confidence_variance': np.var([step.confidence for step in reasoning_chain.steps]),
            'reasoning_keywords_count': 0,
            'conclusion_keywords_count': 0
        }
        
        # Count reasoning and conclusion keywords
        all_text = " ".join([step.content for step in reasoning_chain.steps])
        if reasoning_chain.conclusion:
            all_text += " " + reasoning_chain.conclusion
        
        all_text_lower = all_text.lower()
        
        analysis['reasoning_keywords_count'] = sum(
            1 for keyword in self.config.reasoning_keywords 
            if keyword in all_text_lower
        )
        
        analysis['conclusion_keywords_count'] = sum(
            1 for keyword in self.config.conclusion_keywords 
            if keyword in all_text_lower
        )
        
        # Quality score (0-1)
        quality_score = 0.0
        
        if analysis['is_valid']:
            quality_score += 0.3
        
        if analysis['has_conclusion']:
            quality_score += 0.2
        
        quality_score += min(analysis['overall_confidence'], 0.3)
        
        if analysis['reasoning_keywords_count'] > 0:
            quality_score += 0.1
        
        if analysis['conclusion_keywords_count'] > 0:
            quality_score += 0.1
        
        analysis['quality_score'] = quality_score
        
        return analysis
    
    def get_reasoning_statistics(self) -> Dict[str, Any]:
        """Get comprehensive reasoning statistics."""
        stats = self.reasoning_stats.copy()
        
        if stats['total_reasonings'] > 0:
            stats['success_rate'] = stats['successful_reasonings'] / stats['total_reasonings']
        else:
            stats['success_rate'] = 0.0
        
        return stats
    
    def reset_statistics(self):
        """Reset reasoning statistics."""
        self.reasoning_stats = {
            'total_reasonings': 0,
            'successful_reasonings': 0,
            'average_steps': 0.0,
            'average_confidence': 0.0
        }
        
        logger.info("Reasoning statistics reset")


def create_reasoning_engine(model: AutoModelForCausalLM,
                          tokenizer: AutoTokenizer,
                          config_overrides: Optional[Dict[str, Any]] = None) -> ReasoningEngine:
    """
    Create a reasoning engine with optional configuration overrides.
    
    Args:
        model: Language model
        tokenizer: Tokenizer
        config_overrides: Optional configuration overrides
        
    Returns:
        Configured ReasoningEngine
    """
    config = ReasoningConfig()
    
    if config_overrides:
        for key, value in config_overrides.items():
            if hasattr(config, key):
                setattr(config, key, value)
    
    return ReasoningEngine(model, tokenizer, config)

