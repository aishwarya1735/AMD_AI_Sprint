"""
Dataset Builder for Comprehensive Synthetic Data Generation

This module orchestrates the entire data generation process, coordinating
multiple generators, difficulty management, quality validation, and curriculum
learning to create high-quality training datasets.
"""

import json
import random
import numpy as np
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from datetime import datetime
import logging

from .base_generator import GeneratedProblem, DifficultyLevel, GenerationConfig
from .truth_liar_generator import TruthLiarGenerator
from .seating_generator import SeatingGenerator
from .blood_relations_generator import BloodRelationsGenerator
from .difficulty_manager import DifficultyManager, CurriculumLevel
from .quality_validator import QualityValidator, ValidationResult

logger = logging.getLogger(__name__)


@dataclass
class DatasetConfig:
    """Configuration for dataset generation."""
    # Dataset composition
    total_problems: int = 1000
    topic_distribution: Dict[str, float] = None  # Will be set in __post_init__
    
    # Quality settings
    quality_threshold: float = 3.5
    validation_enabled: bool = True
    max_generation_attempts: int = 5
    
    # Curriculum settings
    curriculum_enabled: bool = True
    curriculum_type: str = 'e2h'  # Easy-to-Hard
    problems_per_stage: int = 250
    
    # Difficulty distribution
    difficulty_distribution: Dict[DifficultyLevel, float] = None
    
    # Output settings
    output_format: str = 'json'  # 'json' or 'competition'
    include_metadata: bool = True
    save_validation_results: bool = True
    
    # Generation settings
    batch_size: int = 50
    parallel_generation: bool = False
    random_seed: Optional[int] = None
    
    def __post_init__(self):
        if self.topic_distribution is None:
            self.topic_distribution = {
                'truth_liar': 0.35,
                'seating': 0.35,
                'blood_relations': 0.30
            }
        
        if self.difficulty_distribution is None:
            if self.curriculum_enabled:
                # Progressive distribution for curriculum learning
                self.difficulty_distribution = {
                    DifficultyLevel.BEGINNER: 0.30,
                    DifficultyLevel.INTERMEDIATE: 0.35,
                    DifficultyLevel.ADVANCED: 0.25,
                    DifficultyLevel.EXPERT: 0.10
                }
            else:
                # Balanced distribution
                self.difficulty_distribution = {
                    DifficultyLevel.BEGINNER: 0.25,
                    DifficultyLevel.INTERMEDIATE: 0.25,
                    DifficultyLevel.ADVANCED: 0.25,
                    DifficultyLevel.EXPERT: 0.25
                }


@dataclass
class GenerationStats:
    """Statistics for dataset generation."""
    total_attempted: int = 0
    total_generated: int = 0
    total_validated: int = 0
    total_accepted: int = 0
    
    generation_time: float = 0.0
    validation_time: float = 0.0
    
    topic_counts: Dict[str, int] = None
    difficulty_counts: Dict[str, int] = None
    quality_scores: List[float] = None
    
    def __post_init__(self):
        if self.topic_counts is None:
            self.topic_counts = {}
        if self.difficulty_counts is None:
            self.difficulty_counts = {}
        if self.quality_scores is None:
            self.quality_scores = []
    
    @property
    def success_rate(self) -> float:
        return self.total_accepted / max(1, self.total_attempted)
    
    @property
    def validation_rate(self) -> float:
        return self.total_validated / max(1, self.total_generated)
    
    @property
    def average_quality(self) -> float:
        return np.mean(self.quality_scores) if self.quality_scores else 0.0


class DatasetBuilder:
    """
    Comprehensive dataset builder that orchestrates the entire data generation process.
    
    Features:
    - Multi-topic problem generation
    - Curriculum learning integration
    - Quality validation and filtering
    - Adaptive difficulty management
    - Comprehensive statistics and reporting
    """

    def __init__(self, config: Optional[DatasetConfig] = None):
        """
        Initialize the dataset builder.
        
        Args:
            config: Dataset generation configuration
        """
        self.config = config or DatasetConfig()
        
        # Set random seed for reproducibility
        if self.config.random_seed is not None:
            random.seed(self.config.random_seed)
            np.random.seed(self.config.random_seed)
        
        # Initialize components
        self.difficulty_manager = DifficultyManager() if self.config.curriculum_enabled else None
        self.quality_validator = QualityValidator() if self.config.validation_enabled else None
        
        # Initialize generators
        self.generators = self._initialize_generators()
        
        # Statistics tracking
        self.stats = GenerationStats()
        
        logger.info(f"Dataset Builder initialized with config: {self.config}")

    def _initialize_generators(self) -> Dict[str, Any]:
        """Initialize problem generators for each topic."""
        generation_config = GenerationConfig(
            difficulty_level=DifficultyLevel.INTERMEDIATE,  # Will be overridden
            num_problems=self.config.batch_size,
            quality_threshold=self.config.quality_threshold,
            max_attempts=self.config.max_generation_attempts,
            seed=self.config.random_seed,
            enable_validation=False,  # We'll validate separately
            include_metadata=self.config.include_metadata
        )
        
        generators = {
            'truth_liar': TruthLiarGenerator(generation_config),
            'seating': SeatingGenerator(generation_config),
            'blood_relations': BloodRelationsGenerator(generation_config)
        }
        
        logger.info(f"Initialized {len(generators)} problem generators")
        return generators

    def generate_dataset(self, output_path: str) -> Dict[str, Any]:
        """
        Generate a complete dataset with all topics and difficulty levels.
        
        Args:
            output_path: Path to save the generated dataset
            
        Returns:
            Generation summary and statistics
        """
        logger.info(f"Starting dataset generation: {self.config.total_problems} problems")
        start_time = datetime.now()
        
        all_problems = []
        validation_results = []
        
        # Calculate problems per topic
        topic_counts = self._calculate_topic_distribution()
        
        # Generate problems for each topic
        for topic, count in topic_counts.items():
            logger.info(f"Generating {count} problems for topic: {topic}")
            
            topic_problems, topic_validations = self._generate_topic_problems(topic, count)
            all_problems.extend(topic_problems)
            validation_results.extend(topic_validations)
            
            # Update statistics
            self.stats.topic_counts[topic] = len(topic_problems)
        
        # Final quality filtering
        if self.config.validation_enabled:
            all_problems, validation_results = self._apply_final_quality_filter(
                all_problems, validation_results
            )
        
        # Save dataset
        self._save_dataset(all_problems, output_path)
        
        # Save validation results if requested
        if self.config.save_validation_results and validation_results:
            validation_path = output_path.replace('.json', '_validation.json')
            self._save_validation_results(validation_results, validation_path)
        
        # Calculate final statistics
        end_time = datetime.now()
        self.stats.generation_time = (end_time - start_time).total_seconds()
        
        # Generate summary
        summary = self._generate_summary(all_problems, validation_results)
        
        logger.info(f"Dataset generation completed: {len(all_problems)} problems in {self.stats.generation_time:.2f}s")
        return summary

    def _calculate_topic_distribution(self) -> Dict[str, int]:
        """Calculate the number of problems to generate for each topic."""
        topic_counts = {}
        
        for topic, proportion in self.config.topic_distribution.items():
            count = int(self.config.total_problems * proportion)
            topic_counts[topic] = count
        
        # Adjust for rounding errors
        total_assigned = sum(topic_counts.values())
        if total_assigned < self.config.total_problems:
            # Add remaining problems to the first topic
            first_topic = list(topic_counts.keys())[0]
            topic_counts[first_topic] += self.config.total_problems - total_assigned
        
        return topic_counts

    def _generate_topic_problems(self, topic: str, target_count: int) -> Tuple[List[GeneratedProblem], List[ValidationResult]]:
        """
        Generate problems for a specific topic.
        
        Args:
            topic: Topic name
            target_count: Number of problems to generate
            
        Returns:
            Tuple of (problems, validation_results)
        """
        generator = self.generators[topic]
        problems = []
        validation_results = []
        
        # Generate in batches
        remaining = target_count
        batch_size = min(self.config.batch_size, remaining)
        
        while remaining > 0 and len(problems) < target_count:
            batch_size = min(batch_size, remaining)
            
            # Get difficulty distribution for this batch
            difficulties = self._get_batch_difficulties(batch_size)
            
            # Generate batch
            batch_problems = []
            for difficulty in difficulties:
                self.stats.total_attempted += 1
                
                try:
                    problem = generator.generate_single_problem(difficulty)
                    if problem:
                        batch_problems.append(problem)
                        self.stats.total_generated += 1
                        
                        # Update difficulty counts
                        diff_name = difficulty.name
                        self.stats.difficulty_counts[diff_name] = self.stats.difficulty_counts.get(diff_name, 0) + 1
                        
                except Exception as e:
                    logger.warning(f"Error generating {topic} problem: {e}")
                    continue
            
            # Validate batch if validation is enabled
            if self.config.validation_enabled and batch_problems:
                batch_validations = self._validate_batch(batch_problems)
                validation_results.extend(batch_validations)
                
                # Filter based on validation
                validated_problems = [
                    problem for problem, validation in zip(batch_problems, batch_validations)
                    if validation.is_valid and validation.overall_score >= self.config.quality_threshold
                ]
                
                problems.extend(validated_problems)
                self.stats.total_validated += len(batch_validations)
                self.stats.total_accepted += len(validated_problems)
                
                # Update quality scores
                self.stats.quality_scores.extend([v.overall_score for v in batch_validations])
            else:
                problems.extend(batch_problems)
                self.stats.total_accepted += len(batch_problems)
            
            remaining = target_count - len(problems)
            
            logger.debug(f"Generated {len(problems)}/{target_count} {topic} problems")
        
        return problems[:target_count], validation_results

    def _get_batch_difficulties(self, batch_size: int) -> List[DifficultyLevel]:
        """Get difficulty levels for a batch of problems."""
        if self.config.curriculum_enabled and self.difficulty_manager:
            return self.difficulty_manager.get_difficulty_distribution(batch_size)
        else:
            # Use configured distribution
            difficulties = []
            for _ in range(batch_size):
                # Sample from difficulty distribution
                rand_val = random.random()
                cumulative = 0.0
                
                for difficulty, prob in self.config.difficulty_distribution.items():
                    cumulative += prob
                    if rand_val <= cumulative:
                        difficulties.append(difficulty)
                        break
                else:
                    # Fallback
                    difficulties.append(DifficultyLevel.INTERMEDIATE)
            
            return difficulties

    def _validate_batch(self, problems: List[GeneratedProblem]) -> List[ValidationResult]:
        """Validate a batch of problems."""
        if not self.quality_validator:
            return []
        
        return self.quality_validator.batch_validate(problems)

    def _apply_final_quality_filter(self, problems: List[GeneratedProblem], 
                                  validation_results: List[ValidationResult]) -> Tuple[List[GeneratedProblem], List[ValidationResult]]:
        """Apply final quality filtering to the entire dataset."""
        if not validation_results:
            return problems, validation_results
        
        # Sort by quality score
        problem_validation_pairs = list(zip(problems, validation_results))
        problem_validation_pairs.sort(key=lambda x: x[1].overall_score, reverse=True)
        
        # Filter high-quality problems
        filtered_pairs = [
            (problem, validation) for problem, validation in problem_validation_pairs
            if validation.is_valid and validation.overall_score >= self.config.quality_threshold
        ]
        
        # Ensure we don't exceed the target count
        if len(filtered_pairs) > self.config.total_problems:
            filtered_pairs = filtered_pairs[:self.config.total_problems]
        
        filtered_problems, filtered_validations = zip(*filtered_pairs) if filtered_pairs else ([], [])
        
        logger.info(f"Quality filtering: {len(problems)} -> {len(filtered_problems)} problems")
        
        return list(filtered_problems), list(filtered_validations)

    def _save_dataset(self, problems: List[GeneratedProblem], output_path: str):
        """Save the generated dataset to file."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if self.config.output_format == 'competition':
            # Save in competition format
            data = [problem.to_competition_format() for problem in problems]
        else:
            # Save in full format with metadata
            data = [problem.to_dict() for problem in problems]
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Dataset saved to {output_path}")

    def _save_validation_results(self, validation_results: List[ValidationResult], output_path: str):
        """Save validation results to file."""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Convert validation results to serializable format
        data = []
        for result in validation_results:
            result_dict = {
                'is_valid': result.is_valid,
                'overall_score': result.overall_score,
                'category_scores': {cat.value: score for cat, score in result.category_scores.items()},
                'issues': [
                    {
                        'category': issue.category.value,
                        'severity': issue.severity,
                        'description': issue.description,
                        'suggestion': issue.suggestion,
                        'location': issue.location
                    }
                    for issue in result.issues
                ],
                'recommendations': result.recommendations
            }
            data.append(result_dict)
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Validation results saved to {output_path}")

    def _generate_summary(self, problems: List[GeneratedProblem], 
                         validation_results: List[ValidationResult]) -> Dict[str, Any]:
        """Generate a comprehensive summary of the dataset generation."""
        summary = {
            'generation_config': asdict(self.config),
            'generation_stats': asdict(self.stats),
            'dataset_info': {
                'total_problems': len(problems),
                'topics': list(self.stats.topic_counts.keys()),
                'topic_distribution': self.stats.topic_counts,
                'difficulty_distribution': self.stats.difficulty_counts
            },
            'quality_metrics': {},
            'curriculum_info': {},
            'recommendations': []
        }
        
        # Quality metrics
        if validation_results:
            quality_summary = self.quality_validator.get_validation_summary(validation_results)
            summary['quality_metrics'] = quality_summary
        
        # Curriculum information
        if self.difficulty_manager:
            curriculum_report = self.difficulty_manager.get_curriculum_progress_report()
            summary['curriculum_info'] = curriculum_report
        
        # Generate recommendations
        summary['recommendations'] = self._generate_recommendations(problems, validation_results)
        
        return summary

    def _generate_recommendations(self, problems: List[GeneratedProblem], 
                                validation_results: List[ValidationResult]) -> List[str]:
        """Generate recommendations based on generation results."""
        recommendations = []
        
        # Success rate recommendations
        if self.stats.success_rate < 0.7:
            recommendations.append("Low success rate - consider adjusting generation parameters")
        
        # Quality recommendations
        if validation_results:
            avg_quality = np.mean([r.overall_score for r in validation_results])
            if avg_quality < 0.8:
                recommendations.append("Average quality below target - review generation logic")
        
        # Topic balance recommendations
        topic_counts = list(self.stats.topic_counts.values())
        if topic_counts and (max(topic_counts) - min(topic_counts)) > len(problems) * 0.1:
            recommendations.append("Topic distribution is unbalanced - adjust generation parameters")
        
        # Difficulty recommendations
        if self.difficulty_manager:
            curriculum_report = self.difficulty_manager.get_curriculum_progress_report()
            recommendations.extend(curriculum_report.get('recommendations', []))
        
        return recommendations

    def generate_curriculum_dataset(self, output_dir: str) -> Dict[str, Any]:
        """
        Generate a complete curriculum dataset with progressive difficulty.
        
        Args:
            output_dir: Directory to save curriculum datasets
            
        Returns:
            Summary of curriculum generation
        """
        if not self.difficulty_manager:
            raise ValueError("Curriculum learning is not enabled")
        
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        curriculum_summary = {
            'stages': [],
            'total_problems': 0,
            'generation_time': 0.0
        }
        
        start_time = datetime.now()
        
        # Generate dataset for each curriculum stage
        for stage_id in range(len(self.difficulty_manager.curriculum_stages)):
            stage_info = self.difficulty_manager.curriculum_stages[stage_id]
            
            logger.info(f"Generating curriculum stage {stage_id}: {stage_info.name}")
            
            # Set current stage
            self.difficulty_manager.current_stage = stage_id
            
            # Generate stage dataset
            stage_config = DatasetConfig(
                total_problems=self.config.problems_per_stage,
                topic_distribution=self.config.topic_distribution,
                quality_threshold=stage_info.quality_threshold,
                curriculum_enabled=True,
                output_format=self.config.output_format,
                batch_size=self.config.batch_size
            )
            
            # Temporarily update config
            original_config = self.config
            self.config = stage_config
            
            # Generate stage dataset
            stage_output_path = output_dir / f"stage_{stage_id}_{stage_info.name.lower()}.json"
            stage_summary = self.generate_dataset(str(stage_output_path))
            
            # Restore original config
            self.config = original_config
            
            # Update curriculum summary
            curriculum_summary['stages'].append({
                'stage_id': stage_id,
                'name': stage_info.name,
                'description': stage_info.description,
                'difficulty_range': stage_info.difficulty_range,
                'problems_generated': stage_summary['dataset_info']['total_problems'],
                'average_quality': stage_summary['quality_metrics'].get('average_score', 0.0),
                'output_file': str(stage_output_path)
            })
            
            curriculum_summary['total_problems'] += stage_summary['dataset_info']['total_problems']
        
        end_time = datetime.now()
        curriculum_summary['generation_time'] = (end_time - start_time).total_seconds()
        
        # Save curriculum summary
        summary_path = output_dir / "curriculum_summary.json"
        with open(summary_path, 'w', encoding='utf-8') as f:
            json.dump(curriculum_summary, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Curriculum dataset generation completed: {curriculum_summary['total_problems']} total problems")
        
        return curriculum_summary

    def export_generation_config(self, output_path: str):
        """Export the current generation configuration."""
        config_data = {
            'dataset_config': asdict(self.config),
            'generation_stats': asdict(self.stats),
            'timestamp': datetime.now().isoformat()
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(config_data, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Generation config exported to {output_path}")

    @classmethod
    def from_config_file(cls, config_path: str) -> 'DatasetBuilder':
        """Create a DatasetBuilder from a configuration file."""
        with open(config_path, 'r', encoding='utf-8') as f:
            config_data = json.load(f)
        
        # Convert to DatasetConfig
        dataset_config = DatasetConfig(**config_data.get('dataset_config', {}))
        
        return cls(dataset_config)

