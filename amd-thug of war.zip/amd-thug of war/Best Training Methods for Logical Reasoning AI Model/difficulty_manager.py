"""
Difficulty Manager for Curriculum Learning

This module manages the systematic progression of difficulty levels in problem
generation, implementing Easy-to-Hard (E2H) curriculum learning strategies
for optimal training progression.
"""

import random
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from enum import Enum
import logging

from .base_generator import DifficultyLevel, GeneratedProblem

logger = logging.getLogger(__name__)


class CurriculumLevel(Enum):
    """Curriculum learning levels for systematic progression."""
    FOUNDATION = 1    # Basic concepts, simple reasoning
    BUILDING = 2      # Intermediate concepts, multi-step reasoning
    MASTERY = 3       # Advanced concepts, complex reasoning
    EXPERTISE = 4     # Expert-level concepts, intricate reasoning


@dataclass
class DifficultyMetrics:
    """Metrics for measuring problem difficulty."""
    logical_complexity: float      # Number of logical steps required
    constraint_density: float      # Number of constraints per entity
    reasoning_depth: float         # Depth of reasoning chain
    concept_abstraction: float     # Level of abstract thinking required
    working_memory_load: float     # Amount of information to track
    
    def overall_difficulty(self) -> float:
        """Calculate overall difficulty score."""
        weights = {
            'logical_complexity': 0.25,
            'constraint_density': 0.20,
            'reasoning_depth': 0.25,
            'concept_abstraction': 0.15,
            'working_memory_load': 0.15
        }
        
        return (
            self.logical_complexity * weights['logical_complexity'] +
            self.constraint_density * weights['constraint_density'] +
            self.reasoning_depth * weights['reasoning_depth'] +
            self.concept_abstraction * weights['concept_abstraction'] +
            self.working_memory_load * weights['working_memory_load']
        )


@dataclass
class CurriculumStage:
    """Represents a stage in the curriculum learning progression."""
    stage_id: int
    name: str
    difficulty_range: Tuple[float, float]  # Min and max difficulty scores
    target_concepts: List[str]
    prerequisite_stages: List[int]
    problems_per_topic: int
    quality_threshold: float
    description: str


class DifficultyManager:
    """
    Manages difficulty progression and curriculum learning for problem generation.
    
    Implements Easy-to-Hard (E2H) curriculum learning with:
    - Systematic difficulty progression
    - Adaptive difficulty adjustment
    - Quality-based advancement criteria
    - Multi-dimensional difficulty assessment
    """

    def __init__(self, curriculum_config: Optional[Dict[str, Any]] = None):
        """
        Initialize the difficulty manager.
        
        Args:
            curriculum_config: Configuration for curriculum learning
        """
        self.config = curriculum_config or self._get_default_config()
        
        # Initialize curriculum stages
        self.curriculum_stages = self._initialize_curriculum_stages()
        
        # Track progress
        self.current_stage = 0
        self.stage_progress = {}
        self.difficulty_history = []
        self.performance_metrics = {}
        
        logger.info("Difficulty Manager initialized with E2H curriculum learning")

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default curriculum configuration."""
        return {
            'adaptive_difficulty': True,
            'quality_threshold': 3.5,
            'progression_threshold': 0.8,  # Success rate to advance
            'difficulty_smoothing': 0.1,   # Rate of difficulty increase
            'max_attempts_per_stage': 3,
            'enable_difficulty_metrics': True,
            'curriculum_type': 'e2h'  # Easy-to-Hard
        }

    def _initialize_curriculum_stages(self) -> List[CurriculumStage]:
        """Initialize the curriculum learning stages."""
        stages = [
            CurriculumStage(
                stage_id=0,
                name="Foundation",
                difficulty_range=(1.0, 2.0),
                target_concepts=[
                    "basic_logical_reasoning",
                    "simple_constraints",
                    "direct_relationships",
                    "single_step_inference"
                ],
                prerequisite_stages=[],
                problems_per_topic=50,
                quality_threshold=3.0,
                description="Basic logical reasoning with simple, direct relationships"
            ),
            CurriculumStage(
                stage_id=1,
                name="Building",
                difficulty_range=(1.8, 3.2),
                target_concepts=[
                    "multi_step_reasoning",
                    "moderate_constraints",
                    "indirect_relationships",
                    "constraint_satisfaction",
                    "logical_chains"
                ],
                prerequisite_stages=[0],
                problems_per_topic=75,
                quality_threshold=3.5,
                description="Multi-step reasoning with moderate constraint complexity"
            ),
            CurriculumStage(
                stage_id=2,
                name="Mastery",
                difficulty_range=(2.8, 4.2),
                target_concepts=[
                    "complex_reasoning",
                    "multiple_constraints",
                    "abstract_relationships",
                    "logical_deduction",
                    "constraint_optimization",
                    "working_memory_intensive"
                ],
                prerequisite_stages=[1],
                problems_per_topic=100,
                quality_threshold=4.0,
                description="Complex reasoning with multiple interacting constraints"
            ),
            CurriculumStage(
                stage_id=3,
                name="Expertise",
                difficulty_range=(3.8, 5.0),
                target_concepts=[
                    "expert_reasoning",
                    "intricate_constraints",
                    "meta_logical_reasoning",
                    "advanced_deduction",
                    "constraint_networks",
                    "high_abstraction"
                ],
                prerequisite_stages=[2],
                problems_per_topic=125,
                quality_threshold=4.5,
                description="Expert-level reasoning with intricate logical relationships"
            )
        ]
        
        return stages

    def get_target_difficulty(self, topic: str, current_performance: Optional[float] = None) -> DifficultyLevel:
        """
        Get target difficulty level based on curriculum stage and performance.
        
        Args:
            topic: The topic for which to determine difficulty
            current_performance: Current performance score (0.0 to 1.0)
            
        Returns:
            Target difficulty level
        """
        current_stage = self.curriculum_stages[self.current_stage]
        
        # Base difficulty from curriculum stage
        min_diff, max_diff = current_stage.difficulty_range
        
        # Adjust based on performance if available
        if current_performance is not None and self.config['adaptive_difficulty']:
            # If performance is high, increase difficulty within range
            # If performance is low, decrease difficulty within range
            performance_factor = (current_performance - 0.5) * 2  # Scale to [-1, 1]
            target_difficulty = min_diff + (max_diff - min_diff) * (0.5 + performance_factor * 0.3)
        else:
            # Use middle of range as default
            target_difficulty = (min_diff + max_diff) / 2
        
        # Map to DifficultyLevel enum
        if target_difficulty <= 1.5:
            return DifficultyLevel.BEGINNER
        elif target_difficulty <= 2.5:
            return DifficultyLevel.INTERMEDIATE
        elif target_difficulty <= 3.5:
            return DifficultyLevel.ADVANCED
        else:
            return DifficultyLevel.EXPERT

    def calculate_difficulty_metrics(self, problem: GeneratedProblem) -> DifficultyMetrics:
        """
        Calculate comprehensive difficulty metrics for a problem.
        
        Args:
            problem: The problem to analyze
            
        Returns:
            Difficulty metrics
        """
        # Logical complexity: based on reasoning steps
        logical_complexity = min(5.0, len(problem.reasoning_steps) * 0.5 + 1.0)
        
        # Constraint density: constraints per entity
        num_entities = self._estimate_entities(problem)
        constraint_density = min(5.0, len(problem.constraints) / max(1, num_entities))
        
        # Reasoning depth: depth of logical chain
        reasoning_depth = min(5.0, self._estimate_reasoning_depth(problem))
        
        # Concept abstraction: based on problem complexity
        concept_abstraction = self._estimate_abstraction_level(problem)
        
        # Working memory load: information to track simultaneously
        working_memory_load = min(5.0, self._estimate_memory_load(problem))
        
        return DifficultyMetrics(
            logical_complexity=logical_complexity,
            constraint_density=constraint_density,
            reasoning_depth=reasoning_depth,
            concept_abstraction=concept_abstraction,
            working_memory_load=working_memory_load
        )

    def _estimate_entities(self, problem: GeneratedProblem) -> int:
        """Estimate the number of entities in the problem."""
        # Count unique names/entities mentioned in the question
        question_words = problem.question.lower().split()
        
        # Simple heuristic: count capitalized words (likely names)
        entities = set()
        for word in problem.question.split():
            if word[0].isupper() and word.isalpha():
                entities.add(word)
        
        # Minimum of 2 entities for any meaningful problem
        return max(2, len(entities))

    def _estimate_reasoning_depth(self, problem: GeneratedProblem) -> float:
        """Estimate the depth of reasoning required."""
        # Base depth from reasoning steps
        base_depth = len(problem.reasoning_steps)
        
        # Adjust based on problem characteristics
        if "between" in problem.question.lower():
            base_depth += 1
        if "not" in problem.question.lower():
            base_depth += 0.5
        if any(word in problem.question.lower() for word in ["grandfather", "grandmother", "uncle", "aunt"]):
            base_depth += 1
        
        return min(5.0, base_depth)

    def _estimate_abstraction_level(self, problem: GeneratedProblem) -> float:
        """Estimate the level of abstract thinking required."""
        abstraction = 1.0
        
        # Topic-based abstraction
        if "truth" in problem.topic.lower() or "liar" in problem.topic.lower():
            abstraction += 1.5  # Meta-logical reasoning
        elif "seating" in problem.topic.lower():
            abstraction += 1.0  # Spatial reasoning
        elif "blood" in problem.topic.lower() or "family" in problem.topic.lower():
            abstraction += 0.8  # Relational reasoning
        
        # Complexity indicators
        if "circular" in problem.question.lower():
            abstraction += 0.5
        if len(problem.constraints) > 3:
            abstraction += 0.3
        
        return min(5.0, abstraction)

    def _estimate_memory_load(self, problem: GeneratedProblem) -> float:
        """Estimate the working memory load."""
        # Base load from entities and constraints
        entities = self._estimate_entities(problem)
        constraints = len(problem.constraints)
        
        memory_load = entities * 0.3 + constraints * 0.4
        
        # Adjust for problem type
        if "circular" in problem.question.lower():
            memory_load += 0.5  # Need to track circular relationships
        
        return min(5.0, memory_load)

    def should_advance_stage(self, performance_history: List[float]) -> bool:
        """
        Determine if the curriculum should advance to the next stage.
        
        Args:
            performance_history: Recent performance scores
            
        Returns:
            True if should advance to next stage
        """
        if not performance_history:
            return False
        
        # Need minimum number of problems to evaluate
        min_problems = 20
        if len(performance_history) < min_problems:
            return False
        
        # Calculate recent performance
        recent_performance = np.mean(performance_history[-min_problems:])
        
        # Check if performance meets threshold
        threshold = self.config['progression_threshold']
        
        if recent_performance >= threshold:
            logger.info(f"Performance threshold met: {recent_performance:.3f} >= {threshold}")
            return True
        
        return False

    def advance_to_next_stage(self) -> bool:
        """
        Advance to the next curriculum stage.
        
        Returns:
            True if advancement was successful
        """
        if self.current_stage < len(self.curriculum_stages) - 1:
            self.current_stage += 1
            current_stage = self.curriculum_stages[self.current_stage]
            
            logger.info(f"Advanced to curriculum stage {self.current_stage}: {current_stage.name}")
            logger.info(f"Target concepts: {current_stage.target_concepts}")
            logger.info(f"Difficulty range: {current_stage.difficulty_range}")
            
            return True
        else:
            logger.info("Already at the highest curriculum stage")
            return False

    def get_current_stage_info(self) -> CurriculumStage:
        """Get information about the current curriculum stage."""
        return self.curriculum_stages[self.current_stage]

    def get_difficulty_distribution(self, num_problems: int) -> List[DifficultyLevel]:
        """
        Get a distribution of difficulty levels for a batch of problems.
        
        Args:
            num_problems: Number of problems to generate
            
        Returns:
            List of difficulty levels
        """
        current_stage = self.curriculum_stages[self.current_stage]
        min_diff, max_diff = current_stage.difficulty_range
        
        # Create a distribution that emphasizes the target range
        difficulties = []
        
        for _ in range(num_problems):
            # Sample from the current stage's difficulty range
            target_score = random.uniform(min_diff, max_diff)
            
            # Map to difficulty level
            if target_score <= 1.5:
                difficulty = DifficultyLevel.BEGINNER
            elif target_score <= 2.5:
                difficulty = DifficultyLevel.INTERMEDIATE
            elif target_score <= 3.5:
                difficulty = DifficultyLevel.ADVANCED
            else:
                difficulty = DifficultyLevel.EXPERT
            
            difficulties.append(difficulty)
        
        return difficulties

    def update_performance_metrics(self, topic: str, problems: List[GeneratedProblem], 
                                 performance_scores: List[float]):
        """
        Update performance metrics for curriculum management.
        
        Args:
            topic: The topic being trained on
            problems: List of problems used
            performance_scores: Performance scores for each problem
        """
        if topic not in self.performance_metrics:
            self.performance_metrics[topic] = {
                'scores': [],
                'difficulties': [],
                'stage_history': []
            }
        
        # Update metrics
        self.performance_metrics[topic]['scores'].extend(performance_scores)
        
        # Track difficulty progression
        for problem in problems:
            metrics = self.calculate_difficulty_metrics(problem)
            self.performance_metrics[topic]['difficulties'].append(metrics.overall_difficulty())
        
        # Track stage progression
        current_stage = self.curriculum_stages[self.current_stage]
        self.performance_metrics[topic]['stage_history'].append(current_stage.stage_id)
        
        # Check for stage advancement
        if self.should_advance_stage(performance_scores):
            self.advance_to_next_stage()

    def get_curriculum_progress_report(self) -> Dict[str, Any]:
        """
        Generate a comprehensive curriculum progress report.
        
        Returns:
            Progress report with metrics and recommendations
        """
        current_stage = self.curriculum_stages[self.current_stage]
        
        report = {
            'current_stage': {
                'id': current_stage.stage_id,
                'name': current_stage.name,
                'description': current_stage.description,
                'difficulty_range': current_stage.difficulty_range,
                'target_concepts': current_stage.target_concepts
            },
            'progress_summary': {},
            'performance_analysis': {},
            'recommendations': []
        }
        
        # Analyze performance by topic
        for topic, metrics in self.performance_metrics.items():
            if metrics['scores']:
                recent_scores = metrics['scores'][-20:]  # Last 20 problems
                avg_performance = np.mean(recent_scores)
                performance_trend = self._calculate_trend(recent_scores)
                
                report['performance_analysis'][topic] = {
                    'average_performance': avg_performance,
                    'performance_trend': performance_trend,
                    'problems_completed': len(metrics['scores']),
                    'current_difficulty': np.mean(metrics['difficulties'][-10:]) if metrics['difficulties'] else 0
                }
                
                # Generate recommendations
                if avg_performance < 0.6:
                    report['recommendations'].append(f"Consider reducing difficulty for {topic}")
                elif avg_performance > 0.9 and performance_trend > 0:
                    report['recommendations'].append(f"Ready to increase difficulty for {topic}")
        
        return report

    def _calculate_trend(self, scores: List[float]) -> float:
        """Calculate the trend in performance scores."""
        if len(scores) < 5:
            return 0.0
        
        # Simple linear trend calculation
        x = np.arange(len(scores))
        y = np.array(scores)
        
        # Calculate slope
        slope = np.polyfit(x, y, 1)[0]
        return slope

    def reset_curriculum(self):
        """Reset curriculum to the beginning."""
        self.current_stage = 0
        self.stage_progress = {}
        self.difficulty_history = []
        self.performance_metrics = {}
        
        logger.info("Curriculum reset to foundation stage")

    def export_curriculum_data(self) -> Dict[str, Any]:
        """Export curriculum data for analysis or resumption."""
        return {
            'current_stage': self.current_stage,
            'stage_progress': self.stage_progress,
            'difficulty_history': self.difficulty_history,
            'performance_metrics': self.performance_metrics,
            'config': self.config
        }

    def import_curriculum_data(self, data: Dict[str, Any]):
        """Import curriculum data to resume training."""
        self.current_stage = data.get('current_stage', 0)
        self.stage_progress = data.get('stage_progress', {})
        self.difficulty_history = data.get('difficulty_history', [])
        self.performance_metrics = data.get('performance_metrics', {})
        
        # Update config if provided
        if 'config' in data:
            self.config.update(data['config'])
        
        logger.info(f"Curriculum data imported. Current stage: {self.current_stage}")

