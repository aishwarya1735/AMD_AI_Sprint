"""
Quality Validator for Synthetic Problem Generation

This module provides comprehensive quality validation for generated reasoning
problems, ensuring logical consistency, clarity, and educational value.
"""

import re
import json
import random
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass
from enum import Enum
import logging

from .base_generator import GeneratedProblem, DifficultyLevel

logger = logging.getLogger(__name__)


class ValidationCategory(Enum):
    """Categories of validation checks."""
    LOGICAL_CONSISTENCY = "logical_consistency"
    STRUCTURAL_INTEGRITY = "structural_integrity"
    CLARITY_AND_READABILITY = "clarity_and_readability"
    EDUCATIONAL_VALUE = "educational_value"
    ANSWER_CORRECTNESS = "answer_correctness"
    CHOICE_QUALITY = "choice_quality"


@dataclass
class ValidationIssue:
    """Represents a validation issue found in a problem."""
    category: ValidationCategory
    severity: str  # 'critical', 'major', 'minor'
    description: str
    suggestion: Optional[str] = None
    location: Optional[str] = None  # Where in the problem the issue occurs


@dataclass
class ValidationResult:
    """Result of problem validation."""
    is_valid: bool
    overall_score: float  # 0.0 to 1.0
    category_scores: Dict[ValidationCategory, float]
    issues: List[ValidationIssue]
    recommendations: List[str]
    
    def get_critical_issues(self) -> List[ValidationIssue]:
        """Get all critical issues."""
        return [issue for issue in self.issues if issue.severity == 'critical']
    
    def get_major_issues(self) -> List[ValidationIssue]:
        """Get all major issues."""
        return [issue for issue in self.issues if issue.severity == 'major']


class QualityValidator:
    """
    Comprehensive quality validator for reasoning problems.
    
    Validates:
    - Logical consistency and correctness
    - Structural integrity of the problem
    - Clarity and readability
    - Educational value and difficulty appropriateness
    - Answer correctness and choice quality
    """

    def __init__(self, validation_config: Optional[Dict[str, Any]] = None):
        """
        Initialize the quality validator.
        
        Args:
            validation_config: Configuration for validation parameters
        """
        self.config = validation_config or self._get_default_config()
        
        # Initialize validation weights
        self.category_weights = {
            ValidationCategory.LOGICAL_CONSISTENCY: 0.30,
            ValidationCategory.STRUCTURAL_INTEGRITY: 0.20,
            ValidationCategory.CLARITY_AND_READABILITY: 0.15,
            ValidationCategory.EDUCATIONAL_VALUE: 0.15,
            ValidationCategory.ANSWER_CORRECTNESS: 0.15,
            ValidationCategory.CHOICE_QUALITY: 0.05
        }
        
        # Common words and patterns for validation
        self.common_names = set([
            'alice', 'bob', 'charlie', 'diana', 'eve', 'frank', 'grace', 'henry',
            'adam', 'betty', 'carl', 'david', 'emma', 'fiona', 'george', 'helen'
        ])
        
        self.relationship_terms = set([
            'father', 'mother', 'parent', 'son', 'daughter', 'child',
            'brother', 'sister', 'sibling', 'grandfather', 'grandmother',
            'grandson', 'granddaughter', 'uncle', 'aunt', 'nephew', 'niece',
            'cousin', 'husband', 'wife', 'spouse'
        ])
        
        logger.info("Quality Validator initialized")

    def _get_default_config(self) -> Dict[str, Any]:
        """Get default validation configuration."""
        return {
            'min_question_length': 20,
            'max_question_length': 500,
            'min_explanation_length': 30,
            'max_explanation_length': 300,
            'require_all_choices': True,
            'check_answer_in_choices': True,
            'validate_logical_consistency': True,
            'check_readability': True,
            'validate_difficulty_alignment': True,
            'critical_issue_threshold': 0.7,  # Score below this is critical
            'major_issue_threshold': 0.8      # Score below this is major
        }

    def validate_problem(self, problem: GeneratedProblem) -> ValidationResult:
        """
        Perform comprehensive validation of a problem.
        
        Args:
            problem: The problem to validate
            
        Returns:
            Validation result with scores and issues
        """
        issues = []
        category_scores = {}
        
        # Validate each category
        category_scores[ValidationCategory.LOGICAL_CONSISTENCY] = self._validate_logical_consistency(problem, issues)
        category_scores[ValidationCategory.STRUCTURAL_INTEGRITY] = self._validate_structural_integrity(problem, issues)
        category_scores[ValidationCategory.CLARITY_AND_READABILITY] = self._validate_clarity_readability(problem, issues)
        category_scores[ValidationCategory.EDUCATIONAL_VALUE] = self._validate_educational_value(problem, issues)
        category_scores[ValidationCategory.ANSWER_CORRECTNESS] = self._validate_answer_correctness(problem, issues)
        category_scores[ValidationCategory.CHOICE_QUALITY] = self._validate_choice_quality(problem, issues)
        
        # Calculate overall score
        overall_score = sum(
            score * self.category_weights[category]
            for category, score in category_scores.items()
        )
        
        # Determine if problem is valid
        critical_issues = [issue for issue in issues if issue.severity == 'critical']
        is_valid = len(critical_issues) == 0 and overall_score >= self.config['critical_issue_threshold']
        
        # Generate recommendations
        recommendations = self._generate_recommendations(issues, category_scores)
        
        return ValidationResult(
            is_valid=is_valid,
            overall_score=overall_score,
            category_scores=category_scores,
            issues=issues,
            recommendations=recommendations
        )

    def _validate_logical_consistency(self, problem: GeneratedProblem, issues: List[ValidationIssue]) -> float:
        """Validate logical consistency of the problem."""
        score = 1.0
        
        # Check for logical contradictions in constraints
        if self._has_logical_contradictions(problem):
            issues.append(ValidationIssue(
                category=ValidationCategory.LOGICAL_CONSISTENCY,
                severity='critical',
                description="Problem contains logical contradictions",
                suggestion="Review constraints for consistency",
                location="constraints"
            ))
            score -= 0.5
        
        # Check if reasoning steps are logical
        if not self._are_reasoning_steps_logical(problem):
            issues.append(ValidationIssue(
                category=ValidationCategory.LOGICAL_CONSISTENCY,
                severity='major',
                description="Reasoning steps contain logical gaps",
                suggestion="Ensure each reasoning step follows logically from the previous",
                location="reasoning_steps"
            ))
            score -= 0.3
        
        # Check if explanation supports the answer
        if not self._does_explanation_support_answer(problem):
            issues.append(ValidationIssue(
                category=ValidationCategory.LOGICAL_CONSISTENCY,
                severity='major',
                description="Explanation does not clearly support the given answer",
                suggestion="Revise explanation to clearly justify the answer",
                location="explanation"
            ))
            score -= 0.2
        
        return max(0.0, score)

    def _validate_structural_integrity(self, problem: GeneratedProblem, issues: List[ValidationIssue]) -> float:
        """Validate structural integrity of the problem."""
        score = 1.0
        
        # Check question length
        question_len = len(problem.question)
        if question_len < self.config['min_question_length']:
            issues.append(ValidationIssue(
                category=ValidationCategory.STRUCTURAL_INTEGRITY,
                severity='major',
                description=f"Question too short ({question_len} chars)",
                suggestion=f"Expand question to at least {self.config['min_question_length']} characters",
                location="question"
            ))
            score -= 0.2
        elif question_len > self.config['max_question_length']:
            issues.append(ValidationIssue(
                category=ValidationCategory.STRUCTURAL_INTEGRITY,
                severity='minor',
                description=f"Question too long ({question_len} chars)",
                suggestion=f"Consider shortening to under {self.config['max_question_length']} characters",
                location="question"
            ))
            score -= 0.1
        
        # Check choices
        if len(problem.choices) != 4:
            issues.append(ValidationIssue(
                category=ValidationCategory.STRUCTURAL_INTEGRITY,
                severity='critical',
                description=f"Must have exactly 4 choices, found {len(problem.choices)}",
                suggestion="Ensure exactly 4 multiple choice options",
                location="choices"
            ))
            score -= 0.4
        
        # Check answer format
        if not self._is_valid_answer_format(problem.answer):
            issues.append(ValidationIssue(
                category=ValidationCategory.STRUCTURAL_INTEGRITY,
                severity='critical',
                description="Answer format is invalid",
                suggestion="Answer should be a single letter (A, B, C, or D) or match one of the choices",
                location="answer"
            ))
            score -= 0.3
        
        # Check explanation length
        explanation_len = len(problem.explanation)
        if explanation_len < self.config['min_explanation_length']:
            issues.append(ValidationIssue(
                category=ValidationCategory.STRUCTURAL_INTEGRITY,
                severity='major',
                description=f"Explanation too short ({explanation_len} chars)",
                suggestion=f"Expand explanation to at least {self.config['min_explanation_length']} characters",
                location="explanation"
            ))
            score -= 0.2
        
        return max(0.0, score)

    def _validate_clarity_readability(self, problem: GeneratedProblem, issues: List[ValidationIssue]) -> float:
        """Validate clarity and readability of the problem."""
        score = 1.0
        
        # Check for unclear language
        if self._has_unclear_language(problem.question):
            issues.append(ValidationIssue(
                category=ValidationCategory.CLARITY_AND_READABILITY,
                severity='minor',
                description="Question contains unclear or ambiguous language",
                suggestion="Simplify language and remove ambiguity",
                location="question"
            ))
            score -= 0.1
        
        # Check for grammatical errors
        grammar_issues = self._check_grammar(problem)
        if grammar_issues:
            issues.append(ValidationIssue(
                category=ValidationCategory.CLARITY_AND_READABILITY,
                severity='minor',
                description=f"Grammar issues found: {', '.join(grammar_issues)}",
                suggestion="Review and correct grammatical errors",
                location="question"
            ))
            score -= 0.1
        
        # Check readability level
        readability_score = self._calculate_readability(problem.question)
        if readability_score < 0.6:  # Too complex
            issues.append(ValidationIssue(
                category=ValidationCategory.CLARITY_AND_READABILITY,
                severity='minor',
                description="Text may be too complex for target audience",
                suggestion="Simplify sentence structure and vocabulary",
                location="question"
            ))
            score -= 0.1
        
        return max(0.0, score)

    def _validate_educational_value(self, problem: GeneratedProblem, issues: List[ValidationIssue]) -> float:
        """Validate educational value and difficulty appropriateness."""
        score = 1.0
        
        # Check if problem teaches the intended concept
        if not self._teaches_target_concept(problem):
            issues.append(ValidationIssue(
                category=ValidationCategory.EDUCATIONAL_VALUE,
                severity='major',
                description="Problem does not clearly teach the target concept",
                suggestion="Ensure problem focuses on the intended learning objective",
                location="question"
            ))
            score -= 0.3
        
        # Check difficulty alignment
        if not self._is_difficulty_appropriate(problem):
            issues.append(ValidationIssue(
                category=ValidationCategory.EDUCATIONAL_VALUE,
                severity='minor',
                description="Problem difficulty may not match the specified level",
                suggestion="Adjust problem complexity to match target difficulty",
                location="metadata"
            ))
            score -= 0.2
        
        # Check for educational progression
        if not self._supports_learning_progression(problem):
            issues.append(ValidationIssue(
                category=ValidationCategory.EDUCATIONAL_VALUE,
                severity='minor',
                description="Problem may not support systematic learning progression",
                suggestion="Ensure problem builds on prerequisite concepts",
                location="reasoning_steps"
            ))
            score -= 0.1
        
        return max(0.0, score)

    def _validate_answer_correctness(self, problem: GeneratedProblem, issues: List[ValidationIssue]) -> float:
        """Validate answer correctness."""
        score = 1.0
        
        # Check if answer is in choices
        if not self._is_answer_in_choices(problem):
            issues.append(ValidationIssue(
                category=ValidationCategory.ANSWER_CORRECTNESS,
                severity='critical',
                description="Correct answer not found in multiple choice options",
                suggestion="Ensure the answer matches one of the provided choices",
                location="answer"
            ))
            score -= 0.5
        
        # Check if answer is unique
        if not self._is_answer_unique(problem):
            issues.append(ValidationIssue(
                category=ValidationCategory.ANSWER_CORRECTNESS,
                severity='major',
                description="Multiple choices could be considered correct",
                suggestion="Ensure only one choice is clearly correct",
                location="choices"
            ))
            score -= 0.3
        
        return max(0.0, score)

    def _validate_choice_quality(self, problem: GeneratedProblem, issues: List[ValidationIssue]) -> float:
        """Validate quality of multiple choice options."""
        score = 1.0
        
        # Check for plausible distractors
        if not self._has_plausible_distractors(problem):
            issues.append(ValidationIssue(
                category=ValidationCategory.CHOICE_QUALITY,
                severity='minor',
                description="Distractors are not sufficiently plausible",
                suggestion="Create more realistic incorrect options",
                location="choices"
            ))
            score -= 0.2
        
        # Check for choice balance
        if not self._are_choices_balanced(problem):
            issues.append(ValidationIssue(
                category=ValidationCategory.CHOICE_QUALITY,
                severity='minor',
                description="Choices are not well-balanced in length or complexity",
                suggestion="Balance the length and complexity of all choices",
                location="choices"
            ))
            score -= 0.1
        
        return max(0.0, score)

    def _has_logical_contradictions(self, problem: GeneratedProblem) -> bool:
        """Check for logical contradictions in the problem."""
        # This is a simplified check - in practice, this would be more sophisticated
        constraints_text = " ".join(problem.constraints).lower()
        
        # Look for obvious contradictions
        if "not" in constraints_text and any(word in constraints_text for word in ["always", "never"]):
            # Check for patterns like "A is not B" and "A is always B"
            return True
        
        return False

    def _are_reasoning_steps_logical(self, problem: GeneratedProblem) -> bool:
        """Check if reasoning steps follow logical progression."""
        if len(problem.reasoning_steps) < 2:
            return True  # Too few steps to check progression
        
        # Basic check for logical flow
        steps_text = " ".join(problem.reasoning_steps).lower()
        
        # Look for logical connectors
        logical_connectors = ["therefore", "thus", "hence", "because", "since", "if", "then"]
        has_connectors = any(connector in steps_text for connector in logical_connectors)
        
        return has_connectors or len(problem.reasoning_steps) <= 3

    def _does_explanation_support_answer(self, problem: GeneratedProblem) -> bool:
        """Check if explanation supports the given answer."""
        explanation_lower = problem.explanation.lower()
        answer_lower = problem.answer.lower()
        
        # Check if answer appears in explanation
        if answer_lower in explanation_lower:
            return True
        
        # Check if explanation mentions the correct choice content
        for choice in problem.choices:
            if problem.answer in choice and any(word in explanation_lower for word in choice.lower().split()):
                return True
        
        return False

    def _is_valid_answer_format(self, answer: str) -> bool:
        """Check if answer format is valid."""
        if not answer:
            return False
        
        # Check if it's a single letter
        if len(answer) == 1 and answer.upper() in 'ABCD':
            return True
        
        # Check if it's a longer answer (should match choice content)
        return len(answer) > 1

    def _has_unclear_language(self, text: str) -> bool:
        """Check for unclear or ambiguous language."""
        unclear_patterns = [
            r'\b(maybe|perhaps|possibly|might be)\b',
            r'\b(unclear|ambiguous|confusing)\b',
            r'\?\?+',  # Multiple question marks
            r'\b(or something|etc\.?)\b'
        ]
        
        for pattern in unclear_patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        
        return False

    def _check_grammar(self, problem: GeneratedProblem) -> List[str]:
        """Basic grammar checking."""
        issues = []
        text = problem.question + " " + problem.explanation
        
        # Check for common grammar issues
        if re.search(r'\b(a|an)\s+[aeiou]', text, re.IGNORECASE):
            # This is actually correct, but let's check for "a" before vowels
            if re.search(r'\ba\s+[aeiou]', text, re.IGNORECASE):
                issues.append("Incorrect article usage")
        
        # Check for sentence fragments
        sentences = re.split(r'[.!?]+', text)
        for sentence in sentences:
            if sentence.strip() and len(sentence.strip().split()) < 3:
                issues.append("Possible sentence fragment")
                break
        
        return issues

    def _calculate_readability(self, text: str) -> float:
        """Calculate readability score (simplified)."""
        words = text.split()
        sentences = len(re.split(r'[.!?]+', text))
        
        if not words or sentences == 0:
            return 0.0
        
        avg_words_per_sentence = len(words) / sentences
        avg_syllables_per_word = sum(self._count_syllables(word) for word in words) / len(words)
        
        # Simplified readability score (higher is more readable)
        score = 1.0 - (avg_words_per_sentence / 20.0) - (avg_syllables_per_word / 3.0)
        return max(0.0, min(1.0, score))

    def _count_syllables(self, word: str) -> int:
        """Count syllables in a word (simplified)."""
        word = word.lower()
        vowels = 'aeiouy'
        syllable_count = 0
        prev_was_vowel = False
        
        for char in word:
            if char in vowels:
                if not prev_was_vowel:
                    syllable_count += 1
                prev_was_vowel = True
            else:
                prev_was_vowel = False
        
        # Handle silent e
        if word.endswith('e') and syllable_count > 1:
            syllable_count -= 1
        
        return max(1, syllable_count)

    def _teaches_target_concept(self, problem: GeneratedProblem) -> bool:
        """Check if problem teaches the target concept."""
        topic_lower = problem.topic.lower()
        question_lower = problem.question.lower()
        
        # Check if question relates to the topic
        if "truth" in topic_lower or "liar" in topic_lower:
            return any(word in question_lower for word in ["truth", "lie", "honest", "dishonest"])
        elif "seating" in topic_lower:
            return any(word in question_lower for word in ["sit", "seat", "arrange", "position"])
        elif "blood" in topic_lower or "family" in topic_lower:
            return any(word in question_lower for word in self.relationship_terms)
        
        return True  # Default to true for unknown topics

    def _is_difficulty_appropriate(self, problem: GeneratedProblem) -> bool:
        """Check if difficulty matches the specified level."""
        # This would ideally use the difficulty metrics from DifficultyManager
        # For now, use simple heuristics
        
        num_constraints = len(problem.constraints)
        num_reasoning_steps = len(problem.reasoning_steps)
        
        if problem.difficulty == DifficultyLevel.BEGINNER:
            return num_constraints <= 3 and num_reasoning_steps <= 3
        elif problem.difficulty == DifficultyLevel.INTERMEDIATE:
            return 2 <= num_constraints <= 5 and 2 <= num_reasoning_steps <= 5
        elif problem.difficulty == DifficultyLevel.ADVANCED:
            return 3 <= num_constraints <= 7 and 3 <= num_reasoning_steps <= 6
        else:  # EXPERT
            return num_constraints >= 4 and num_reasoning_steps >= 4

    def _supports_learning_progression(self, problem: GeneratedProblem) -> bool:
        """Check if problem supports systematic learning progression."""
        # Check if reasoning steps build on each other
        steps = problem.reasoning_steps
        if len(steps) < 2:
            return True
        
        # Look for progression indicators
        progression_words = ["first", "then", "next", "finally", "therefore", "thus"]
        steps_text = " ".join(steps).lower()
        
        return any(word in steps_text for word in progression_words)

    def _is_answer_in_choices(self, problem: GeneratedProblem) -> bool:
        """Check if the answer is found in the choices."""
        answer = problem.answer.strip()
        
        # Check if answer is a letter
        if len(answer) == 1 and answer.upper() in 'ABCD':
            return True
        
        # Check if answer content matches any choice
        for choice in problem.choices:
            if answer in choice or any(word in choice.lower() for word in answer.lower().split()):
                return True
        
        return False

    def _is_answer_unique(self, problem: GeneratedProblem) -> bool:
        """Check if only one choice is correct."""
        # This is a simplified check
        # In practice, this would require domain-specific logic
        return True  # Assume unique for now

    def _has_plausible_distractors(self, problem: GeneratedProblem) -> bool:
        """Check if distractors are plausible."""
        # Check if distractors are not obviously wrong
        choices_text = " ".join(problem.choices).lower()
        
        # Look for obviously wrong patterns
        obvious_wrong = ["none of the above", "impossible", "cannot be determined"]
        
        for wrong in obvious_wrong:
            if wrong in choices_text:
                return False  # Has obvious distractors
        
        return True

    def _are_choices_balanced(self, problem: GeneratedProblem) -> bool:
        """Check if choices are balanced in length and complexity."""
        if len(problem.choices) != 4:
            return False
        
        lengths = [len(choice) for choice in problem.choices]
        avg_length = sum(lengths) / len(lengths)
        
        # Check if all choices are within reasonable range of average length
        for length in lengths:
            if abs(length - avg_length) > avg_length * 0.5:  # More than 50% difference
                return False
        
        return True

    def _generate_recommendations(self, issues: List[ValidationIssue], 
                                category_scores: Dict[ValidationCategory, float]) -> List[str]:
        """Generate recommendations based on validation results."""
        recommendations = []
        
        # Critical issues
        critical_issues = [issue for issue in issues if issue.severity == 'critical']
        if critical_issues:
            recommendations.append("Address critical issues before using this problem")
        
        # Category-specific recommendations
        for category, score in category_scores.items():
            if score < 0.7:
                if category == ValidationCategory.LOGICAL_CONSISTENCY:
                    recommendations.append("Review logical consistency and remove contradictions")
                elif category == ValidationCategory.STRUCTURAL_INTEGRITY:
                    recommendations.append("Fix structural issues with question format")
                elif category == ValidationCategory.CLARITY_AND_READABILITY:
                    recommendations.append("Improve clarity and readability of the text")
                elif category == ValidationCategory.EDUCATIONAL_VALUE:
                    recommendations.append("Enhance educational value and concept focus")
                elif category == ValidationCategory.ANSWER_CORRECTNESS:
                    recommendations.append("Verify answer correctness and choice alignment")
                elif category == ValidationCategory.CHOICE_QUALITY:
                    recommendations.append("Improve quality and plausibility of distractors")
        
        return recommendations

    def batch_validate(self, problems: List[GeneratedProblem]) -> List[ValidationResult]:
        """
        Validate a batch of problems.
        
        Args:
            problems: List of problems to validate
            
        Returns:
            List of validation results
        """
        results = []
        
        for i, problem in enumerate(problems):
            try:
                result = self.validate_problem(problem)
                results.append(result)
                
                if (i + 1) % 10 == 0:
                    logger.info(f"Validated {i + 1}/{len(problems)} problems")
                    
            except Exception as e:
                logger.error(f"Error validating problem {i}: {e}")
                # Create a failed validation result
                results.append(ValidationResult(
                    is_valid=False,
                    overall_score=0.0,
                    category_scores={cat: 0.0 for cat in ValidationCategory},
                    issues=[ValidationIssue(
                        category=ValidationCategory.STRUCTURAL_INTEGRITY,
                        severity='critical',
                        description=f"Validation failed: {str(e)}"
                    )],
                    recommendations=["Fix validation errors"]
                ))
        
        return results

    def get_validation_summary(self, results: List[ValidationResult]) -> Dict[str, Any]:
        """
        Generate a summary of validation results.
        
        Args:
            results: List of validation results
            
        Returns:
            Summary statistics
        """
        if not results:
            return {}
        
        valid_count = sum(1 for r in results if r.is_valid)
        avg_score = sum(r.overall_score for r in results) / len(results)
        
        # Category averages
        category_averages = {}
        for category in ValidationCategory:
            scores = [r.category_scores.get(category, 0.0) for r in results]
            category_averages[category.value] = sum(scores) / len(scores)
        
        # Issue statistics
        all_issues = [issue for result in results for issue in result.issues]
        issue_counts = {
            'critical': len([i for i in all_issues if i.severity == 'critical']),
            'major': len([i for i in all_issues if i.severity == 'major']),
            'minor': len([i for i in all_issues if i.severity == 'minor'])
        }
        
        return {
            'total_problems': len(results),
            'valid_problems': valid_count,
            'validation_rate': valid_count / len(results),
            'average_score': avg_score,
            'category_averages': category_averages,
            'issue_counts': issue_counts,
            'quality_distribution': self._get_quality_distribution(results)
        }

    def _get_quality_distribution(self, results: List[ValidationResult]) -> Dict[str, int]:
        """Get distribution of quality levels."""
        distribution = {'excellent': 0, 'good': 0, 'acceptable': 0, 'poor': 0}
        
        for result in results:
            if result.overall_score >= 0.9:
                distribution['excellent'] += 1
            elif result.overall_score >= 0.8:
                distribution['good'] += 1
            elif result.overall_score >= 0.7:
                distribution['acceptable'] += 1
            else:
                distribution['poor'] += 1
        
        return distribution

