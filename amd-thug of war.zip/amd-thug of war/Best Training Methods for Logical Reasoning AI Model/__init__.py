"""
Enhanced Synthetic Data Generation System for AMD AI Premier League

This module provides advanced synthetic data generation capabilities for logical reasoning tasks,
including Truth-teller/Liar problems, Seating Arrangements, and Blood Relations puzzles.

Key Features:
- Constraint-based problem generation
- Difficulty progression and curriculum learning
- Logical consistency validation
- Quality assurance and metrics
- Scalable architecture for large-scale data generation
"""

from .base_generator import BaseGenerator, DifficultyLevel, ProblemQuality
from .truth_liar_generator import TruthLiarGenerator
from .seating_generator import SeatingGenerator
from .blood_relations_generator import BloodRelationsGenerator
from .difficulty_manager import DifficultyManager, CurriculumLevel
from .quality_validator import QualityValidator, ValidationResult
from .dataset_builder import DatasetBuilder, DatasetConfig

__all__ = [
    'BaseGenerator',
    'DifficultyLevel', 
    'ProblemQuality',
    'TruthLiarGenerator',
    'SeatingGenerator', 
    'BloodRelationsGenerator',
    'DifficultyManager',
    'CurriculumLevel',
    'QualityValidator',
    'ValidationResult',
    'DatasetBuilder',
    'DatasetConfig'
]

__version__ = "1.0.0"
__author__ = "Enhanced AAIPL Team"

