"""
Curriculum Learning Trainer

This module implements advanced curriculum learning strategies for logical
reasoning tasks, integrating with the data generation system to provide
systematic Easy-to-Hard (E2H) progression.
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
import logging
from pathlib import Path
import json
from transformers import AutoModelForCausalLM, AutoTokenizer
from torch.utils.data import DataLoader, Dataset, ConcatDataset

from .training_config import CurriculumConfig
from .grpo_trainer import GRPOTrainer, create_grpo_dataset
from .dpo_trainer import DPOTrainer, create_dpo_dataset
from .training_utils import TrainingMetrics, ModelEvaluator, MetricsLogger
from .optimization_utils import AMDOptimizer, MemoryOptimizer
from ..data_generation.difficulty_manager import DifficultyManager, DifficultyMetrics
from ..data_generation.base_generator import DifficultyLevel, GeneratedProblem

logger = logging.getLogger(__name__)


@dataclass
class CurriculumStage:
    """Represents a curriculum learning stage."""
    stage_id: int
    name: str
    difficulty_range: Tuple[float, float]
    target_concepts: List[str]
    dataset_path: str
    training_config: Dict[str, Any]
    advancement_criteria: Dict[str, float]
    completed: bool = False
    performance_history: List[float] = None
    
    def __post_init__(self):
        if self.performance_history is None:
            self.performance_history = []


class CurriculumDataManager:
    """Manages curriculum datasets and progression."""
    
    def __init__(self, 
                 config: CurriculumConfig,
                 data_dir: str):
        self.config = config
        self.data_dir = Path(data_dir)
        self.difficulty_manager = DifficultyManager()
        
        # Initialize curriculum stages
        self.stages = self._initialize_stages()
        self.current_stage = 0
        
        logger.info(f"Curriculum Data Manager initialized with {len(self.stages)} stages")
    
    def _initialize_stages(self) -> List[CurriculumStage]:
        """Initialize curriculum stages based on configuration."""
        stages = []
        
        stage_configs = [
            {
                'name': 'Foundation',
                'difficulty_range': (1.0, 2.0),
                'target_concepts': ['basic_reasoning', 'simple_constraints', 'direct_relationships'],
                'advancement_threshold': 0.80
            },
            {
                'name': 'Building',
                'difficulty_range': (1.8, 3.0),
                'target_concepts': ['multi_step_reasoning', 'moderate_constraints', 'logical_chains'],
                'advancement_threshold': 0.85
            },
            {
                'name': 'Mastery',
                'difficulty_range': (2.5, 4.0),
                'target_concepts': ['complex_reasoning', 'multiple_constraints', 'abstract_relationships'],
                'advancement_threshold': 0.88
            },
            {
                'name': 'Expertise',
                'difficulty_range': (3.5, 5.0),
                'target_concepts': ['expert_reasoning', 'intricate_constraints', 'meta_reasoning'],
                'advancement_threshold': 0.90
            }
        ]
        
        for i, stage_config in enumerate(stage_configs[:self.config.curriculum_stages]):
            stage = CurriculumStage(
                stage_id=i,
                name=stage_config['name'],
                difficulty_range=stage_config['difficulty_range'],
                target_concepts=stage_config['target_concepts'],
                dataset_path=str(self.data_dir / f"stage_{i}_{stage_config['name'].lower()}.json"),
                training_config={
                    'learning_rate': self.config.stage_learning_rates[i] if i < len(self.config.stage_learning_rates) else 5e-6,
                    'num_epochs': self.config.stage_epochs[i] if i < len(self.config.stage_epochs) else 3,
                    'batch_size': self.config.stage_batch_sizes[i] if i < len(self.config.stage_batch_sizes) else 4
                },
                advancement_criteria={
                    'accuracy_threshold': stage_config['advancement_threshold'],
                    'min_problems': self.config.min_problems_per_stage,
                    'performance_window': self.config.performance_window
                }
            )
            stages.append(stage)
        
        return stages
    
    def get_current_stage(self) -> CurriculumStage:
        """Get the current curriculum stage."""
        return self.stages[self.current_stage]
    
    def load_stage_dataset(self, stage_id: int) -> List[Dict[str, Any]]:
        """Load dataset for a specific stage."""
        stage = self.stages[stage_id]
        
        try:
            with open(stage.dataset_path, 'r') as f:
                data = json.load(f)
            
            logger.info(f"Loaded {len(data)} problems for stage {stage_id} ({stage.name})")
            return data
        
        except FileNotFoundError:
            logger.warning(f"Dataset not found for stage {stage_id}: {stage.dataset_path}")
            return []
    
    def create_mixed_dataset(self, current_stage_id: int) -> List[Dict[str, Any]]:
        """Create a mixed dataset including previous stages."""
        if not self.config.enable_data_mixing:
            return self.load_stage_dataset(current_stage_id)
        
        mixed_data = []
        
        # Add current stage data
        current_data = self.load_stage_dataset(current_stage_id)
        mixed_data.extend(current_data)
        
        # Add data from previous stages
        if current_stage_id > 0 and self.config.mixing_ratio > 0:
            for prev_stage_id in range(current_stage_id):
                prev_data = self.load_stage_dataset(prev_stage_id)
                
                # Sample a portion of previous stage data
                num_samples = int(len(prev_data) * self.config.mixing_ratio)
                if num_samples > 0:
                    sampled_data = np.random.choice(prev_data, num_samples, replace=False).tolist()
                    mixed_data.extend(sampled_data)
        
        # Shuffle the mixed dataset
        np.random.shuffle(mixed_data)
        
        logger.info(f"Created mixed dataset with {len(mixed_data)} problems")
        return mixed_data
    
    def should_advance_stage(self, performance_history: List[float]) -> bool:
        """Determine if should advance to next stage."""
        if self.current_stage >= len(self.stages) - 1:
            return False  # Already at final stage
        
        current_stage = self.get_current_stage()
        criteria = current_stage.advancement_criteria
        
        # Check minimum number of problems
        if len(performance_history) < criteria['min_problems']:
            return False
        
        # Check performance in recent window
        window_size = criteria['performance_window']
        recent_performance = performance_history[-window_size:]
        avg_performance = np.mean(recent_performance)
        
        threshold = criteria['accuracy_threshold']
        
        if avg_performance >= threshold:
            logger.info(f"Stage {self.current_stage} advancement criteria met: {avg_performance:.3f} >= {threshold}")
            return True
        
        return False
    
    def advance_to_next_stage(self) -> bool:
        """Advance to the next curriculum stage."""
        if self.current_stage < len(self.stages) - 1:
            # Mark current stage as completed
            self.stages[self.current_stage].completed = True
            
            # Advance to next stage
            self.current_stage += 1
            
            current_stage = self.get_current_stage()
            logger.info(f"Advanced to stage {self.current_stage}: {current_stage.name}")
            logger.info(f"Target concepts: {current_stage.target_concepts}")
            logger.info(f"Difficulty range: {current_stage.difficulty_range}")
            
            return True
        else:
            logger.info("Already at the final curriculum stage")
            return False
    
    def get_curriculum_progress(self) -> Dict[str, Any]:
        """Get curriculum progress summary."""
        completed_stages = sum(1 for stage in self.stages if stage.completed)
        
        return {
            'current_stage': self.current_stage,
            'current_stage_name': self.get_current_stage().name,
            'completed_stages': completed_stages,
            'total_stages': len(self.stages),
            'progress_percentage': (completed_stages / len(self.stages)) * 100,
            'stage_details': [
                {
                    'stage_id': stage.stage_id,
                    'name': stage.name,
                    'completed': stage.completed,
                    'difficulty_range': stage.difficulty_range,
                    'target_concepts': stage.target_concepts
                }
                for stage in self.stages
            ]
        }


class CurriculumTrainer:
    """
    Curriculum Learning Trainer that orchestrates progressive difficulty training.
    
    Integrates with GRPO/DPO trainers and data generation system to provide
    systematic Easy-to-Hard curriculum learning.
    """
    
    def __init__(self,
                 config: CurriculumConfig,
                 model: Optional[AutoModelForCausalLM] = None,
                 tokenizer: Optional[AutoTokenizer] = None,
                 data_dir: str = "./curriculum_data"):
        """
        Initialize curriculum trainer.
        
        Args:
            config: Curriculum learning configuration
            model: Pre-trained model (will be loaded if None)
            tokenizer: Tokenizer (will be loaded if None)
            data_dir: Directory containing curriculum datasets
        """
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Initialize model and tokenizer
        self.model = model or self._load_model()
        self.tokenizer = tokenizer or self._load_tokenizer()
        
        # Initialize curriculum data manager
        self.data_manager = CurriculumDataManager(config, data_dir)
        
        # Initialize base trainer (GRPO or DPO)
        self.base_trainer = self._create_base_trainer()
        
        # Initialize metrics and logging
        self.metrics = TrainingMetrics()
        self.evaluator = ModelEvaluator(self.model, self.tokenizer)
        self.metrics_logger = MetricsLogger(
            log_to_wandb=getattr(config, 'enable_wandb', False),
            log_file=f"{config.output_dir}/curriculum_metrics.json"
        )
        
        # AMD optimizations
        if getattr(config, 'use_rocm_optimizations', False):
            self.amd_optimizer = AMDOptimizer(config)
            self.memory_optimizer = MemoryOptimizer(config)
            self._apply_amd_optimizations()
        
        # Training state
        self.global_step = 0
        self.curriculum_history = []
        
        logger.info("Curriculum Trainer initialized")
    
    def _load_model(self) -> AutoModelForCausalLM:
        """Load the pre-trained model."""
        model = AutoModelForCausalLM.from_pretrained(
            self.config.model_name,
            revision=self.config.model_revision,
            torch_dtype=getattr(torch, self.config.torch_dtype),
            attn_implementation=self.config.attn_implementation,
            device_map="auto",
            low_cpu_mem_usage=True,
            use_cache=False
        )
        
        if self.config.gradient_checkpointing:
            model.gradient_checkpointing_enable()
        
        return model
    
    def _load_tokenizer(self) -> AutoTokenizer:
        """Load the tokenizer."""
        tokenizer = AutoTokenizer.from_pretrained(
            self.config.model_name,
            revision=self.config.model_revision
        )
        
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        
        return tokenizer
    
    def _create_base_trainer(self):
        """Create the base trainer (GRPO or DPO)."""
        # For curriculum learning, we'll use GRPO as the base trainer
        from .training_config import GRPOConfig
        
        grpo_config = GRPOConfig(
            model_name=self.config.model_name,
            learning_rate=self.config.learning_rate,
            num_train_epochs=1,  # Will be overridden per stage
            per_device_train_batch_size=self.config.per_device_train_batch_size,
            gradient_accumulation_steps=self.config.gradient_accumulation_steps,
            max_length=self.config.max_length,
            output_dir=self.config.output_dir,
            eval_steps=self.config.eval_steps,
            save_steps=self.config.save_steps,
            logging_steps=self.config.logging_steps
        )
        
        return GRPOTrainer(
            config=grpo_config,
            model=self.model,
            tokenizer=self.tokenizer
        )
    
    def _apply_amd_optimizations(self):
        """Apply AMD MI300x optimizations."""
        self.model = self.amd_optimizer.optimize_model_for_amd(self.model)
        self.memory_optimizer.optimize_memory_usage()
    
    def train_curriculum(self) -> Dict[str, Any]:
        """
        Train the model using curriculum learning.
        
        Returns:
            Training results and curriculum progress
        """
        logger.info("Starting curriculum learning training")
        
        curriculum_results = {
            'stages_completed': 0,
            'total_training_time': 0,
            'stage_results': [],
            'final_performance': {}
        }
        
        start_time = torch.cuda.Event(enable_timing=True)
        end_time = torch.cuda.Event(enable_timing=True)
        start_time.record()
        
        # Train through each curriculum stage
        while self.data_manager.current_stage < len(self.data_manager.stages):
            stage_result = self._train_stage()
            curriculum_results['stage_results'].append(stage_result)
            
            # Check advancement criteria
            if self.config.adaptive_progression:
                performance_history = stage_result.get('performance_history', [])
                if self.data_manager.should_advance_stage(performance_history):
                    if not self.data_manager.advance_to_next_stage():
                        break  # Reached final stage
                else:
                    logger.info("Advancement criteria not met, continuing current stage")
                    # Could implement additional training or data augmentation here
            else:
                # Fixed progression
                if not self.data_manager.advance_to_next_stage():
                    break
        
        end_time.record()
        torch.cuda.synchronize()
        total_time = start_time.elapsed_time(end_time) / 1000  # Convert to seconds
        
        curriculum_results['stages_completed'] = len(curriculum_results['stage_results'])
        curriculum_results['total_training_time'] = total_time
        
        # Final evaluation
        if self.config.eval_on_all_stages:
            curriculum_results['final_performance'] = self._evaluate_on_all_stages()
        
        # Save curriculum progress
        progress = self.data_manager.get_curriculum_progress()
        curriculum_results['curriculum_progress'] = progress
        
        logger.info(f"Curriculum training completed: {curriculum_results['stages_completed']} stages")
        
        return curriculum_results
    
    def _train_stage(self) -> Dict[str, Any]:
        """Train on the current curriculum stage."""
        current_stage = self.data_manager.get_current_stage()
        
        logger.info(f"Training stage {current_stage.stage_id}: {current_stage.name}")
        logger.info(f"Difficulty range: {current_stage.difficulty_range}")
        logger.info(f"Target concepts: {current_stage.target_concepts}")
        
        # Load stage dataset
        stage_data = self.data_manager.create_mixed_dataset(current_stage.stage_id)
        
        if not stage_data:
            logger.warning(f"No data available for stage {current_stage.stage_id}")
            return {'stage_id': current_stage.stage_id, 'status': 'skipped', 'reason': 'no_data'}
        
        # Create dataset
        train_dataset = create_grpo_dataset(stage_data, self.tokenizer, self.base_trainer.config)
        
        # Update training configuration for this stage
        self._update_stage_config(current_stage)
        
        # Train on stage
        stage_start_time = torch.cuda.Event(enable_timing=True)
        stage_end_time = torch.cuda.Event(enable_timing=True)
        stage_start_time.record()
        
        training_result = self.base_trainer.train(
            train_dataset=train_dataset,
            num_epochs=current_stage.training_config['num_epochs']
        )
        
        stage_end_time.record()
        torch.cuda.synchronize()
        stage_time = stage_start_time.elapsed_time(stage_end_time) / 1000
        
        # Evaluate stage performance
        stage_performance = self._evaluate_stage_performance(stage_data[:100])  # Sample for evaluation
        
        # Update stage performance history
        current_stage.performance_history.extend(stage_performance.get('accuracy_history', []))
        
        # Log stage completion
        stage_result = {
            'stage_id': current_stage.stage_id,
            'stage_name': current_stage.name,
            'training_time': stage_time,
            'final_accuracy': stage_performance.get('final_accuracy', 0.0),
            'performance_history': current_stage.performance_history,
            'training_result': training_result,
            'stage_performance': stage_performance
        }
        
        # Log metrics
        self.metrics_logger.log_metrics(
            {
                'stage_id': current_stage.stage_id,
                'stage_accuracy': stage_performance.get('final_accuracy', 0.0),
                'stage_training_time': stage_time
            },
            step=self.global_step,
            prefix='curriculum'
        )
        
        self.curriculum_history.append(stage_result)
        
        logger.info(f"Stage {current_stage.stage_id} completed with accuracy: {stage_performance.get('final_accuracy', 0.0):.3f}")
        
        return stage_result
    
    def _update_stage_config(self, stage: CurriculumStage):
        """Update trainer configuration for the current stage."""
        # Update learning rate
        self.base_trainer.optimizer.param_groups[0]['lr'] = stage.training_config['learning_rate']
        
        # Update batch size if needed
        if hasattr(self.base_trainer.config, 'per_device_train_batch_size'):
            self.base_trainer.config.per_device_train_batch_size = stage.training_config['batch_size']
        
        logger.info(f"Updated config for stage {stage.stage_id}: LR={stage.training_config['learning_rate']}, BS={stage.training_config['batch_size']}")
    
    def _evaluate_stage_performance(self, eval_data: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Evaluate performance on the current stage."""
        # Extract questions and answers
        questions = [item['question'] for item in eval_data]
        correct_answers = [item['answer'] for item in eval_data]
        
        # Evaluate reasoning accuracy
        performance = self.evaluator.evaluate_reasoning_accuracy(
            questions=questions,
            correct_answers=correct_answers
        )
        
        # Add accuracy history (simplified - in practice would track over training)
        performance['accuracy_history'] = [performance['exact_accuracy']]
        performance['final_accuracy'] = performance['exact_accuracy']
        
        return performance
    
    def _evaluate_on_all_stages(self) -> Dict[str, Any]:
        """Evaluate the final model on all curriculum stages."""
        all_stage_performance = {}
        
        for stage in self.data_manager.stages:
            stage_data = self.data_manager.load_stage_dataset(stage.stage_id)
            
            if stage_data:
                # Sample data for evaluation
                eval_data = stage_data[:50] if len(stage_data) > 50 else stage_data
                performance = self._evaluate_stage_performance(eval_data)
                
                all_stage_performance[f'stage_{stage.stage_id}_{stage.name}'] = {
                    'accuracy': performance['final_accuracy'],
                    'difficulty_range': stage.difficulty_range,
                    'num_problems': len(eval_data)
                }
        
        # Compute overall performance
        accuracies = [perf['accuracy'] for perf in all_stage_performance.values()]
        all_stage_performance['overall_accuracy'] = np.mean(accuracies) if accuracies else 0.0
        
        return all_stage_performance
    
    def save_curriculum_state(self, output_path: str):
        """Save the current curriculum training state."""
        state = {
            'current_stage': self.data_manager.current_stage,
            'curriculum_history': self.curriculum_history,
            'stage_states': [
                {
                    'stage_id': stage.stage_id,
                    'name': stage.name,
                    'completed': stage.completed,
                    'performance_history': stage.performance_history
                }
                for stage in self.data_manager.stages
            ],
            'global_step': self.global_step,
            'config': self.config.to_dict() if hasattr(self.config, 'to_dict') else self.config.__dict__
        }
        
        with open(output_path, 'w') as f:
            json.dump(state, f, indent=2)
        
        logger.info(f"Curriculum state saved to {output_path}")
    
    def load_curriculum_state(self, state_path: str):
        """Load curriculum training state."""
        with open(state_path, 'r') as f:
            state = json.load(f)
        
        self.data_manager.current_stage = state['current_stage']
        self.curriculum_history = state['curriculum_history']
        self.global_step = state['global_step']
        
        # Restore stage states
        for stage_state in state['stage_states']:
            stage_id = stage_state['stage_id']
            if stage_id < len(self.data_manager.stages):
                stage = self.data_manager.stages[stage_id]
                stage.completed = stage_state['completed']
                stage.performance_history = stage_state['performance_history']
        
        logger.info(f"Curriculum state loaded from {state_path}")
    
    def get_curriculum_summary(self) -> Dict[str, Any]:
        """Get a comprehensive curriculum training summary."""
        progress = self.data_manager.get_curriculum_progress()
        
        summary = {
            'curriculum_progress': progress,
            'training_history': self.curriculum_history,
            'current_stage_info': {
                'stage_id': self.data_manager.current_stage,
                'stage_name': self.data_manager.get_current_stage().name,
                'difficulty_range': self.data_manager.get_current_stage().difficulty_range
            },
            'performance_trends': self._analyze_performance_trends(),
            'recommendations': self._generate_recommendations()
        }
        
        return summary
    
    def _analyze_performance_trends(self) -> Dict[str, Any]:
        """Analyze performance trends across curriculum stages."""
        if not self.curriculum_history:
            return {}
        
        # Extract accuracy trends
        stage_accuracies = [
            result.get('final_accuracy', 0.0) 
            for result in self.curriculum_history
        ]
        
        trends = {
            'accuracy_progression': stage_accuracies,
            'improvement_rate': 0.0,
            'consistency': 0.0
        }
        
        if len(stage_accuracies) > 1:
            # Calculate improvement rate
            trends['improvement_rate'] = (stage_accuracies[-1] - stage_accuracies[0]) / len(stage_accuracies)
            
            # Calculate consistency (inverse of variance)
            trends['consistency'] = 1.0 / (np.var(stage_accuracies) + 1e-8)
        
        return trends
    
    def _generate_recommendations(self) -> List[str]:
        """Generate recommendations based on curriculum progress."""
        recommendations = []
        
        # Analyze current progress
        progress = self.data_manager.get_curriculum_progress()
        
        if progress['progress_percentage'] < 50:
            recommendations.append("Continue curriculum training to reach advanced stages")
        
        # Analyze performance trends
        trends = self._analyze_performance_trends()
        
        if trends.get('improvement_rate', 0) < 0.01:
            recommendations.append("Consider adjusting learning rates or training duration")
        
        if trends.get('consistency', 0) < 0.5:
            recommendations.append("Performance is inconsistent across stages - review data quality")
        
        # Check current stage performance
        current_stage = self.data_manager.get_current_stage()
        if current_stage.performance_history:
            recent_performance = np.mean(current_stage.performance_history[-10:])
            if recent_performance < 0.7:
                recommendations.append(f"Current stage performance is low ({recent_performance:.2f}) - consider additional training")
        
        return recommendations


def create_curriculum_trainer(config: CurriculumConfig,
                            model_path: Optional[str] = None,
                            data_dir: str = "./curriculum_data") -> CurriculumTrainer:
    """Create a curriculum trainer with optional pre-trained model."""
    model = None
    tokenizer = None
    
    if model_path:
        model = AutoModelForCausalLM.from_pretrained(model_path)
        tokenizer = AutoTokenizer.from_pretrained(model_path)
    
    return CurriculumTrainer(
        config=config,
        model=model,
        tokenizer=tokenizer,
        data_dir=data_dir
    )

