"""
Training Configuration Classes

This module defines comprehensive configuration classes for all training
methodologies including GRPO, DPO, curriculum learning, and hardware
optimization settings.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Any, Optional, Union
from enum import Enum
import torch


class TrainingMethod(Enum):
    """Available training methods."""
    GRPO = "grpo"
    DPO = "dpo"
    SFT = "sft"
    CURRICULUM = "curriculum"
    SELF_TRAINING = "self_training"


class SchedulerType(Enum):
    """Learning rate scheduler types."""
    LINEAR = "linear"
    COSINE = "cosine"
    POLYNOMIAL = "polynomial"
    CONSTANT = "constant"
    WARMUP_COSINE = "warmup_cosine"


class OptimizerType(Enum):
    """Optimizer types."""
    ADAMW = "adamw"
    ADAM = "adam"
    SGD = "sgd"
    ADAFACTOR = "adafactor"


@dataclass
class BaseTrainingConfig:
    """Base configuration for all training methods."""
    
    # Model settings
    model_name: str = "Qwen/Qwen2.5-4B"
    model_revision: Optional[str] = None
    torch_dtype: str = "bfloat16"
    attn_implementation: str = "flash_attention_2"
    
    # Training hyperparameters
    learning_rate: float = 5e-6
    num_train_epochs: int = 3
    per_device_train_batch_size: int = 4
    per_device_eval_batch_size: int = 8
    gradient_accumulation_steps: int = 4
    max_grad_norm: float = 1.0
    weight_decay: float = 0.01
    warmup_ratio: float = 0.1
    
    # Optimizer settings
    optimizer_type: OptimizerType = OptimizerType.ADAMW
    adam_beta1: float = 0.9
    adam_beta2: float = 0.999
    adam_epsilon: float = 1e-8
    
    # Scheduler settings
    lr_scheduler_type: SchedulerType = SchedulerType.COSINE
    lr_scheduler_kwargs: Dict[str, Any] = field(default_factory=dict)
    
    # Data settings
    max_length: int = 2048
    max_prompt_length: int = 1024
    dataset_num_proc: int = 4
    dataloader_num_workers: int = 4
    
    # Evaluation settings
    eval_strategy: str = "steps"
    eval_steps: int = 500
    eval_accumulation_steps: Optional[int] = None
    metric_for_best_model: str = "eval_accuracy"
    greater_is_better: bool = True
    
    # Logging and saving
    logging_steps: int = 10
    save_strategy: str = "steps"
    save_steps: int = 500
    save_total_limit: int = 3
    load_best_model_at_end: bool = True
    
    # Hardware optimization
    bf16: bool = True
    fp16: bool = False
    tf32: bool = True
    dataloader_pin_memory: bool = True
    gradient_checkpointing: bool = True
    
    # AMD MI300x specific
    use_rocm_optimizations: bool = True
    rocm_memory_fraction: float = 0.95
    enable_kv_cache_optimization: bool = True
    
    # Reproducibility
    seed: int = 42
    data_seed: int = 42
    
    # Output settings
    output_dir: str = "./training_output"
    logging_dir: Optional[str] = None
    run_name: Optional[str] = None
    
    # Advanced settings
    remove_unused_columns: bool = False
    label_names: List[str] = field(default_factory=lambda: ["labels"])
    
    def __post_init__(self):
        if self.logging_dir is None:
            self.logging_dir = f"{self.output_dir}/logs"


@dataclass
class GRPOConfig(BaseTrainingConfig):
    """Configuration for Group Relative Policy Optimization (GRPO)."""
    
    # GRPO specific parameters
    beta: float = 0.1  # KL penalty coefficient
    group_size: int = 64  # Group size for relative advantages
    response_length: int = 1024  # Maximum response length
    
    # PPO-style parameters adapted for GRPO
    ppo_epochs: int = 4
    mini_batch_size: int = 16
    clip_range: float = 0.2
    clip_range_vf: Optional[float] = None
    target_kl: float = 0.01
    
    # Value function settings
    vf_coef: float = 0.1
    use_score_scaling: bool = True
    use_score_norm: bool = True
    score_clip: Optional[float] = None
    
    # Group relative advantage settings
    advantage_normalization: str = "group"  # "group", "global", "none"
    group_advantage_clip: float = 10.0
    relative_advantage_weight: float = 1.0
    
    # Memory optimization for GRPO
    gradient_accumulation_steps: int = 8  # Higher for memory efficiency
    per_device_train_batch_size: int = 2  # Lower for memory efficiency
    
    # GRPO specific evaluation
    eval_batch_size: int = 4
    eval_accumulation_steps: int = 8
    
    # Reward model settings
    reward_model_path: Optional[str] = None
    reward_model_device: str = "auto"
    
    def __post_init__(self):
        super().__post_init__()
        if self.clip_range_vf is None:
            self.clip_range_vf = self.clip_range


@dataclass
class DPOConfig(BaseTrainingConfig):
    """Configuration for Direct Preference Optimization (DPO)."""
    
    # DPO specific parameters
    beta: float = 0.1  # Temperature parameter for DPO loss
    label_smoothing: float = 0.0
    loss_type: str = "sigmoid"  # "sigmoid", "hinge", "ipo"
    
    # Reference model settings
    reference_model_path: Optional[str] = None
    reference_free: bool = False  # Whether to use reference-free DPO
    
    # Data processing
    max_length: int = 2048
    max_prompt_length: int = 1024
    max_target_length: int = 1024
    
    # DPO specific training settings
    per_device_train_batch_size: int = 4
    gradient_accumulation_steps: int = 4
    learning_rate: float = 5e-7  # Lower LR for DPO
    
    # Preference data settings
    preference_data_format: str = "standard"  # "standard", "anthropic", "custom"
    truncation_mode: str = "keep_end"  # "keep_end", "keep_start"
    
    # Self-training integration
    enable_self_training: bool = False
    self_training_iterations: int = 3
    self_training_data_ratio: float = 0.5
    
    # Advanced DPO settings
    precompute_ref_log_probs: bool = False
    model_init_kwargs: Dict[str, Any] = field(default_factory=dict)
    ref_model_init_kwargs: Dict[str, Any] = field(default_factory=dict)


@dataclass
class CurriculumConfig(BaseTrainingConfig):
    """Configuration for Curriculum Learning."""
    
    # Curriculum strategy
    curriculum_strategy: str = "easy_to_hard"  # "easy_to_hard", "hard_to_easy", "mixed"
    curriculum_stages: int = 4
    problems_per_stage: int = 1000
    
    # Stage progression criteria
    advancement_threshold: float = 0.85  # Accuracy threshold to advance
    min_problems_per_stage: int = 500
    max_problems_per_stage: int = 2000
    
    # Difficulty assessment
    difficulty_metric: str = "composite"  # "composite", "constraint_count", "reasoning_depth"
    difficulty_bins: int = 10
    
    # Stage-specific training
    stage_epochs: List[int] = field(default_factory=lambda: [2, 3, 4, 5])
    stage_learning_rates: List[float] = field(default_factory=lambda: [1e-5, 8e-6, 5e-6, 3e-6])
    stage_batch_sizes: List[int] = field(default_factory=lambda: [8, 6, 4, 4])
    
    # Data mixing
    enable_data_mixing: bool = True
    mixing_ratio: float = 0.2  # Ratio of previous stage data to include
    
    # Evaluation during curriculum
    eval_each_stage: bool = True
    eval_on_all_stages: bool = True
    
    # Adaptive curriculum
    adaptive_progression: bool = True
    performance_window: int = 100  # Number of recent examples to consider
    
    def __post_init__(self):
        super().__post_init__()
        # Ensure lists have correct length
        while len(self.stage_epochs) < self.curriculum_stages:
            self.stage_epochs.append(self.stage_epochs[-1])
        while len(self.stage_learning_rates) < self.curriculum_stages:
            self.stage_learning_rates.append(self.stage_learning_rates[-1])
        while len(self.stage_batch_sizes) < self.curriculum_stages:
            self.stage_batch_sizes.append(self.stage_batch_sizes[-1])


@dataclass
class SelfTrainingConfig(BaseTrainingConfig):
    """Configuration for Self-Training with iterative improvement."""
    
    # Self-training iterations
    num_iterations: int = 3
    problems_per_iteration: int = 2000
    
    # Data generation for self-training
    generation_batch_size: int = 32
    generation_temperature: float = 0.8
    generation_top_p: float = 0.9
    generation_max_length: int = 2048
    
    # Quality filtering
    quality_threshold: float = 0.8
    confidence_threshold: float = 0.9
    use_ensemble_filtering: bool = True
    ensemble_size: int = 3
    
    # Data augmentation
    enable_augmentation: bool = True
    augmentation_ratio: float = 0.3
    augmentation_methods: List[str] = field(default_factory=lambda: ["paraphrase", "difficulty_adjust"])
    
    # Training on generated data
    synthetic_data_weight: float = 0.5  # Weight for synthetic vs. original data
    curriculum_on_synthetic: bool = True
    
    # Evaluation and selection
    eval_on_holdout: bool = True
    holdout_ratio: float = 0.1
    model_selection_metric: str = "accuracy"
    
    # Advanced self-training
    use_pseudo_labeling: bool = True
    pseudo_label_threshold: float = 0.95
    distillation_temperature: float = 3.0


@dataclass
class TrainingConfig:
    """Main training configuration that combines all methods."""
    
    # Primary training method
    training_method: TrainingMethod = TrainingMethod.GRPO
    
    # Method-specific configs
    grpo_config: Optional[GRPOConfig] = None
    dpo_config: Optional[DPOConfig] = None
    curriculum_config: Optional[CurriculumConfig] = None
    self_training_config: Optional[SelfTrainingConfig] = None
    
    # Multi-stage training
    enable_multi_stage: bool = False
    training_stages: List[TrainingMethod] = field(default_factory=list)
    
    # Hardware and optimization
    device_map: str = "auto"
    low_cpu_mem_usage: bool = True
    use_cache: bool = False  # Disable for training
    
    # Distributed training
    distributed_training: bool = False
    world_size: int = 1
    local_rank: int = -1
    
    # Monitoring and debugging
    enable_wandb: bool = True
    wandb_project: str = "aaipl-enhanced-training"
    wandb_run_name: Optional[str] = None
    
    # Checkpointing
    resume_from_checkpoint: Optional[str] = None
    save_safetensors: bool = True
    
    def __post_init__(self):
        # Initialize method-specific configs if not provided
        if self.training_method == TrainingMethod.GRPO and self.grpo_config is None:
            self.grpo_config = GRPOConfig()
        elif self.training_method == TrainingMethod.DPO and self.dpo_config is None:
            self.dpo_config = DPOConfig()
        elif self.training_method == TrainingMethod.CURRICULUM and self.curriculum_config is None:
            self.curriculum_config = CurriculumConfig()
        elif self.training_method == TrainingMethod.SELF_TRAINING and self.self_training_config is None:
            self.self_training_config = SelfTrainingConfig()
    
    def get_active_config(self) -> BaseTrainingConfig:
        """Get the configuration for the active training method."""
        if self.training_method == TrainingMethod.GRPO:
            return self.grpo_config
        elif self.training_method == TrainingMethod.DPO:
            return self.dpo_config
        elif self.training_method == TrainingMethod.CURRICULUM:
            return self.curriculum_config
        elif self.training_method == TrainingMethod.SELF_TRAINING:
            return self.self_training_config
        else:
            raise ValueError(f"Unknown training method: {self.training_method}")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary."""
        result = {}
        
        # Add main config fields
        for key, value in self.__dict__.items():
            if not key.endswith('_config'):
                if isinstance(value, Enum):
                    result[key] = value.value
                else:
                    result[key] = value
        
        # Add method-specific configs
        if self.grpo_config:
            result['grpo_config'] = {k: v.value if isinstance(v, Enum) else v 
                                   for k, v in self.grpo_config.__dict__.items()}
        if self.dpo_config:
            result['dpo_config'] = {k: v.value if isinstance(v, Enum) else v 
                                  for k, v in self.dpo_config.__dict__.items()}
        if self.curriculum_config:
            result['curriculum_config'] = {k: v.value if isinstance(v, Enum) else v 
                                         for k, v in self.curriculum_config.__dict__.items()}
        if self.self_training_config:
            result['self_training_config'] = {k: v.value if isinstance(v, Enum) else v 
                                            for k, v in self.self_training_config.__dict__.items()}
        
        return result
    
    @classmethod
    def from_dict(cls, config_dict: Dict[str, Any]) -> 'TrainingConfig':
        """Create configuration from dictionary."""
        # Extract method-specific configs
        grpo_config = None
        if 'grpo_config' in config_dict:
            grpo_config = GRPOConfig(**config_dict.pop('grpo_config'))
        
        dpo_config = None
        if 'dpo_config' in config_dict:
            dpo_config = DPOConfig(**config_dict.pop('dpo_config'))
        
        curriculum_config = None
        if 'curriculum_config' in config_dict:
            curriculum_config = CurriculumConfig(**config_dict.pop('curriculum_config'))
        
        self_training_config = None
        if 'self_training_config' in config_dict:
            self_training_config = SelfTrainingConfig(**config_dict.pop('self_training_config'))
        
        # Convert enum strings back to enums
        if 'training_method' in config_dict:
            config_dict['training_method'] = TrainingMethod(config_dict['training_method'])
        if 'training_stages' in config_dict:
            config_dict['training_stages'] = [TrainingMethod(stage) for stage in config_dict['training_stages']]
        
        return cls(
            grpo_config=grpo_config,
            dpo_config=dpo_config,
            curriculum_config=curriculum_config,
            self_training_config=self_training_config,
            **config_dict
        )


def create_competition_config() -> TrainingConfig:
    """Create optimized configuration for competition training."""
    grpo_config = GRPOConfig(
        learning_rate=3e-6,
        num_train_epochs=4,
        per_device_train_batch_size=2,
        gradient_accumulation_steps=16,
        group_size=128,  # Larger groups for better relative advantages
        beta=0.05,  # Lower KL penalty for more exploration
        max_length=2048,
        eval_steps=250,
        save_steps=250,
        warmup_ratio=0.05,
        use_rocm_optimizations=True
    )
    
    curriculum_config = CurriculumConfig(
        curriculum_stages=4,
        problems_per_stage=1500,
        advancement_threshold=0.88,
        stage_learning_rates=[5e-6, 3e-6, 2e-6, 1e-6],
        adaptive_progression=True
    )
    
    return TrainingConfig(
        training_method=TrainingMethod.GRPO,
        grpo_config=grpo_config,
        curriculum_config=curriculum_config,
        enable_multi_stage=True,
        training_stages=[TrainingMethod.CURRICULUM, TrainingMethod.GRPO],
        enable_wandb=True,
        wandb_project="aaipl-competition-training"
    )


def create_research_config() -> TrainingConfig:
    """Create configuration optimized for research and experimentation."""
    dpo_config = DPOConfig(
        learning_rate=1e-6,
        num_train_epochs=3,
        beta=0.1,
        enable_self_training=True,
        self_training_iterations=2,
        max_length=1536
    )
    
    self_training_config = SelfTrainingConfig(
        num_iterations=3,
        quality_threshold=0.85,
        use_ensemble_filtering=True,
        enable_augmentation=True
    )
    
    return TrainingConfig(
        training_method=TrainingMethod.DPO,
        dpo_config=dpo_config,
        self_training_config=self_training_config,
        enable_multi_stage=True,
        training_stages=[TrainingMethod.DPO, TrainingMethod.SELF_TRAINING],
        enable_wandb=True,
        wandb_project="aaipl-research-training"
    )

