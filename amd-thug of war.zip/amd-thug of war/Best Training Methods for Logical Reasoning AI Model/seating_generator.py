"""
Seating Arrangement Problem Generator

This module generates sophisticated seating arrangement problems for both linear
and circular configurations. The generator uses constraint satisfaction techniques
to create logically consistent problems with varying complexity levels.
"""

import random
import itertools
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass
from enum import Enum
import logging

from .base_generator import BaseGenerator, GeneratedProblem, DifficultyLevel, GenerationConfig

logger = logging.getLogger(__name__)


class SeatingType(Enum):
    """Types of seating arrangements."""
    LINEAR = "linear"
    CIRCULAR = "circular"


class ConstraintType(Enum):
    """Types of seating constraints."""
    ADJACENT = "adjacent"          # A sits next to B
    NOT_ADJACENT = "not_adjacent"  # A does not sit next to B
    BETWEEN = "between"            # A sits between B and C
    NOT_BETWEEN = "not_between"    # A does not sit between B and C
    POSITION = "position"          # A sits at position X
    NOT_POSITION = "not_position"  # A does not sit at position X
    RELATIVE = "relative"          # A sits to the left/right of B
    DISTANCE = "distance"          # A sits exactly N seats from B


@dataclass
class Person:
    """Represents a person in the seating arrangement."""
    name: str
    gender: Optional[str] = None
    profession: Optional[str] = None
    age_group: Optional[str] = None
    attributes: Dict[str, Any] = None

    def __post_init__(self):
        if self.attributes is None:
            self.attributes = {}


@dataclass
class SeatingConstraint:
    """Represents a constraint in the seating arrangement."""
    constraint_type: ConstraintType
    people: List[str]
    parameters: Dict[str, Any] = None
    description: str = ""

    def __post_init__(self):
        if self.parameters is None:
            self.parameters = {}


class SeatingGenerator(BaseGenerator):
    """
    Generator for Seating Arrangement problems with systematic difficulty progression.
    
    Difficulty Levels:
    - BEGINNER: 4-5 people, linear arrangement, simple constraints
    - INTERMEDIATE: 5-6 people, mix of linear/circular, moderate constraints
    - ADVANCED: 6-8 people, complex constraints, multiple constraint types
    - EXPERT: 8+ people, intricate logical relationships, challenging constraints
    """

    def __init__(self, config: Optional[GenerationConfig] = None):
        super().__init__("Seating Arrangements", config)
        
        # Person names with variety
        self.male_names = [
            'Alex', 'Ben', 'Chris', 'David', 'Eric', 'Frank', 'George', 'Henry',
            'Ian', 'Jack', 'Kevin', 'Liam', 'Mike', 'Nathan', 'Oscar', 'Paul',
            'Quinn', 'Ryan', 'Steve', 'Tom', 'Victor', 'Will', 'Xavier', 'Zack'
        ]
        
        self.female_names = [
            'Anna', 'Beth', 'Claire', 'Diana', 'Emma', 'Fiona', 'Grace', 'Helen',
            'Iris', 'Jane', 'Kate', 'Lisa', 'Mary', 'Nina', 'Olivia', 'Penny',
            'Rachel', 'Sarah', 'Tina', 'Uma', 'Vera', 'Wendy', 'Yvonne', 'Zoe'
        ]
        
        self.professions = [
            'doctor', 'teacher', 'engineer', 'lawyer', 'artist', 'chef',
            'pilot', 'nurse', 'architect', 'scientist', 'writer', 'musician'
        ]
        
        self.age_groups = ['young', 'middle-aged', 'elderly']
        
        # Constraint templates
        self.constraint_templates = {
            ConstraintType.ADJACENT: [
                "{person1} sits next to {person2}",
                "{person1} and {person2} are seated adjacent to each other",
                "{person1} is seated immediately beside {person2}"
            ],
            ConstraintType.NOT_ADJACENT: [
                "{person1} does not sit next to {person2}",
                "{person1} and {person2} are not seated adjacent to each other",
                "{person1} is not seated immediately beside {person2}"
            ],
            ConstraintType.BETWEEN: [
                "{person1} sits between {person2} and {person3}",
                "{person1} is seated between {person2} and {person3}",
                "{person2} and {person3} have {person1} sitting between them"
            ],
            ConstraintType.POSITION: [
                "{person1} sits at position {position}",
                "{person1} is seated at the {position} position",
                "The {position} seat is occupied by {person1}"
            ],
            ConstraintType.RELATIVE: [
                "{person1} sits to the {direction} of {person2}",
                "{person1} is seated {direction} of {person2}",
                "{person2} has {person1} sitting to their {direction}"
            ]
        }

    def generate_problem_core(self, difficulty: DifficultyLevel) -> GeneratedProblem:
        """Generate a seating arrangement problem of specified difficulty."""
        
        # Determine problem parameters
        num_people, seating_type, num_constraints = self._get_difficulty_parameters(difficulty)
        
        # Generate people
        people = self._generate_people(num_people)
        
        # Generate valid seating arrangement
        arrangement = self._generate_valid_arrangement(people, seating_type)
        
        # Generate constraints based on the arrangement
        constraints = self._generate_constraints(people, arrangement, seating_type, num_constraints)
        
        # Create the problem question
        question = self._create_question(people, constraints, seating_type)
        
        # Generate answer choices
        choices, correct_answer = self._generate_choices(people, arrangement, seating_type)
        
        # Create explanation
        explanation = self._create_explanation(people, arrangement, constraints, seating_type)
        
        # Extract reasoning steps
        reasoning_steps = self._extract_reasoning_steps(constraints, seating_type)
        constraint_descriptions = [c.description for c in constraints]
        
        return GeneratedProblem(
            topic=self.topic,
            question=question,
            choices=choices,
            answer=correct_answer,
            explanation=explanation,
            difficulty=difficulty,
            quality_score=0.0,
            constraints=constraint_descriptions,
            reasoning_steps=reasoning_steps,
            metadata={
                'num_people': num_people,
                'seating_type': seating_type.value,
                'num_constraints': num_constraints,
                'people_names': [p.name for p in people],
                'arrangement': arrangement
            },
            generation_timestamp="",
            problem_id=""
        )

    def _get_difficulty_parameters(self, difficulty: DifficultyLevel) -> Tuple[int, SeatingType, int]:
        """Get problem parameters based on difficulty level."""
        if difficulty == DifficultyLevel.BEGINNER:
            num_people = random.choice([4, 5])
            seating_type = SeatingType.LINEAR
            num_constraints = random.choice([2, 3])
        elif difficulty == DifficultyLevel.INTERMEDIATE:
            num_people = random.choice([5, 6])
            seating_type = random.choice([SeatingType.LINEAR, SeatingType.CIRCULAR])
            num_constraints = random.choice([3, 4])
        elif difficulty == DifficultyLevel.ADVANCED:
            num_people = random.choice([6, 7, 8])
            seating_type = random.choice([SeatingType.LINEAR, SeatingType.CIRCULAR])
            num_constraints = random.choice([4, 5, 6])
        else:  # EXPERT
            num_people = random.choice([7, 8, 9])
            seating_type = random.choice([SeatingType.LINEAR, SeatingType.CIRCULAR])
            num_constraints = random.choice([5, 6, 7])
        
        return num_people, seating_type, num_constraints

    def _generate_people(self, num_people: int) -> List[Person]:
        """Generate people with diverse attributes."""
        people = []
        used_names = set()
        
        # Ensure gender balance
        num_males = num_people // 2
        num_females = num_people - num_males
        
        # Generate males
        male_names = random.sample(self.male_names, num_males)
        for name in male_names:
            person = Person(
                name=name,
                gender='male',
                profession=random.choice(self.professions),
                age_group=random.choice(self.age_groups)
            )
            people.append(person)
            used_names.add(name)
        
        # Generate females
        female_names = random.sample(self.female_names, num_females)
        for name in female_names:
            person = Person(
                name=name,
                gender='female',
                profession=random.choice(self.professions),
                age_group=random.choice(self.age_groups)
            )
            people.append(person)
            used_names.add(name)
        
        # Shuffle to randomize order
        random.shuffle(people)
        return people

    def _generate_valid_arrangement(self, people: List[Person], seating_type: SeatingType) -> List[str]:
        """Generate a valid seating arrangement."""
        names = [p.name for p in people]
        arrangement = names.copy()
        random.shuffle(arrangement)
        return arrangement

    def _generate_constraints(self, people: List[Person], arrangement: List[str], 
                            seating_type: SeatingType, num_constraints: int) -> List[SeatingConstraint]:
        """Generate constraints based on the valid arrangement."""
        constraints = []
        names = [p.name for p in people]
        
        # Ensure we have enough possible constraints
        max_attempts = 50
        attempts = 0
        
        while len(constraints) < num_constraints and attempts < max_attempts:
            attempts += 1
            
            # Choose constraint type based on difficulty and seating type
            possible_types = [ConstraintType.ADJACENT, ConstraintType.NOT_ADJACENT]
            
            if len(arrangement) >= 3:
                possible_types.extend([ConstraintType.BETWEEN, ConstraintType.NOT_BETWEEN])
            
            if seating_type == SeatingType.LINEAR:
                possible_types.extend([ConstraintType.POSITION, ConstraintType.RELATIVE])
            
            constraint_type = random.choice(possible_types)
            
            # Generate constraint based on type
            constraint = self._generate_single_constraint(
                constraint_type, people, arrangement, seating_type
            )
            
            if constraint and self._is_constraint_valid(constraint, arrangement, seating_type):
                constraints.append(constraint)
        
        return constraints

    def _generate_single_constraint(self, constraint_type: ConstraintType, people: List[Person],
                                  arrangement: List[str], seating_type: SeatingType) -> Optional[SeatingConstraint]:
        """Generate a single constraint of the specified type."""
        names = [p.name for p in people]
        
        if constraint_type == ConstraintType.ADJACENT:
            # Find two people who are actually adjacent
            for i in range(len(arrangement)):
                next_i = (i + 1) % len(arrangement) if seating_type == SeatingType.CIRCULAR else i + 1
                if next_i < len(arrangement):
                    person1, person2 = arrangement[i], arrangement[next_i]
                    template = random.choice(self.constraint_templates[constraint_type])
                    description = template.format(person1=person1, person2=person2)
                    return SeatingConstraint(
                        constraint_type=constraint_type,
                        people=[person1, person2],
                        description=description
                    )
        
        elif constraint_type == ConstraintType.NOT_ADJACENT:
            # Find two people who are not adjacent
            for person1 in names:
                for person2 in names:
                    if person1 != person2 and not self._are_adjacent(person1, person2, arrangement, seating_type):
                        template = random.choice(self.constraint_templates[constraint_type])
                        description = template.format(person1=person1, person2=person2)
                        return SeatingConstraint(
                            constraint_type=constraint_type,
                            people=[person1, person2],
                            description=description
                        )
        
        elif constraint_type == ConstraintType.BETWEEN:
            # Find someone who is between two others
            for i in range(len(arrangement)):
                if seating_type == SeatingType.LINEAR and (i == 0 or i == len(arrangement) - 1):
                    continue  # Can't be between in linear arrangement at ends
                
                person1 = arrangement[i]
                if seating_type == SeatingType.CIRCULAR:
                    person2 = arrangement[(i - 1) % len(arrangement)]
                    person3 = arrangement[(i + 1) % len(arrangement)]
                else:
                    if i > 0 and i < len(arrangement) - 1:
                        person2 = arrangement[i - 1]
                        person3 = arrangement[i + 1]
                    else:
                        continue
                
                template = random.choice(self.constraint_templates[constraint_type])
                description = template.format(person1=person1, person2=person2, person3=person3)
                return SeatingConstraint(
                    constraint_type=constraint_type,
                    people=[person1, person2, person3],
                    description=description
                )
        
        elif constraint_type == ConstraintType.POSITION and seating_type == SeatingType.LINEAR:
            # Choose a person and their actual position
            person = random.choice(names)
            position = arrangement.index(person) + 1
            position_names = {1: "first", 2: "second", 3: "third", 4: "fourth", 5: "fifth"}
            position_name = position_names.get(position, f"{position}th")
            
            template = random.choice(self.constraint_templates[constraint_type])
            description = template.format(person1=person, position=position_name)
            return SeatingConstraint(
                constraint_type=constraint_type,
                people=[person],
                parameters={'position': position},
                description=description
            )
        
        elif constraint_type == ConstraintType.RELATIVE and seating_type == SeatingType.LINEAR:
            # Find two people with a clear left/right relationship
            for i in range(len(arrangement) - 1):
                person1 = arrangement[i]
                person2 = arrangement[i + 1]
                direction = "left"  # person1 is to the left of person2
                
                template = random.choice(self.constraint_templates[constraint_type])
                description = template.format(person1=person1, person2=person2, direction=direction)
                return SeatingConstraint(
                    constraint_type=constraint_type,
                    people=[person1, person2],
                    parameters={'direction': direction},
                    description=description
                )
        
        return None

    def _are_adjacent(self, person1: str, person2: str, arrangement: List[str], seating_type: SeatingType) -> bool:
        """Check if two people are adjacent in the arrangement."""
        try:
            idx1 = arrangement.index(person1)
            idx2 = arrangement.index(person2)
        except ValueError:
            return False
        
        if seating_type == SeatingType.CIRCULAR:
            # In circular arrangement, also check wrap-around
            return abs(idx1 - idx2) == 1 or abs(idx1 - idx2) == len(arrangement) - 1
        else:
            # In linear arrangement
            return abs(idx1 - idx2) == 1

    def _is_constraint_valid(self, constraint: SeatingConstraint, arrangement: List[str], 
                           seating_type: SeatingType) -> bool:
        """Check if a constraint is satisfied by the arrangement."""
        if constraint.constraint_type == ConstraintType.ADJACENT:
            return self._are_adjacent(constraint.people[0], constraint.people[1], arrangement, seating_type)
        
        elif constraint.constraint_type == ConstraintType.NOT_ADJACENT:
            return not self._are_adjacent(constraint.people[0], constraint.people[1], arrangement, seating_type)
        
        elif constraint.constraint_type == ConstraintType.BETWEEN:
            person1, person2, person3 = constraint.people
            try:
                idx1 = arrangement.index(person1)
                idx2 = arrangement.index(person2)
                idx3 = arrangement.index(person3)
                
                if seating_type == SeatingType.CIRCULAR:
                    # Check if person1 is between person2 and person3 in circular arrangement
                    return ((idx2 < idx1 < idx3) or (idx3 < idx1 < idx2) or 
                           (idx1 < idx2 and idx3 < idx1) or (idx1 < idx3 and idx2 < idx1))
                else:
                    # Linear arrangement
                    return (idx2 < idx1 < idx3) or (idx3 < idx1 < idx2)
            except ValueError:
                return False
        
        elif constraint.constraint_type == ConstraintType.POSITION:
            person = constraint.people[0]
            position = constraint.parameters.get('position', 1)
            try:
                actual_position = arrangement.index(person) + 1
                return actual_position == position
            except ValueError:
                return False
        
        elif constraint.constraint_type == ConstraintType.RELATIVE:
            person1, person2 = constraint.people
            direction = constraint.parameters.get('direction', 'left')
            try:
                idx1 = arrangement.index(person1)
                idx2 = arrangement.index(person2)
                
                if direction == 'left':
                    return idx1 < idx2
                else:  # right
                    return idx1 > idx2
            except ValueError:
                return False
        
        return True

    def _create_question(self, people: List[Person], constraints: List[SeatingConstraint], 
                        seating_type: SeatingType) -> str:
        """Create the problem question text."""
        people_names = [p.name for p in people]
        
        # Build the scenario description
        if len(people_names) <= 3:
            name_list = " and ".join(people_names)
        else:
            name_list = ", ".join(people_names[:-1]) + f", and {people_names[-1]}"
        
        arrangement_type = "in a row" if seating_type == SeatingType.LINEAR else "around a circular table"
        
        question_parts = [
            f"{len(people)} people - {name_list} - are seated {arrangement_type}."
        ]
        
        # Add constraints
        if constraints:
            question_parts.append("The following conditions must be satisfied:")
            for i, constraint in enumerate(constraints, 1):
                question_parts.append(f"{i}. {constraint.description}.")
        
        # Add the question
        question_parts.append("What is the correct seating arrangement?")
        
        return " ".join(question_parts)

    def _generate_choices(self, people: List[Person], arrangement: List[str], 
                         seating_type: SeatingType) -> Tuple[List[str], str]:
        """Generate multiple choice options."""
        # Correct arrangement
        if seating_type == SeatingType.LINEAR:
            correct_answer = " - ".join(arrangement)
        else:
            # For circular, we can start from any position
            correct_answer = " - ".join(arrangement) + " (circular)"
        
        # Generate distractors by creating invalid arrangements
        distractors = []
        names = [p.name for p in people]
        
        # Create variations by swapping adjacent people
        for _ in range(10):  # Try multiple variations
            distractor = arrangement.copy()
            
            # Swap two random adjacent positions
            if len(distractor) > 1:
                idx = random.randint(0, len(distractor) - 2)
                distractor[idx], distractor[idx + 1] = distractor[idx + 1], distractor[idx]
                
                if seating_type == SeatingType.LINEAR:
                    distractor_str = " - ".join(distractor)
                else:
                    distractor_str = " - ".join(distractor) + " (circular)"
                
                if distractor_str != correct_answer and distractor_str not in distractors:
                    distractors.append(distractor_str)
        
        # Create more variations by random shuffling
        for _ in range(5):
            distractor = names.copy()
            random.shuffle(distractor)
            
            if seating_type == SeatingType.LINEAR:
                distractor_str = " - ".join(distractor)
            else:
                distractor_str = " - ".join(distractor) + " (circular)"
            
            if distractor_str != correct_answer and distractor_str not in distractors:
                distractors.append(distractor_str)
        
        # Select best distractors
        if len(distractors) >= 3:
            selected_distractors = random.sample(distractors, 3)
        else:
            selected_distractors = distractors[:]
            while len(selected_distractors) < 3:
                selected_distractors.append("None of the above arrangements")
        
        # Create choices
        choices, correct_letter = self.generate_choices(correct_answer, selected_distractors)
        
        return choices, correct_letter

    def _create_explanation(self, people: List[Person], arrangement: List[str], 
                          constraints: List[SeatingConstraint], seating_type: SeatingType) -> str:
        """Create a clear explanation of the solution."""
        explanation_parts = []
        
        explanation_parts.append("Let's solve this step by step using the given constraints:")
        
        # Explain how each constraint is satisfied
        for i, constraint in enumerate(constraints, 1):
            explanation_parts.append(f"Constraint {i}: {constraint.description}")
            
            # Verify the constraint
            if self._is_constraint_valid(constraint, arrangement, seating_type):
                explanation_parts.append("✓ This constraint is satisfied in our arrangement.")
            else:
                explanation_parts.append("✗ This constraint is NOT satisfied.")
        
        # Show the final arrangement
        if seating_type == SeatingType.LINEAR:
            arrangement_str = " - ".join(arrangement)
            explanation_parts.append(f"The correct linear arrangement is: {arrangement_str}")
        else:
            arrangement_str = " - ".join(arrangement)
            explanation_parts.append(f"The correct circular arrangement is: {arrangement_str} (circular)")
        
        return " ".join(explanation_parts)

    def _extract_reasoning_steps(self, constraints: List[SeatingConstraint], seating_type: SeatingType) -> List[str]:
        """Extract the logical reasoning steps."""
        steps = []
        
        steps.append(f"Identify the seating type: {'linear' if seating_type == SeatingType.LINEAR else 'circular'}")
        steps.append("List all given constraints")
        steps.append("Use constraint satisfaction to find valid arrangements")
        steps.append("Verify that the solution satisfies all constraints")
        steps.append("Eliminate arrangements that violate any constraint")
        
        return steps

    def validate_problem_logic(self, problem: GeneratedProblem) -> Tuple[bool, List[str]]:
        """Validate the logical consistency of the problem."""
        errors = []
        
        if not problem.question:
            errors.append("Question is empty")
        
        if len(problem.choices) != 4:
            errors.append("Must have exactly 4 choices")
        
        if not problem.answer:
            errors.append("Answer is empty")
        
        if not problem.explanation:
            errors.append("Explanation is empty")
        
        # Check that answer is one of the choices
        answer_found = False
        for choice in problem.choices:
            if problem.answer in choice:
                answer_found = True
                break
        
        if not answer_found:
            errors.append("Answer not found in choices")
        
        # Validate arrangement format
        arrangement = problem.metadata.get('arrangement', [])
        if not arrangement:
            errors.append("No arrangement found in metadata")
        
        return len(errors) == 0, errors

    def calculate_difficulty_score(self, problem: GeneratedProblem) -> float:
        """Calculate the actual difficulty score of the problem."""
        score = 1.0
        
        # Base score from number of people
        num_people = problem.metadata.get('num_people', 4)
        score += (num_people - 4) * 0.3
        
        # Complexity from seating type
        seating_type = problem.metadata.get('seating_type', 'linear')
        if seating_type == 'circular':
            score += 0.5
        
        # Number of constraints
        num_constraints = problem.metadata.get('num_constraints', 2)
        score += num_constraints * 0.2
        
        # Constraint complexity
        if 'between' in str(problem.constraints).lower():
            score += 0.3
        if 'position' in str(problem.constraints).lower():
            score += 0.2
        
        return min(5.0, score)

