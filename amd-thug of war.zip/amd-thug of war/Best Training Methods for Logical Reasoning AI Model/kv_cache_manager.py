"""
KV Cache Manager for Efficient Memory Management

This module implements advanced KV cache management strategies optimized
for AMD MI300x hardware, including hierarchical caching, quantization,
and memory-efficient allocation patterns.
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
from dataclasses import dataclass
import logging
from collections import OrderedDict
import threading
import time

logger = logging.getLogger(__name__)


@dataclass
class CacheConfig:
    """Configuration for KV cache management."""
    
    # Cache implementation
    implementation: str = "flash_attention"  # "flash_attention", "standard", "quantized"
    max_length: int = 4096
    dtype: torch.dtype = torch.bfloat16
    
    # Memory management
    enable_quantization: bool = True
    quantization_bits: int = 8
    block_size: int = 16
    max_memory_usage_gb: float = 32.0
    
    # Hierarchical caching
    enable_hierarchical_cache: bool = True
    l1_cache_size: int = 1024  # Fast cache for recent tokens
    l2_cache_size: int = 8192  # Slower cache for older tokens
    
    # Eviction policy
    eviction_policy: str = "lru"  # "lru", "lfu", "adaptive"
    cache_warmup: bool = True
    prefetch_enabled: bool = True
    
    # Performance optimization
    async_operations: bool = True
    compression_enabled: bool = True
    compression_ratio: float = 0.5


@dataclass
class CacheBlock:
    """Represents a cache block."""
    
    key_cache: torch.Tensor
    value_cache: torch.Tensor
    sequence_id: int
    position_start: int
    position_end: int
    last_access_time: float
    access_count: int
    is_compressed: bool = False
    compression_metadata: Optional[Dict[str, Any]] = None


class QuantizedCache:
    """Quantized cache implementation for memory efficiency."""
    
    def __init__(self, config: CacheConfig):
        self.config = config
        self.quantization_bits = config.quantization_bits
        
        # Quantization parameters
        self.scale_factor = 2 ** (self.quantization_bits - 1) - 1
        self.zero_point = 0
        
    def quantize_tensor(self, tensor: torch.Tensor) -> Tuple[torch.Tensor, Dict[str, Any]]:
        """Quantize tensor to reduce memory usage."""
        # Compute quantization parameters
        tensor_min = tensor.min()
        tensor_max = tensor.max()
        
        scale = (tensor_max - tensor_min) / (2 ** self.quantization_bits - 1)
        zero_point = tensor_min
        
        # Quantize
        quantized = ((tensor - zero_point) / scale).round().clamp(0, 2 ** self.quantization_bits - 1)
        quantized = quantized.to(torch.uint8)
        
        metadata = {
            'scale': scale.item(),
            'zero_point': zero_point.item(),
            'original_shape': tensor.shape,
            'original_dtype': tensor.dtype
        }
        
        return quantized, metadata
    
    def dequantize_tensor(self, quantized: torch.Tensor, metadata: Dict[str, Any]) -> torch.Tensor:
        """Dequantize tensor back to original precision."""
        scale = metadata['scale']
        zero_point = metadata['zero_point']
        original_dtype = metadata['original_dtype']
        
        # Dequantize
        dequantized = quantized.to(torch.float32) * scale + zero_point
        dequantized = dequantized.to(original_dtype)
        
        return dequantized


class HierarchicalCache:
    """Hierarchical cache with L1 and L2 levels."""
    
    def __init__(self, config: CacheConfig):
        self.config = config
        
        # L1 cache (fast, small)
        self.l1_cache = OrderedDict()
        self.l1_max_size = config.l1_cache_size
        
        # L2 cache (slower, larger)
        self.l2_cache = OrderedDict()
        self.l2_max_size = config.l2_cache_size
        
        # Statistics
        self.l1_hits = 0
        self.l2_hits = 0
        self.cache_misses = 0
        
        # Quantized cache for L2
        if config.enable_quantization:
            self.quantized_cache = QuantizedCache(config)
        else:
            self.quantized_cache = None
    
    def get(self, key: str) -> Optional[CacheBlock]:
        """Get cache block with hierarchical lookup."""
        # Check L1 cache first
        if key in self.l1_cache:
            block = self.l1_cache[key]
            # Move to end (most recently used)
            self.l1_cache.move_to_end(key)
            block.last_access_time = time.time()
            block.access_count += 1
            self.l1_hits += 1
            return block
        
        # Check L2 cache
        if key in self.l2_cache:
            block = self.l2_cache[key]
            
            # Dequantize if needed
            if block.is_compressed and self.quantized_cache:
                block = self._decompress_block(block)
            
            # Promote to L1 cache
            self._promote_to_l1(key, block)
            
            block.last_access_time = time.time()
            block.access_count += 1
            self.l2_hits += 1
            return block
        
        # Cache miss
        self.cache_misses += 1
        return None
    
    def put(self, key: str, block: CacheBlock):
        """Put cache block into hierarchical cache."""
        # Always put in L1 first
        self.l1_cache[key] = block
        
        # Evict from L1 if necessary
        if len(self.l1_cache) > self.l1_max_size:
            self._evict_from_l1()
    
    def _promote_to_l1(self, key: str, block: CacheBlock):
        """Promote block from L2 to L1."""
        # Remove from L2
        if key in self.l2_cache:
            del self.l2_cache[key]
        
        # Add to L1
        self.l1_cache[key] = block
        
        # Evict from L1 if necessary
        if len(self.l1_cache) > self.l1_max_size:
            self._evict_from_l1()
    
    def _evict_from_l1(self):
        """Evict least recently used item from L1 to L2."""
        if not self.l1_cache:
            return
        
        # Get LRU item
        lru_key, lru_block = self.l1_cache.popitem(last=False)
        
        # Compress if moving to L2 and quantization is enabled
        if self.quantized_cache:
            lru_block = self._compress_block(lru_block)
        
        # Move to L2
        self.l2_cache[lru_key] = lru_block
        
        # Evict from L2 if necessary
        if len(self.l2_cache) > self.l2_max_size:
            self._evict_from_l2()
    
    def _evict_from_l2(self):
        """Evict least recently used item from L2."""
        if self.l2_cache:
            self.l2_cache.popitem(last=False)
    
    def _compress_block(self, block: CacheBlock) -> CacheBlock:
        """Compress cache block for L2 storage."""
        if not self.quantized_cache or block.is_compressed:
            return block
        
        # Quantize key and value caches
        quantized_key, key_metadata = self.quantized_cache.quantize_tensor(block.key_cache)
        quantized_value, value_metadata = self.quantized_cache.quantize_tensor(block.value_cache)
        
        # Create compressed block
        compressed_block = CacheBlock(
            key_cache=quantized_key,
            value_cache=quantized_value,
            sequence_id=block.sequence_id,
            position_start=block.position_start,
            position_end=block.position_end,
            last_access_time=block.last_access_time,
            access_count=block.access_count,
            is_compressed=True,
            compression_metadata={
                'key_metadata': key_metadata,
                'value_metadata': value_metadata
            }
        )
        
        return compressed_block
    
    def _decompress_block(self, block: CacheBlock) -> CacheBlock:
        """Decompress cache block from L2 storage."""
        if not block.is_compressed or not self.quantized_cache:
            return block
        
        # Dequantize key and value caches
        key_cache = self.quantized_cache.dequantize_tensor(
            block.key_cache, 
            block.compression_metadata['key_metadata']
        )
        value_cache = self.quantized_cache.dequantize_tensor(
            block.value_cache,
            block.compression_metadata['value_metadata']
        )
        
        # Create decompressed block
        decompressed_block = CacheBlock(
            key_cache=key_cache,
            value_cache=value_cache,
            sequence_id=block.sequence_id,
            position_start=block.position_start,
            position_end=block.position_end,
            last_access_time=block.last_access_time,
            access_count=block.access_count,
            is_compressed=False
        )
        
        return decompressed_block
    
    def get_cache_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        total_accesses = self.l1_hits + self.l2_hits + self.cache_misses
        
        return {
            'l1_size': len(self.l1_cache),
            'l2_size': len(self.l2_cache),
            'l1_hits': self.l1_hits,
            'l2_hits': self.l2_hits,
            'cache_misses': self.cache_misses,
            'l1_hit_rate': self.l1_hits / total_accesses if total_accesses > 0 else 0.0,
            'l2_hit_rate': self.l2_hits / total_accesses if total_accesses > 0 else 0.0,
            'overall_hit_rate': (self.l1_hits + self.l2_hits) / total_accesses if total_accesses > 0 else 0.0
        }


class KVCacheManager:
    """
    Advanced KV Cache Manager for efficient memory management.
    
    Implements hierarchical caching, quantization, and memory optimization
    strategies specifically designed for AMD MI300x hardware.
    """
    
    def __init__(self, config: CacheConfig):
        """
        Initialize KV cache manager.
        
        Args:
            config: Cache configuration
        """
        self.config = config
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # Initialize hierarchical cache
        if config.enable_hierarchical_cache:
            self.cache = HierarchicalCache(config)
        else:
            self.cache = OrderedDict()
        
        # Memory tracking
        self.current_memory_usage = 0.0
        self.peak_memory_usage = 0.0
        self.memory_limit = config.max_memory_usage_gb * 1024**3  # Convert to bytes
        
        # Performance tracking
        self.cache_operations = 0
        self.memory_allocations = 0
        self.compression_operations = 0
        
        # Thread safety
        self.lock = threading.RLock()
        
        logger.info("KV Cache Manager initialized")
        logger.info(f"  Implementation: {config.implementation}")
        logger.info(f"  Max length: {config.max_length}")
        logger.info(f"  Quantization: {config.enable_quantization}")
        logger.info(f"  Hierarchical: {config.enable_hierarchical_cache}")
    
    def allocate_cache(self, 
                      sequence_id: int,
                      batch_size: int,
                      num_heads: int,
                      head_dim: int,
                      sequence_length: int) -> str:
        """
        Allocate cache for a sequence.
        
        Args:
            sequence_id: Unique sequence identifier
            batch_size: Batch size
            num_heads: Number of attention heads
            head_dim: Head dimension
            sequence_length: Sequence length
            
        Returns:
            Cache key for the allocated cache
        """
        with self.lock:
            cache_key = f"seq_{sequence_id}_{batch_size}_{num_heads}_{head_dim}_{sequence_length}"
            
            # Check if cache already exists
            if isinstance(self.cache, HierarchicalCache):
                existing_block = self.cache.get(cache_key)
                if existing_block:
                    return cache_key
            elif cache_key in self.cache:
                return cache_key
            
            # Allocate new cache block
            cache_shape = (batch_size, num_heads, sequence_length, head_dim)
            
            key_cache = torch.zeros(cache_shape, dtype=self.config.dtype, device=self.device)
            value_cache = torch.zeros(cache_shape, dtype=self.config.dtype, device=self.device)
            
            # Create cache block
            cache_block = CacheBlock(
                key_cache=key_cache,
                value_cache=value_cache,
                sequence_id=sequence_id,
                position_start=0,
                position_end=sequence_length,
                last_access_time=time.time(),
                access_count=1
            )
            
            # Store in cache
            if isinstance(self.cache, HierarchicalCache):
                self.cache.put(cache_key, cache_block)
            else:
                self.cache[cache_key] = cache_block
            
            # Update memory tracking
            cache_size = key_cache.numel() * key_cache.element_size() * 2  # key + value
            self.current_memory_usage += cache_size
            self.peak_memory_usage = max(self.peak_memory_usage, self.current_memory_usage)
            self.memory_allocations += 1
            
            logger.debug(f"Allocated cache: {cache_key}, size: {cache_size / 1024**2:.2f} MB")
            
            return cache_key
    
    def get_cache(self, cache_key: str) -> Optional[Tuple[torch.Tensor, torch.Tensor]]:
        """
        Get cache tensors for a given key.
        
        Args:
            cache_key: Cache key
            
        Returns:
            Tuple of (key_cache, value_cache) or None if not found
        """
        with self.lock:
            self.cache_operations += 1
            
            if isinstance(self.cache, HierarchicalCache):
                cache_block = self.cache.get(cache_key)
                if cache_block:
                    return cache_block.key_cache, cache_block.value_cache
            else:
                if cache_key in self.cache:
                    cache_block = self.cache[cache_key]
                    cache_block.last_access_time = time.time()
                    cache_block.access_count += 1
                    return cache_block.key_cache, cache_block.value_cache
            
            return None
    
    def update_cache(self, 
                    cache_key: str,
                    key_states: torch.Tensor,
                    value_states: torch.Tensor,
                    position: int):
        """
        Update cache with new key-value states.
        
        Args:
            cache_key: Cache key
            key_states: New key states
            value_states: New value states
            position: Position to update
        """
        with self.lock:
            cache_result = self.get_cache(cache_key)
            if cache_result is None:
                logger.warning(f"Cache key not found: {cache_key}")
                return
            
            key_cache, value_cache = cache_result
            
            # Update cache at specified position
            if position < key_cache.shape[2]:
                key_cache[:, :, position, :] = key_states
                value_cache[:, :, position, :] = value_states
            else:
                logger.warning(f"Position {position} out of bounds for cache {cache_key}")
    
    def extend_cache(self, 
                    cache_key: str,
                    additional_length: int) -> bool:
        """
        Extend cache to accommodate more tokens.
        
        Args:
            cache_key: Cache key
            additional_length: Additional length needed
            
        Returns:
            True if extension successful, False otherwise
        """
        with self.lock:
            if isinstance(self.cache, HierarchicalCache):
                cache_block = self.cache.get(cache_key)
            else:
                cache_block = self.cache.get(cache_key)
            
            if cache_block is None:
                return False
            
            current_length = cache_block.key_cache.shape[2]
            new_length = current_length + additional_length
            
            # Check if extension exceeds max length
            if new_length > self.config.max_length:
                logger.warning(f"Extension would exceed max length: {new_length} > {self.config.max_length}")
                return False
            
            # Create extended cache
            batch_size, num_heads, _, head_dim = cache_block.key_cache.shape
            
            new_key_cache = torch.zeros(
                (batch_size, num_heads, new_length, head_dim),
                dtype=self.config.dtype,
                device=self.device
            )
            new_value_cache = torch.zeros(
                (batch_size, num_heads, new_length, head_dim),
                dtype=self.config.dtype,
                device=self.device
            )
            
            # Copy existing cache
            new_key_cache[:, :, :current_length, :] = cache_block.key_cache
            new_value_cache[:, :, :current_length, :] = cache_block.value_cache
            
            # Update cache block
            cache_block.key_cache = new_key_cache
            cache_block.value_cache = new_value_cache
            cache_block.position_end = new_length
            
            logger.debug(f"Extended cache {cache_key} from {current_length} to {new_length}")
            
            return True
    
    def evict_cache(self, cache_key: str):
        """
        Evict cache for a given key.
        
        Args:
            cache_key: Cache key to evict
        """
        with self.lock:
            if isinstance(self.cache, HierarchicalCache):
                # Remove from both L1 and L2
                if cache_key in self.cache.l1_cache:
                    cache_block = self.cache.l1_cache.pop(cache_key)
                elif cache_key in self.cache.l2_cache:
                    cache_block = self.cache.l2_cache.pop(cache_key)
                else:
                    return
            else:
                if cache_key not in self.cache:
                    return
                cache_block = self.cache.pop(cache_key)
            
            # Update memory tracking
            cache_size = (cache_block.key_cache.numel() * cache_block.key_cache.element_size() * 2)
            self.current_memory_usage -= cache_size
            
            logger.debug(f"Evicted cache: {cache_key}")
    
    def clear_cache(self):
        """Clear all cache."""
        with self.lock:
            if isinstance(self.cache, HierarchicalCache):
                self.cache.l1_cache.clear()
                self.cache.l2_cache.clear()
            else:
                self.cache.clear()
            
            self.current_memory_usage = 0.0
            
            # Clear CUDA cache
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            
            logger.info("Cache cleared")
    
    def optimize_memory(self):
        """Optimize memory usage by compressing or evicting cache."""
        with self.lock:
            if self.current_memory_usage < self.memory_limit * 0.8:
                return  # Memory usage is acceptable
            
            logger.info("Optimizing cache memory usage")
            
            if isinstance(self.cache, HierarchicalCache):
                # Force compression of L2 cache
                for key, block in list(self.cache.l2_cache.items()):
                    if not block.is_compressed and self.cache.quantized_cache:
                        compressed_block = self.cache._compress_block(block)
                        self.cache.l2_cache[key] = compressed_block
                        self.compression_operations += 1
                
                # Evict least recently used items if still over limit
                while (self.current_memory_usage > self.memory_limit * 0.7 and 
                       (self.cache.l1_cache or self.cache.l2_cache)):
                    if self.cache.l2_cache:
                        self.cache._evict_from_l2()
                    elif self.cache.l1_cache:
                        self.cache._evict_from_l1()
            else:
                # Simple LRU eviction for non-hierarchical cache
                while (self.current_memory_usage > self.memory_limit * 0.7 and 
                       self.cache):
                    # Remove least recently used
                    lru_key = min(self.cache.keys(), 
                                key=lambda k: self.cache[k].last_access_time)
                    self.evict_cache(lru_key)
    
    def get_cache_statistics(self) -> Dict[str, Any]:
        """Get comprehensive cache statistics."""
        with self.lock:
            stats = {
                'current_memory_usage_gb': self.current_memory_usage / 1024**3,
                'peak_memory_usage_gb': self.peak_memory_usage / 1024**3,
                'memory_limit_gb': self.memory_limit / 1024**3,
                'memory_utilization': self.current_memory_usage / self.memory_limit,
                'cache_operations': self.cache_operations,
                'memory_allocations': self.memory_allocations,
                'compression_operations': self.compression_operations
            }
            
            if isinstance(self.cache, HierarchicalCache):
                cache_stats = self.cache.get_cache_stats()
                stats.update(cache_stats)
            else:
                stats['cache_size'] = len(self.cache)
                stats['cache_hit_rate'] = 0.0  # Not tracked for simple cache
            
            return stats
    
    def prefetch_cache(self, sequence_ids: List[int]):
        """
        Prefetch cache for upcoming sequences.
        
        Args:
            sequence_ids: List of sequence IDs to prefetch
        """
        if not self.config.prefetch_enabled:
            return
        
        # This is a placeholder for prefetching logic
        # In practice, would analyze patterns and preload likely-to-be-accessed cache
        logger.debug(f"Prefetching cache for sequences: {sequence_ids}")
    
    def get_memory_pressure(self) -> float:
        """Get current memory pressure (0.0 to 1.0)."""
        return self.current_memory_usage / self.memory_limit
    
    def should_compress(self) -> bool:
        """Determine if compression should be applied."""
        return (self.config.enable_quantization and 
                self.get_memory_pressure() > 0.6)
    
    def get_optimal_block_size(self, sequence_length: int) -> int:
        """Get optimal block size for given sequence length."""
        if sequence_length <= 512:
            return 16
        elif sequence_length <= 2048:
            return 32
        else:
            return 64


def create_kv_cache_manager(config_overrides: Optional[Dict[str, Any]] = None) -> KVCacheManager:
    """
    Create a KV cache manager with optional configuration overrides.
    
    Args:
        config_overrides: Optional configuration overrides
        
    Returns:
        Configured KVCacheManager
    """
    config = CacheConfig()
    
    if config_overrides:
        for key, value in config_overrides.items():
            if hasattr(config, key):
                setattr(config, key, value)
    
    return KVCacheManager(config)

