#!/usr/bin/env python3
"""
Enhanced Dataset Generation Script

This script demonstrates the advanced synthetic data generation system
for logical reasoning problems. It showcases curriculum learning,
quality validation, and multi-topic problem generation.
"""

import argparse
import logging
import json
from pathlib import Path
from datetime import datetime

from data_generation.dataset_builder import DatasetBuilder, DatasetConfig
from data_generation.base_generator import DifficultyLevel

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('dataset_generation.log'),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)


def create_basic_config() -> DatasetConfig:
    """Create a basic dataset configuration."""
    return DatasetConfig(
        total_problems=500,
        topic_distribution={
            'truth_liar': 0.35,
            'seating': 0.35,
            'blood_relations': 0.30
        },
        quality_threshold=3.5,
        validation_enabled=True,
        curriculum_enabled=True,
        problems_per_stage=125,
        batch_size=25,
        random_seed=42
    )


def create_competition_config() -> DatasetConfig:
    """Create configuration optimized for competition training."""
    return DatasetConfig(
        total_problems=2000,
        topic_distribution={
            'truth_liar': 0.40,  # Emphasize logical reasoning
            'seating': 0.35,
            'blood_relations': 0.25
        },
        quality_threshold=4.0,  # Higher quality threshold
        validation_enabled=True,
        curriculum_enabled=True,
        curriculum_type='e2h',
        problems_per_stage=500,
        difficulty_distribution={
            DifficultyLevel.BEGINNER: 0.20,
            DifficultyLevel.INTERMEDIATE: 0.30,
            DifficultyLevel.ADVANCED: 0.35,
            DifficultyLevel.EXPERT: 0.15
        },
        output_format='competition',
        batch_size=50,
        max_generation_attempts=3,
        random_seed=2024
    )


def create_research_config() -> DatasetConfig:
    """Create configuration for research and experimentation."""
    return DatasetConfig(
        total_problems=1000,
        topic_distribution={
            'truth_liar': 0.33,
            'seating': 0.33,
            'blood_relations': 0.34
        },
        quality_threshold=3.0,  # Lower threshold for more variety
        validation_enabled=True,
        curriculum_enabled=True,
        problems_per_stage=250,
        include_metadata=True,
        save_validation_results=True,
        batch_size=20,
        random_seed=None  # Random seed for variety
    )


def generate_basic_dataset(output_dir: str):
    """Generate a basic dataset for testing."""
    logger.info("Generating basic dataset...")
    
    config = create_basic_config()
    builder = DatasetBuilder(config)
    
    output_path = Path(output_dir) / "basic_dataset.json"
    summary = builder.generate_dataset(str(output_path))
    
    # Save summary
    summary_path = Path(output_dir) / "basic_summary.json"
    with open(summary_path, 'w') as f:
        json.dump(summary, f, indent=2)
    
    logger.info(f"Basic dataset generated: {summary['dataset_info']['total_problems']} problems")
    return summary


def generate_competition_dataset(output_dir: str):
    """Generate a competition-ready dataset."""
    logger.info("Generating competition dataset...")
    
    config = create_competition_config()
    builder = DatasetBuilder(config)
    
    output_path = Path(output_dir) / "competition_dataset.json"
    summary = builder.generate_dataset(str(output_path))
    
    # Save summary
    summary_path = Path(output_dir) / "competition_summary.json"
    with open(summary_path, 'w') as f:
        json.dump(summary, f, indent=2)
    
    logger.info(f"Competition dataset generated: {summary['dataset_info']['total_problems']} problems")
    return summary


def generate_curriculum_dataset(output_dir: str):
    """Generate a complete curriculum dataset."""
    logger.info("Generating curriculum dataset...")
    
    config = create_research_config()
    builder = DatasetBuilder(config)
    
    curriculum_dir = Path(output_dir) / "curriculum"
    summary = builder.generate_curriculum_dataset(str(curriculum_dir))
    
    logger.info(f"Curriculum dataset generated: {summary['total_problems']} total problems across {len(summary['stages'])} stages")
    return summary


def demonstrate_quality_validation(output_dir: str):
    """Demonstrate the quality validation system."""
    logger.info("Demonstrating quality validation...")
    
    # Create a small dataset with validation enabled
    config = DatasetConfig(
        total_problems=50,
        quality_threshold=4.0,  # High threshold
        validation_enabled=True,
        save_validation_results=True,
        batch_size=10
    )
    
    builder = DatasetBuilder(config)
    
    output_path = Path(output_dir) / "validated_dataset.json"
    summary = builder.generate_dataset(str(output_path))
    
    # Print validation statistics
    if 'quality_metrics' in summary:
        quality_metrics = summary['quality_metrics']
        logger.info(f"Validation Results:")
        logger.info(f"  - Validation Rate: {quality_metrics.get('validation_rate', 0):.2%}")
        logger.info(f"  - Average Score: {quality_metrics.get('average_score', 0):.2f}")
        logger.info(f"  - Quality Distribution: {quality_metrics.get('quality_distribution', {})}")
    
    return summary


def analyze_generation_performance(summaries: list):
    """Analyze performance across different generation configurations."""
    logger.info("Analyzing generation performance...")
    
    analysis = {
        'configurations': [],
        'performance_comparison': {},
        'recommendations': []
    }
    
    for i, summary in enumerate(summaries):
        config_name = f"config_{i}"
        stats = summary.get('generation_stats', {})
        
        config_analysis = {
            'name': config_name,
            'total_problems': summary['dataset_info']['total_problems'],
            'success_rate': stats.get('success_rate', 0),
            'average_quality': stats.get('average_quality', 0),
            'generation_time': stats.get('generation_time', 0),
            'problems_per_second': summary['dataset_info']['total_problems'] / max(1, stats.get('generation_time', 1))
        }
        
        analysis['configurations'].append(config_analysis)
    
    # Find best performing configuration
    if analysis['configurations']:
        best_config = max(analysis['configurations'], key=lambda x: x['success_rate'] * x['average_quality'])
        analysis['best_configuration'] = best_config['name']
        
        # Generate recommendations
        avg_success_rate = sum(c['success_rate'] for c in analysis['configurations']) / len(analysis['configurations'])
        if avg_success_rate < 0.8:
            analysis['recommendations'].append("Consider adjusting generation parameters to improve success rate")
        
        avg_quality = sum(c['average_quality'] for c in analysis['configurations']) / len(analysis['configurations'])
        if avg_quality < 3.5:
            analysis['recommendations'].append("Review quality validation thresholds")
    
    return analysis


def main():
    """Main function for dataset generation."""
    parser = argparse.ArgumentParser(description="Enhanced Dataset Generation for Logical Reasoning")
    parser.add_argument('--mode', choices=['basic', 'competition', 'curriculum', 'validation', 'all'], 
                       default='basic', help='Generation mode')
    parser.add_argument('--output-dir', default='./generated_datasets', 
                       help='Output directory for generated datasets')
    parser.add_argument('--config-file', help='Path to custom configuration file')
    parser.add_argument('--analyze', action='store_true', 
                       help='Analyze generation performance')
    
    args = parser.parse_args()
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    logger.info(f"Starting dataset generation in mode: {args.mode}")
    logger.info(f"Output directory: {output_dir}")
    
    summaries = []
    
    try:
        if args.config_file:
            # Use custom configuration
            logger.info(f"Using custom configuration: {args.config_file}")
            builder = DatasetBuilder.from_config_file(args.config_file)
            output_path = output_dir / "custom_dataset.json"
            summary = builder.generate_dataset(str(output_path))
            summaries.append(summary)
            
        elif args.mode == 'basic':
            summary = generate_basic_dataset(str(output_dir))
            summaries.append(summary)
            
        elif args.mode == 'competition':
            summary = generate_competition_dataset(str(output_dir))
            summaries.append(summary)
            
        elif args.mode == 'curriculum':
            summary = generate_curriculum_dataset(str(output_dir))
            summaries.append(summary)
            
        elif args.mode == 'validation':
            summary = demonstrate_quality_validation(str(output_dir))
            summaries.append(summary)
            
        elif args.mode == 'all':
            logger.info("Generating all dataset types...")
            summaries.append(generate_basic_dataset(str(output_dir)))
            summaries.append(generate_competition_dataset(str(output_dir)))
            summaries.append(generate_curriculum_dataset(str(output_dir)))
            summaries.append(demonstrate_quality_validation(str(output_dir)))
        
        # Analyze performance if requested
        if args.analyze and summaries:
            analysis = analyze_generation_performance(summaries)
            analysis_path = output_dir / "performance_analysis.json"
            with open(analysis_path, 'w') as f:
                json.dump(analysis, f, indent=2)
            logger.info(f"Performance analysis saved to {analysis_path}")
        
        logger.info("Dataset generation completed successfully!")
        
    except Exception as e:
        logger.error(f"Error during dataset generation: {e}")
        raise


if __name__ == "__main__":
    main()

