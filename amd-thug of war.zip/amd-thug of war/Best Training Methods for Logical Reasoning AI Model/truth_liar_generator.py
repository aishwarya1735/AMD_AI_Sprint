"""
Truth-teller and Liar Problem Generator

This module generates sophisticated logical reasoning problems involving truth-tellers
(who always tell the truth) and liars (who always lie). The generator uses constraint
satisfaction techniques to ensure logical consistency and creates problems with
varying complexity levels.
"""

import random
import itertools
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass
import logging

from .base_generator import BaseGenerator, GeneratedProblem, DifficultyLevel, GenerationConfig

logger = logging.getLogger(__name__)


@dataclass
class Character:
    """Represents a character in a truth-teller/liar problem."""
    name: str
    is_truth_teller: bool
    statements: List[str] = None

    def __post_init__(self):
        if self.statements is None:
            self.statements = []


@dataclass
class Statement:
    """Represents a statement made by a character."""
    speaker: str
    content: str
    about: str  # Who the statement is about
    statement_type: str  # 'truth_claim', 'liar_claim', 'identity_claim', etc.
    is_true: bool  # Whether the statement content is actually true


class TruthLiarGenerator(BaseGenerator):
    """
    Generator for Truth-teller and Liar problems with systematic difficulty progression.
    
    Difficulty Levels:
    - BEGINNER: 2-3 characters, simple direct statements
    - INTERMEDIATE: 3-4 characters, some indirect statements
    - ADVANCED: 4-5 characters, complex logical chains
    - EXPERT: 5+ characters, intricate logical relationships
    """

    def __init__(self, config: Optional[GenerationConfig] = None):
        super().__init__("Truth-teller and Liar Problems", config)
        
        # Character names for variety
        self.character_names = [
            'Alice', 'Bob', 'Charlie', 'Diana', 'Eve', 'Frank', 'Grace', 'Henry',
            'Iris', 'Jack', 'Kate', 'Liam', 'Maya', 'Noah', 'Olivia', 'Paul',
            'Quinn', 'Ruby', 'Sam', 'Tara', 'Uma', 'Victor', 'Wendy', 'Xavier',
            'Yara', 'Zoe'
        ]
        
        # Statement templates for different types
        self.statement_templates = {
            'truth_claim': [
                "{about} is a truth-teller",
                "{about} always tells the truth",
                "{about} is honest",
                "{about} never lies"
            ],
            'liar_claim': [
                "{about} is a liar",
                "{about} always lies", 
                "{about} is dishonest",
                "{about} never tells the truth"
            ],
            'count_claim': [
                "There are exactly {count} truth-tellers among us",
                "Exactly {count} of us are truth-tellers",
                "{count} people here always tell the truth",
                "The number of truth-tellers is {count}"
            ],
            'majority_claim': [
                "Most of us are truth-tellers",
                "Truth-tellers are in the majority",
                "There are more truth-tellers than liars",
                "Liars are outnumbered by truth-tellers"
            ],
            'minority_claim': [
                "Most of us are liars",
                "Liars are in the majority", 
                "There are more liars than truth-tellers",
                "Truth-tellers are outnumbered by liars"
            ],
            'self_reference': [
                "I am a truth-teller",
                "I always tell the truth",
                "I am honest",
                "I never lie"
            ]
        }

    def generate_problem_core(self, difficulty: DifficultyLevel) -> GeneratedProblem:
        """Generate a truth-teller/liar problem of specified difficulty."""
        
        # Determine problem parameters based on difficulty
        num_characters, num_truth_tellers, statement_complexity = self._get_difficulty_parameters(difficulty)
        
        # Generate characters
        characters = self._generate_characters(num_characters, num_truth_tellers)
        
        # Generate statements
        statements = self._generate_statements(characters, statement_complexity)
        
        # Create the problem question
        question = self._create_question(characters, statements)
        
        # Generate answer choices and determine correct answer
        choices, correct_answer = self._generate_choices(characters, num_truth_tellers)
        
        # Create explanation
        explanation = self._create_explanation(characters, statements, correct_answer)
        
        # Extract constraints and reasoning steps
        constraints = self._extract_constraints(statements)
        reasoning_steps = self._extract_reasoning_steps(characters, statements)
        
        return GeneratedProblem(
            topic=self.topic,
            question=question,
            choices=choices,
            answer=correct_answer,
            explanation=explanation,
            difficulty=difficulty,
            quality_score=0.0,  # Will be calculated later
            constraints=constraints,
            reasoning_steps=reasoning_steps,
            metadata={
                'num_characters': num_characters,
                'num_truth_tellers': num_truth_tellers,
                'statement_complexity': statement_complexity,
                'character_names': [c.name for c in characters]
            },
            generation_timestamp="",
            problem_id=""
        )

    def _get_difficulty_parameters(self, difficulty: DifficultyLevel) -> Tuple[int, int, str]:
        """Get problem parameters based on difficulty level."""
        if difficulty == DifficultyLevel.BEGINNER:
            num_characters = random.choice([2, 3])
            num_truth_tellers = random.choice([1, 2])
            complexity = 'simple'
        elif difficulty == DifficultyLevel.INTERMEDIATE:
            num_characters = random.choice([3, 4])
            num_truth_tellers = random.choice([1, 2, 3])
            complexity = 'moderate'
        elif difficulty == DifficultyLevel.ADVANCED:
            num_characters = random.choice([4, 5])
            num_truth_tellers = random.choice([2, 3])
            complexity = 'complex'
        else:  # EXPERT
            num_characters = random.choice([5, 6])
            num_truth_tellers = random.choice([2, 3, 4])
            complexity = 'very_complex'
        
        # Ensure valid configuration
        num_truth_tellers = min(num_truth_tellers, num_characters - 1)
        num_truth_tellers = max(1, num_truth_tellers)
        
        return num_characters, num_truth_tellers, complexity

    def _generate_characters(self, num_characters: int, num_truth_tellers: int) -> List[Character]:
        """Generate characters with assigned truth-teller/liar roles."""
        selected_names = random.sample(self.character_names, num_characters)
        characters = []
        
        # Assign truth-teller roles
        truth_teller_indices = random.sample(range(num_characters), num_truth_tellers)
        
        for i, name in enumerate(selected_names):
            is_truth_teller = i in truth_teller_indices
            characters.append(Character(name=name, is_truth_teller=is_truth_teller))
        
        return characters

    def _generate_statements(self, characters: List[Character], complexity: str) -> List[Statement]:
        """Generate statements based on complexity level."""
        statements = []
        
        if complexity == 'simple':
            statements = self._generate_simple_statements(characters)
        elif complexity == 'moderate':
            statements = self._generate_moderate_statements(characters)
        elif complexity == 'complex':
            statements = self._generate_complex_statements(characters)
        else:  # very_complex
            statements = self._generate_very_complex_statements(characters)
        
        return statements

    def _generate_simple_statements(self, characters: List[Character]) -> List[Statement]:
        """Generate simple direct statements about other characters."""
        statements = []
        
        for speaker in characters:
            # Each character makes one statement about another character
            possible_targets = [c for c in characters if c.name != speaker.name]
            if not possible_targets:
                continue
                
            target = random.choice(possible_targets)
            
            # Choose statement type
            if random.random() < 0.5:
                # Truth claim
                template = random.choice(self.statement_templates['truth_claim'])
                content = template.format(about=target.name)
                is_true = target.is_truth_teller
                statement_type = 'truth_claim'
            else:
                # Liar claim
                template = random.choice(self.statement_templates['liar_claim'])
                content = template.format(about=target.name)
                is_true = not target.is_truth_teller
                statement_type = 'liar_claim'
            
            statement = Statement(
                speaker=speaker.name,
                content=content,
                about=target.name,
                statement_type=statement_type,
                is_true=is_true
            )
            statements.append(statement)
            speaker.statements.append(content)
        
        return statements

    def _generate_moderate_statements(self, characters: List[Character]) -> List[Statement]:
        """Generate moderate complexity statements including some counting."""
        statements = []
        
        # Start with some simple statements
        simple_statements = self._generate_simple_statements(characters[:2])
        statements.extend(simple_statements)
        
        # Add counting statements
        remaining_characters = characters[2:]
        for speaker in remaining_characters:
            if random.random() < 0.7:
                # Count statement
                actual_truth_tellers = sum(1 for c in characters if c.is_truth_teller)
                
                if random.random() < 0.5:
                    # Correct count
                    count = actual_truth_tellers
                else:
                    # Incorrect count
                    possible_counts = [i for i in range(1, len(characters) + 1) if i != actual_truth_tellers]
                    count = random.choice(possible_counts) if possible_counts else actual_truth_tellers
                
                template = random.choice(self.statement_templates['count_claim'])
                content = template.format(count=count)
                is_true = (count == actual_truth_tellers)
                
                statement = Statement(
                    speaker=speaker.name,
                    content=content,
                    about="group",
                    statement_type='count_claim',
                    is_true=is_true
                )
                statements.append(statement)
                speaker.statements.append(content)
        
        return statements

    def _generate_complex_statements(self, characters: List[Character]) -> List[Statement]:
        """Generate complex statements with logical chains."""
        statements = []
        
        # Mix of different statement types
        for i, speaker in enumerate(characters):
            if i < 2:
                # Direct claims about others
                target = random.choice([c for c in characters if c.name != speaker.name])
                if random.random() < 0.5:
                    template = random.choice(self.statement_templates['truth_claim'])
                    content = template.format(about=target.name)
                    is_true = target.is_truth_teller
                    statement_type = 'truth_claim'
                else:
                    template = random.choice(self.statement_templates['liar_claim'])
                    content = template.format(about=target.name)
                    is_true = not target.is_truth_teller
                    statement_type = 'liar_claim'
            elif i < 4:
                # Counting statements
                actual_truth_tellers = sum(1 for c in characters if c.is_truth_teller)
                count = random.choice(range(1, len(characters) + 1))
                template = random.choice(self.statement_templates['count_claim'])
                content = template.format(count=count)
                is_true = (count == actual_truth_tellers)
                statement_type = 'count_claim'
            else:
                # Majority/minority claims
                actual_truth_tellers = sum(1 for c in characters if c.is_truth_teller)
                majority_truth_tellers = actual_truth_tellers > len(characters) / 2
                
                if random.random() < 0.5:
                    template = random.choice(self.statement_templates['majority_claim'])
                    is_true = majority_truth_tellers
                    statement_type = 'majority_claim'
                else:
                    template = random.choice(self.statement_templates['minority_claim'])
                    is_true = not majority_truth_tellers
                    statement_type = 'minority_claim'
                
                content = template
            
            statement = Statement(
                speaker=speaker.name,
                content=content,
                about=target.name if 'target' in locals() else "group",
                statement_type=statement_type,
                is_true=is_true
            )
            statements.append(statement)
            speaker.statements.append(content)
        
        return statements

    def _generate_very_complex_statements(self, characters: List[Character]) -> List[Statement]:
        """Generate very complex statements with intricate logical relationships."""
        statements = []
        
        # Include all types of statements for maximum complexity
        statement_types = ['truth_claim', 'liar_claim', 'count_claim', 'majority_claim']
        
        for i, speaker in enumerate(characters):
            statement_type = statement_types[i % len(statement_types)]
            
            if statement_type in ['truth_claim', 'liar_claim']:
                target = random.choice([c for c in characters if c.name != speaker.name])
                template = random.choice(self.statement_templates[statement_type])
                content = template.format(about=target.name)
                
                if statement_type == 'truth_claim':
                    is_true = target.is_truth_teller
                else:
                    is_true = not target.is_truth_teller
                
                about = target.name
            
            elif statement_type == 'count_claim':
                actual_truth_tellers = sum(1 for c in characters if c.is_truth_teller)
                # Make counting more challenging with nearby numbers
                if random.random() < 0.3:
                    count = actual_truth_tellers
                else:
                    offset = random.choice([-1, 1])
                    count = max(1, min(len(characters), actual_truth_tellers + offset))
                
                template = random.choice(self.statement_templates[statement_type])
                content = template.format(count=count)
                is_true = (count == actual_truth_tellers)
                about = "group"
            
            else:  # majority_claim
                actual_truth_tellers = sum(1 for c in characters if c.is_truth_teller)
                majority_truth_tellers = actual_truth_tellers > len(characters) / 2
                
                template = random.choice(self.statement_templates[statement_type])
                content = template
                is_true = majority_truth_tellers
                about = "group"
            
            statement = Statement(
                speaker=speaker.name,
                content=content,
                about=about,
                statement_type=statement_type,
                is_true=is_true
            )
            statements.append(statement)
            speaker.statements.append(content)
        
        return statements

    def _create_question(self, characters: List[Character], statements: List[Statement]) -> str:
        """Create the problem question text."""
        # Build the scenario description
        char_list = ", ".join([c.name for c in characters[:-1]]) + f", and {characters[-1].name}"
        
        question_parts = [
            f"On an island where truth-tellers always tell the truth and liars always lie, "
            f"{len(characters)} inhabitants {char_list} make the following statements:"
        ]
        
        # Add each statement
        for statement in statements:
            question_parts.append(f"{statement.speaker} says, '{statement.content}.'")
        
        # Add the question
        actual_truth_tellers = sum(1 for c in characters if c.is_truth_teller)
        
        if actual_truth_tellers == 1:
            question_parts.append("Who is the truth-teller?")
        elif actual_truth_tellers == len(characters) - 1:
            question_parts.append("Who is the liar?")
        else:
            question_parts.append("Who are the truth-tellers?")
        
        return " ".join(question_parts)

    def _generate_choices(self, characters: List[Character], num_truth_tellers: int) -> Tuple[List[str], str]:
        """Generate multiple choice options."""
        truth_tellers = [c.name for c in characters if c.is_truth_teller]
        liars = [c.name for c in characters if not c.is_truth_teller]
        
        # Determine correct answer format
        if num_truth_tellers == 1:
            correct_answer = truth_tellers[0]
        elif num_truth_tellers == len(characters) - 1:
            correct_answer = liars[0]
        else:
            correct_answer = " and ".join(truth_tellers)
        
        # Generate distractors
        distractors = []
        
        # Add individual names as distractors
        for char in characters:
            if char.name != correct_answer and char.name not in correct_answer:
                distractors.append(char.name)
        
        # Add combination distractors
        if num_truth_tellers > 1:
            # Wrong combinations
            for combo_size in [2, 3]:
                if combo_size <= len(characters) and combo_size != num_truth_tellers:
                    for combo in itertools.combinations([c.name for c in characters], combo_size):
                        combo_str = " and ".join(combo)
                        if combo_str != correct_answer and len(distractors) < 6:
                            distractors.append(combo_str)
        
        # Select best distractors
        if len(distractors) >= 3:
            selected_distractors = random.sample(distractors, 3)
        else:
            selected_distractors = distractors[:]
            while len(selected_distractors) < 3:
                selected_distractors.append(f"None of the above")
        
        # Create choices
        choices, correct_letter = self.generate_choices(correct_answer, selected_distractors)
        
        return choices, correct_letter

    def _create_explanation(self, characters: List[Character], statements: List[Statement], correct_answer: str) -> str:
        """Create a clear explanation of the solution."""
        explanation_parts = []
        
        # Analyze each statement
        explanation_parts.append("Let's analyze each statement:")
        
        for statement in statements:
            speaker = next(c for c in characters if c.name == statement.speaker)
            
            # Determine if the statement should be true or false based on speaker
            should_be_true = speaker.is_truth_teller
            actually_true = statement.is_true
            
            if should_be_true == actually_true:
                consistency = "consistent"
            else:
                consistency = "inconsistent"
            
            explanation_parts.append(
                f"{statement.speaker} says '{statement.content}'. "
                f"This statement is {consistency} with {statement.speaker} being a "
                f"{'truth-teller' if speaker.is_truth_teller else 'liar'}."
            )
        
        # Conclude with the answer
        truth_tellers = [c.name for c in characters if c.is_truth_teller]
        if len(truth_tellers) == 1:
            explanation_parts.append(f"Therefore, {truth_tellers[0]} is the truth-teller.")
        else:
            explanation_parts.append(f"Therefore, {' and '.join(truth_tellers)} are the truth-tellers.")
        
        return " ".join(explanation_parts)

    def _extract_constraints(self, statements: List[Statement]) -> List[str]:
        """Extract logical constraints from the problem."""
        constraints = []
        
        for statement in statements:
            if statement.statement_type == 'truth_claim':
                constraints.append(f"If {statement.speaker} is truthful, then {statement.about} is a truth-teller")
            elif statement.statement_type == 'liar_claim':
                constraints.append(f"If {statement.speaker} is truthful, then {statement.about} is a liar")
            elif statement.statement_type == 'count_claim':
                constraints.append(f"If {statement.speaker} is truthful, then the count claim is accurate")
        
        return constraints

    def _extract_reasoning_steps(self, characters: List[Character], statements: List[Statement]) -> List[str]:
        """Extract the logical reasoning steps."""
        steps = []
        
        steps.append("Assume each character is either a truth-teller or liar")
        steps.append("Analyze consistency of each statement with speaker's assumed type")
        steps.append("Find the assignment that makes all statements consistent")
        steps.append("Verify the solution satisfies all constraints")
        
        return steps

    def validate_problem_logic(self, problem: GeneratedProblem) -> Tuple[bool, List[str]]:
        """Validate the logical consistency of the problem."""
        errors = []
        
        # Check that the problem has a unique solution
        # This would require implementing a constraint solver
        # For now, we'll do basic validation
        
        if not problem.question:
            errors.append("Question is empty")
        
        if len(problem.choices) != 4:
            errors.append("Must have exactly 4 choices")
        
        if not problem.answer:
            errors.append("Answer is empty")
        
        if not problem.explanation:
            errors.append("Explanation is empty")
        
        # Check that answer is one of the choices
        answer_found = False
        for choice in problem.choices:
            if problem.answer in choice:
                answer_found = True
                break
        
        if not answer_found:
            errors.append("Answer not found in choices")
        
        return len(errors) == 0, errors

    def calculate_difficulty_score(self, problem: GeneratedProblem) -> float:
        """Calculate the actual difficulty score of the problem."""
        score = 1.0
        
        # Base score from metadata
        num_characters = problem.metadata.get('num_characters', 2)
        score += (num_characters - 2) * 0.5
        
        # Complexity from statement types
        if 'count_claim' in str(problem.constraints):
            score += 0.5
        if 'majority_claim' in str(problem.constraints):
            score += 0.7
        
        # Number of constraints
        score += len(problem.constraints) * 0.2
        
        return min(5.0, score)

