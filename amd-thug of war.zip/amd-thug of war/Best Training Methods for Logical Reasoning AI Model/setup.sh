#!/bin/bash

# Enhanced AAIPL Setup Script
# Sets up the complete enhanced training and inference system

set -e

echo "Enhanced AAIPL Setup"
echo "==================="
echo "Setting up advanced training and inference system for AMD MI300x"
echo ""

# Check if running on AMD MI300x
echo "Checking hardware compatibility..."
if command -v rocm-smi &> /dev/null; then
    echo "ROCm detected:"
    rocm-smi --showproductname || true
else
    echo "Warning: ROCm not detected. Some optimizations may not be available."
fi
echo ""

# Check Python version
echo "Checking Python version..."
python3 --version
if ! python3 -c "import sys; assert sys.version_info >= (3, 8)"; then
    echo "Error: Python 3.8+ required"
    exit 1
fi
echo "Python version OK"
echo ""

# Create virtual environment
echo "Creating virtual environment..."
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "Virtual environment created"
else
    echo "Virtual environment already exists"
fi

# Activate virtual environment
source venv/bin/activate
echo "Virtual environment activated"
echo ""

# Upgrade pip
echo "Upgrading pip..."
pip install --upgrade pip
echo ""

# Install PyTorch with ROCm support
echo "Installing PyTorch with ROCm support..."
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/rocm5.6
echo ""

# Install core dependencies
echo "Installing core dependencies..."
pip install -r requirements.txt
echo ""

# Install Flash Attention
echo "Installing Flash Attention..."
pip install flash-attn --no-build-isolation || echo "Warning: Flash Attention installation failed"
echo ""

# Test installation
echo "Testing installation..."
python3 -c "
import torch
import transformers
print(f'PyTorch version: {torch.__version__}')
print(f'Transformers version: {transformers.__version__}')
print(f'CUDA available: {torch.cuda.is_available()}')
if torch.cuda.is_available():
    print(f'GPU count: {torch.cuda.device_count()}')
    print(f'GPU name: {torch.cuda.get_device_name(0)}')
    print(f'GPU memory: {torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB')
"

if [ $? -eq 0 ]; then
    echo "Installation test passed!"
else
    echo "Installation test failed!"
    exit 1
fi
echo ""

# Create necessary directories
echo "Creating directory structure..."
mkdir -p configs
mkdir -p examples
mkdir -p scripts
mkdir -p data
mkdir -p outputs
mkdir -p logs
echo "Directory structure created"
echo ""

# Make scripts executable
echo "Making scripts executable..."
chmod +x scripts/*.sh
chmod +x main_trainer.py
chmod +x main_inference.py
echo "Scripts made executable"
echo ""

# Download example model (optional)
read -p "Download example model for testing? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Downloading example model..."
    python3 -c "
from transformers import AutoTokenizer, AutoModelForCausalLM
model_name = 'Qwen/Qwen2.5-1.5B'  # Smaller model for testing
print(f'Downloading {model_name}...')
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)
print('Model downloaded successfully!')
"
    echo "Example model downloaded"
else
    echo "Skipping model download"
fi
echo ""

# Create example configuration
echo "Creating example configuration..."
cat > configs/example_config.json << 'EOF'
{
  "model_name": "Qwen/Qwen2.5-1.5B",
  "output_dir": "./outputs/example_run",
  "max_length": 1024,
  "num_epochs": 1,
  "learning_rate": 2e-5,
  "batch_size": 4,
  "gradient_accumulation_steps": 2,
  
  "enable_synthetic_data": true,
  "enable_grpo": true,
  "enable_dpo": false,
  "enable_curriculum": true,
  "enable_self_training": false,
  
  "synthetic_data_size": 1000,
  "curriculum_stages": 2,
  "self_training_iterations": 1
}
EOF
echo "Example configuration created: configs/example_config.json"
echo ""

# Create quick test script
echo "Creating quick test script..."
cat > test_system.py << 'EOF'
#!/usr/bin/env python3
"""Quick system test script."""

import torch
import sys
from pathlib import Path

# Add project to path
sys.path.insert(0, str(Path(__file__).parent))

def test_imports():
    """Test all imports."""
    print("Testing imports...")
    
    try:
        from data_generation.dataset_builder import DatasetBuilder
        print("✓ Data generation module")
    except Exception as e:
        print(f"✗ Data generation module: {e}")
        return False
    
    try:
        from training.grpo_trainer import GRPOTrainer
        from training.dpo_trainer import DPOTrainer
        print("✓ Training modules")
    except Exception as e:
        print(f"✗ Training modules: {e}")
        return False
    
    try:
        from inference.inference_engine import InferenceEngine
        print("✓ Inference module")
    except Exception as e:
        print(f"✗ Inference module: {e}")
        return False
    
    return True

def test_gpu():
    """Test GPU availability."""
    print("\nTesting GPU...")
    
    if not torch.cuda.is_available():
        print("✗ CUDA not available")
        return False
    
    print(f"✓ CUDA available")
    print(f"  Device count: {torch.cuda.device_count()}")
    print(f"  Current device: {torch.cuda.current_device()}")
    print(f"  Device name: {torch.cuda.get_device_name(0)}")
    
    # Test memory allocation
    try:
        x = torch.randn(1000, 1000).cuda()
        y = torch.randn(1000, 1000).cuda()
        z = torch.mm(x, y)
        print(f"✓ GPU computation test passed")
        return True
    except Exception as e:
        print(f"✗ GPU computation test failed: {e}")
        return False

def main():
    """Run all tests."""
    print("Enhanced AAIPL System Test")
    print("=" * 30)
    
    success = True
    success &= test_imports()
    success &= test_gpu()
    
    print("\n" + "=" * 30)
    if success:
        print("✓ All tests passed! System is ready.")
        print("\nNext steps:")
        print("1. Run training: bash scripts/train.sh configs/example_config.json")
        print("2. Run inference: bash scripts/inference.sh")
    else:
        print("✗ Some tests failed. Please check the installation.")
        sys.exit(1)

if __name__ == "__main__":
    main()
EOF

chmod +x test_system.py
echo "Quick test script created: test_system.py"
echo ""

# Run system test
echo "Running system test..."
python3 test_system.py

if [ $? -eq 0 ]; then
    echo ""
    echo "Setup completed successfully!"
    echo ""
    echo "Enhanced AAIPL System Ready"
    echo "=========================="
    echo ""
    echo "Quick Start:"
    echo "1. Training: bash scripts/train.sh configs/example_config.json"
    echo "2. Inference: bash scripts/inference.sh"
    echo "3. Interactive: bash scripts/inference.sh Qwen/Qwen2.5-4B configs/inference_config.json interactive"
    echo ""
    echo "Documentation:"
    echo "- Training config: configs/training_config.json"
    echo "- Inference config: configs/inference_config.json"
    echo "- Example prompts: examples/test_prompts.txt"
    echo ""
    echo "Advanced Features:"
    echo "- Synthetic data generation with curriculum learning"
    echo "- GRPO and DPO training methodologies"
    echo "- AMD MI300x optimized inference with speculative decoding"
    echo "- Reasoning-aware generation for logical problems"
    echo ""
else
    echo ""
    echo "Setup failed! Please check the error messages above."
    exit 1
fi

