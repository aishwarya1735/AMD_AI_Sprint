"""
Blood Relations and Family Tree Problem Generator

This module generates sophisticated blood relations problems involving complex
family relationships, generational puzzles, and logical deduction about family
structures. The generator uses graph-based family tree construction to ensure
logical consistency.
"""

import random
import networkx as nx
from typing import Dict, List, Any, Optional, Tuple, Set
from dataclasses import dataclass
from enum import Enum
import logging

from .base_generator import BaseGenerator, GeneratedProblem, DifficultyLevel, GenerationConfig

logger = logging.getLogger(__name__)


class Gender(Enum):
    """Gender enumeration."""
    MALE = "male"
    FEMALE = "female"


class RelationType(Enum):
    """Types of family relationships."""
    PARENT = "parent"
    CHILD = "child"
    SIBLING = "sibling"
    SPOUSE = "spouse"
    GRANDPARENT = "grandparent"
    GRANDCHILD = "grandchild"
    UNCLE_AUNT = "uncle_aunt"
    NEPHEW_NIECE = "nephew_niece"
    COUSIN = "cousin"
    IN_LAW = "in_law"


@dataclass
class FamilyMember:
    """Represents a family member."""
    name: str
    gender: Gender
    generation: int  # 0 = reference, -1 = parents, +1 = children, etc.
    relationships: Dict[str, RelationType] = None
    attributes: Dict[str, Any] = None

    def __post_init__(self):
        if self.relationships is None:
            self.relationships = {}
        if self.attributes is None:
            self.attributes = {}


@dataclass
class FamilyRelationship:
    """Represents a relationship between two family members."""
    person1: str
    person2: str
    relationship: RelationType
    description: str
    is_direct: bool = True  # Direct vs. derived relationship


class BloodRelationsGenerator(BaseGenerator):
    """
    Generator for Blood Relations problems with systematic difficulty progression.
    
    Difficulty Levels:
    - BEGINNER: 3-4 people, simple direct relationships (parent, child, sibling)
    - INTERMEDIATE: 4-6 people, extended family (grandparents, aunts, uncles)
    - ADVANCED: 6-8 people, complex relationships (cousins, in-laws)
    - EXPERT: 8+ people, multi-generational puzzles with intricate relationships
    """

    def __init__(self, config: Optional[GenerationConfig] = None):
        super().__init__("Blood Relations and Family Tree", config)
        
        # Names for family members
        self.male_names = [
            'Adam', 'Ben', 'Carl', 'David', 'Eric', 'Frank', 'George', 'Henry',
            'Ivan', 'Jack', 'Kevin', 'Leo', 'Mark', 'Nathan', 'Oscar', 'Peter',
            'Quinn', 'Robert', 'Sam', 'Tom', 'Victor', 'William', 'Xavier', 'Zach'
        ]
        
        self.female_names = [
            'Alice', 'Betty', 'Carol', 'Diana', 'Emma', 'Fiona', 'Grace', 'Helen',
            'Iris', 'Julia', 'Kate', 'Linda', 'Mary', 'Nancy', 'Olivia', 'Paula',
            'Rachel', 'Susan', 'Tina', 'Uma', 'Vera', 'Wendy', 'Yvonne', 'Zara'
        ]
        
        # Relationship description templates
        self.relationship_templates = {
            RelationType.PARENT: {
                Gender.MALE: ["{person1} is {person2}'s father", "{person1} is the father of {person2}"],
                Gender.FEMALE: ["{person1} is {person2}'s mother", "{person1} is the mother of {person2}"]
            },
            RelationType.CHILD: {
                Gender.MALE: ["{person1} is {person2}'s son", "{person1} is the son of {person2}"],
                Gender.FEMALE: ["{person1} is {person2}'s daughter", "{person1} is the daughter of {person2}"]
            },
            RelationType.SIBLING: {
                Gender.MALE: ["{person1} is {person2}'s brother", "{person1} is the brother of {person2}"],
                Gender.FEMALE: ["{person1} is {person2}'s sister", "{person1} is the sister of {person2}"]
            },
            RelationType.GRANDPARENT: {
                Gender.MALE: ["{person1} is {person2}'s grandfather", "{person1} is the grandfather of {person2}"],
                Gender.FEMALE: ["{person1} is {person2}'s grandmother", "{person1} is the grandmother of {person2}"]
            },
            RelationType.GRANDCHILD: {
                Gender.MALE: ["{person1} is {person2}'s grandson", "{person1} is the grandson of {person2}"],
                Gender.FEMALE: ["{person1} is {person2}'s granddaughter", "{person1} is the granddaughter of {person2}"]
            },
            RelationType.UNCLE_AUNT: {
                Gender.MALE: ["{person1} is {person2}'s uncle", "{person1} is the uncle of {person2}"],
                Gender.FEMALE: ["{person1} is {person2}'s aunt", "{person1} is the aunt of {person2}"]
            },
            RelationType.NEPHEW_NIECE: {
                Gender.MALE: ["{person1} is {person2}'s nephew", "{person1} is the nephew of {person2}"],
                Gender.FEMALE: ["{person1} is {person2}'s niece", "{person1} is the niece of {person2}"]
            },
            RelationType.COUSIN: {
                Gender.MALE: ["{person1} is {person2}'s cousin", "{person1} and {person2} are cousins"],
                Gender.FEMALE: ["{person1} is {person2}'s cousin", "{person1} and {person2} are cousins"]
            }
        }

    def generate_problem_core(self, difficulty: DifficultyLevel) -> GeneratedProblem:
        """Generate a blood relations problem of specified difficulty."""
        
        # Determine problem parameters
        num_people, max_generations, relationship_complexity = self._get_difficulty_parameters(difficulty)
        
        # Generate family tree
        family_tree = self._generate_family_tree(num_people, max_generations)
        
        # Extract family members
        family_members = list(family_tree.nodes())
        
        # Generate relationship statements
        relationships = self._generate_relationship_statements(family_tree, relationship_complexity)
        
        # Choose target relationship to ask about
        target_person1, target_person2, target_relationship = self._choose_target_relationship(family_tree)
        
        # Create the problem question
        question = self._create_question(relationships, target_person1, target_person2)
        
        # Generate answer choices
        choices, correct_answer = self._generate_choices(target_person1, target_person2, target_relationship, family_tree)
        
        # Create explanation
        explanation = self._create_explanation(family_tree, target_person1, target_person2, target_relationship)
        
        # Extract constraints and reasoning steps
        constraints = self._extract_constraints(relationships)
        reasoning_steps = self._extract_reasoning_steps(relationships, target_relationship)
        
        return GeneratedProblem(
            topic=self.topic,
            question=question,
            choices=choices,
            answer=correct_answer,
            explanation=explanation,
            difficulty=difficulty,
            quality_score=0.0,
            constraints=constraints,
            reasoning_steps=reasoning_steps,
            metadata={
                'num_people': num_people,
                'max_generations': max_generations,
                'relationship_complexity': relationship_complexity,
                'family_members': family_members,
                'target_relationship': target_relationship.value if target_relationship else None
            },
            generation_timestamp="",
            problem_id=""
        )

    def _get_difficulty_parameters(self, difficulty: DifficultyLevel) -> Tuple[int, int, str]:
        """Get problem parameters based on difficulty level."""
        if difficulty == DifficultyLevel.BEGINNER:
            num_people = random.choice([3, 4])
            max_generations = 2
            complexity = 'simple'
        elif difficulty == DifficultyLevel.INTERMEDIATE:
            num_people = random.choice([4, 5, 6])
            max_generations = 3
            complexity = 'moderate'
        elif difficulty == DifficultyLevel.ADVANCED:
            num_people = random.choice([6, 7, 8])
            max_generations = 3
            complexity = 'complex'
        else:  # EXPERT
            num_people = random.choice([8, 9, 10])
            max_generations = 4
            complexity = 'very_complex'
        
        return num_people, max_generations, complexity

    def _generate_family_tree(self, num_people: int, max_generations: int) -> nx.Graph:
        """Generate a family tree using graph structure."""
        family_tree = nx.Graph()
        
        # Start with a reference person
        reference_name = random.choice(self.male_names + self.female_names)
        reference_gender = Gender.MALE if reference_name in self.male_names else Gender.FEMALE
        
        family_tree.add_node(reference_name, 
                           gender=reference_gender, 
                           generation=0,
                           used_name=reference_name)
        
        used_names = {reference_name}
        people_added = 1
        
        # Add family members generation by generation
        current_generation = 0
        
        while people_added < num_people and abs(current_generation) <= max_generations:
            # Decide whether to go up (parents) or down (children) in generations
            if current_generation >= 0 and random.random() < 0.6:
                # Add parents
                current_generation -= 1
                self._add_parents(family_tree, current_generation, used_names, num_people - people_added)
            else:
                # Add children
                current_generation += 1
                self._add_children(family_tree, current_generation, used_names, num_people - people_added)
            
            people_added = len(family_tree.nodes())
            
            # Prevent infinite loops
            if people_added >= num_people:
                break
        
        # Add some siblings if needed
        if people_added < num_people:
            self._add_siblings(family_tree, used_names, num_people - people_added)
        
        return family_tree

    def _add_parents(self, family_tree: nx.Graph, generation: int, used_names: Set[str], max_to_add: int):
        """Add parents to existing family members."""
        # Find people who don't have parents yet
        candidates = [node for node in family_tree.nodes() 
                     if family_tree.nodes[node]['generation'] == generation + 1]
        
        if not candidates or max_to_add <= 0:
            return
        
        # Choose a person to add parents for
        child = random.choice(candidates)
        
        # Add father
        if max_to_add > 0:
            father_name = self._get_unused_name(used_names, self.male_names)
            if father_name:
                family_tree.add_node(father_name, 
                                   gender=Gender.MALE, 
                                   generation=generation)
                family_tree.add_edge(father_name, child, relationship='parent')
                used_names.add(father_name)
                max_to_add -= 1
        
        # Add mother
        if max_to_add > 0:
            mother_name = self._get_unused_name(used_names, self.female_names)
            if mother_name:
                family_tree.add_node(mother_name, 
                                   gender=Gender.FEMALE, 
                                   generation=generation)
                family_tree.add_edge(mother_name, child, relationship='parent')
                used_names.add(mother_name)

    def _add_children(self, family_tree: nx.Graph, generation: int, used_names: Set[str], max_to_add: int):
        """Add children to existing family members."""
        # Find people who could have children
        candidates = [node for node in family_tree.nodes() 
                     if family_tree.nodes[node]['generation'] == generation - 1]
        
        if not candidates or max_to_add <= 0:
            return
        
        # Choose a parent
        parent = random.choice(candidates)
        
        # Add 1-2 children
        num_children = min(random.choice([1, 2]), max_to_add)
        
        for _ in range(num_children):
            child_gender = random.choice([Gender.MALE, Gender.FEMALE])
            child_names = self.male_names if child_gender == Gender.MALE else self.female_names
            child_name = self._get_unused_name(used_names, child_names)
            
            if child_name:
                family_tree.add_node(child_name, 
                                   gender=child_gender, 
                                   generation=generation)
                family_tree.add_edge(parent, child_name, relationship='parent')
                used_names.add(child_name)

    def _add_siblings(self, family_tree: nx.Graph, used_names: Set[str], max_to_add: int):
        """Add siblings to existing family members."""
        if max_to_add <= 0:
            return
        
        # Find someone who could have siblings
        candidates = [node for node in family_tree.nodes() 
                     if family_tree.nodes[node]['generation'] != 0]  # Not the reference person
        
        if not candidates:
            return
        
        person = random.choice(candidates)
        generation = family_tree.nodes[person]['generation']
        
        # Find parents of this person
        parents = [neighbor for neighbor in family_tree.neighbors(person)
                  if family_tree.nodes[neighbor]['generation'] == generation - 1]
        
        # Add sibling
        sibling_gender = random.choice([Gender.MALE, Gender.FEMALE])
        sibling_names = self.male_names if sibling_gender == Gender.MALE else self.female_names
        sibling_name = self._get_unused_name(used_names, sibling_names)
        
        if sibling_name:
            family_tree.add_node(sibling_name, 
                               gender=sibling_gender, 
                               generation=generation)
            
            # Connect to same parents
            for parent in parents:
                family_tree.add_edge(parent, sibling_name, relationship='parent')
            
            used_names.add(sibling_name)

    def _get_unused_name(self, used_names: Set[str], name_list: List[str]) -> Optional[str]:
        """Get an unused name from the list."""
        available_names = [name for name in name_list if name not in used_names]
        return random.choice(available_names) if available_names else None

    def _generate_relationship_statements(self, family_tree: nx.Graph, complexity: str) -> List[FamilyRelationship]:
        """Generate relationship statements based on the family tree."""
        relationships = []
        nodes = list(family_tree.nodes())
        
        # Generate direct relationships from the tree
        for edge in family_tree.edges():
            person1, person2 = edge
            person1_data = family_tree.nodes[person1]
            person2_data = family_tree.nodes[person2]
            
            # Determine relationship direction
            if person1_data['generation'] < person2_data['generation']:
                # person1 is parent of person2
                rel_type = RelationType.PARENT
                gender = person1_data['gender']
                template = random.choice(self.relationship_templates[rel_type][gender])
                description = template.format(person1=person1, person2=person2)
            else:
                # person2 is parent of person1
                rel_type = RelationType.PARENT
                gender = person2_data['gender']
                template = random.choice(self.relationship_templates[rel_type][gender])
                description = template.format(person1=person2, person2=person1)
            
            relationships.append(FamilyRelationship(
                person1=person1 if person1_data['generation'] < person2_data['generation'] else person2,
                person2=person2 if person1_data['generation'] < person2_data['generation'] else person1,
                relationship=rel_type,
                description=description,
                is_direct=True
            ))
        
        # Add some derived relationships based on complexity
        if complexity in ['moderate', 'complex', 'very_complex']:
            self._add_derived_relationships(family_tree, relationships, complexity)
        
        return relationships

    def _add_derived_relationships(self, family_tree: nx.Graph, relationships: List[FamilyRelationship], complexity: str):
        """Add derived relationships like grandparent, uncle, cousin, etc."""
        nodes = list(family_tree.nodes())
        
        # Add grandparent relationships
        for node in nodes:
            node_data = family_tree.nodes[node]
            
            # Find grandparents (parents of parents)
            parents = [n for n in family_tree.neighbors(node) 
                      if family_tree.nodes[n]['generation'] == node_data['generation'] - 1]
            
            for parent in parents:
                grandparents = [n for n in family_tree.neighbors(parent)
                              if family_tree.nodes[n]['generation'] == node_data['generation'] - 2]
                
                for grandparent in grandparents:
                    gp_data = family_tree.nodes[grandparent]
                    template = random.choice(self.relationship_templates[RelationType.GRANDPARENT][gp_data['gender']])
                    description = template.format(person1=grandparent, person2=node)
                    
                    relationships.append(FamilyRelationship(
                        person1=grandparent,
                        person2=node,
                        relationship=RelationType.GRANDPARENT,
                        description=description,
                        is_direct=False
                    ))
        
        # Add sibling relationships
        if complexity in ['complex', 'very_complex']:
            self._add_sibling_relationships(family_tree, relationships)
        
        # Add uncle/aunt relationships
        if complexity in ['complex', 'very_complex']:
            self._add_uncle_aunt_relationships(family_tree, relationships)

    def _add_sibling_relationships(self, family_tree: nx.Graph, relationships: List[FamilyRelationship]):
        """Add sibling relationships."""
        nodes = list(family_tree.nodes())
        
        for node1 in nodes:
            for node2 in nodes:
                if node1 != node2:
                    node1_data = family_tree.nodes[node1]
                    node2_data = family_tree.nodes[node2]
                    
                    # Check if they have the same parents (siblings)
                    if node1_data['generation'] == node2_data['generation']:
                        parents1 = set(n for n in family_tree.neighbors(node1)
                                     if family_tree.nodes[n]['generation'] == node1_data['generation'] - 1)
                        parents2 = set(n for n in family_tree.neighbors(node2)
                                     if family_tree.nodes[n]['generation'] == node2_data['generation'] - 1)
                        
                        if parents1 and parents2 and parents1 == parents2:
                            # They are siblings
                            template = random.choice(self.relationship_templates[RelationType.SIBLING][node1_data['gender']])
                            description = template.format(person1=node1, person2=node2)
                            
                            relationships.append(FamilyRelationship(
                                person1=node1,
                                person2=node2,
                                relationship=RelationType.SIBLING,
                                description=description,
                                is_direct=False
                            ))
                            break  # Only add one direction

    def _add_uncle_aunt_relationships(self, family_tree: nx.Graph, relationships: List[FamilyRelationship]):
        """Add uncle/aunt relationships."""
        nodes = list(family_tree.nodes())
        
        for node in nodes:
            node_data = family_tree.nodes[node]
            
            # Find parents
            parents = [n for n in family_tree.neighbors(node)
                      if family_tree.nodes[n]['generation'] == node_data['generation'] - 1]
            
            for parent in parents:
                # Find siblings of parent (uncles/aunts)
                parent_data = family_tree.nodes[parent]
                grandparents = [n for n in family_tree.neighbors(parent)
                              if family_tree.nodes[n]['generation'] == parent_data['generation'] - 1]
                
                for grandparent in grandparents:
                    # Find other children of grandparent (parent's siblings)
                    uncles_aunts = [n for n in family_tree.neighbors(grandparent)
                                  if (family_tree.nodes[n]['generation'] == parent_data['generation'] 
                                      and n != parent)]
                    
                    for uncle_aunt in uncles_aunts:
                        ua_data = family_tree.nodes[uncle_aunt]
                        template = random.choice(self.relationship_templates[RelationType.UNCLE_AUNT][ua_data['gender']])
                        description = template.format(person1=uncle_aunt, person2=node)
                        
                        relationships.append(FamilyRelationship(
                            person1=uncle_aunt,
                            person2=node,
                            relationship=RelationType.UNCLE_AUNT,
                            description=description,
                            is_direct=False
                        ))

    def _choose_target_relationship(self, family_tree: nx.Graph) -> Tuple[str, str, RelationType]:
        """Choose the target relationship to ask about."""
        nodes = list(family_tree.nodes())
        
        # Try to find an interesting relationship to ask about
        for _ in range(20):  # Max attempts
            person1 = random.choice(nodes)
            person2 = random.choice(nodes)
            
            if person1 != person2:
                relationship = self._determine_relationship(family_tree, person1, person2)
                if relationship:
                    return person1, person2, relationship
        
        # Fallback: just pick two people
        person1, person2 = random.sample(nodes, 2)
        relationship = self._determine_relationship(family_tree, person1, person2)
        
        return person1, person2, relationship

    def _determine_relationship(self, family_tree: nx.Graph, person1: str, person2: str) -> Optional[RelationType]:
        """Determine the relationship between two people in the family tree."""
        if person1 == person2:
            return None
        
        person1_data = family_tree.nodes[person1]
        person2_data = family_tree.nodes[person2]
        
        gen_diff = person1_data['generation'] - person2_data['generation']
        
        # Direct parent-child relationship
        if family_tree.has_edge(person1, person2):
            if gen_diff == -1:
                return RelationType.PARENT
            elif gen_diff == 1:
                return RelationType.CHILD
        
        # Grandparent-grandchild relationship
        if abs(gen_diff) == 2:
            if self._are_related_through_path(family_tree, person1, person2, 2):
                if gen_diff == -2:
                    return RelationType.GRANDPARENT
                else:
                    return RelationType.GRANDCHILD
        
        # Sibling relationship
        if gen_diff == 0:
            if self._are_siblings(family_tree, person1, person2):
                return RelationType.SIBLING
        
        # Uncle/aunt relationship
        if abs(gen_diff) == 1:
            if self._are_uncle_aunt_nephew_niece(family_tree, person1, person2):
                if gen_diff == -1:
                    return RelationType.UNCLE_AUNT
                else:
                    return RelationType.NEPHEW_NIECE
        
        return None

    def _are_related_through_path(self, family_tree: nx.Graph, person1: str, person2: str, path_length: int) -> bool:
        """Check if two people are related through a path of specific length."""
        try:
            path = nx.shortest_path(family_tree, person1, person2)
            return len(path) - 1 == path_length
        except nx.NetworkXNoPath:
            return False

    def _are_siblings(self, family_tree: nx.Graph, person1: str, person2: str) -> bool:
        """Check if two people are siblings."""
        person1_data = family_tree.nodes[person1]
        person2_data = family_tree.nodes[person2]
        
        if person1_data['generation'] != person2_data['generation']:
            return False
        
        # Find parents of both
        parents1 = set(n for n in family_tree.neighbors(person1)
                      if family_tree.nodes[n]['generation'] == person1_data['generation'] - 1)
        parents2 = set(n for n in family_tree.neighbors(person2)
                      if family_tree.nodes[n]['generation'] == person2_data['generation'] - 1)
        
        return parents1 and parents2 and parents1 == parents2

    def _are_uncle_aunt_nephew_niece(self, family_tree: nx.Graph, person1: str, person2: str) -> bool:
        """Check if two people have uncle/aunt - nephew/niece relationship."""
        person1_data = family_tree.nodes[person1]
        person2_data = family_tree.nodes[person2]
        
        gen_diff = person1_data['generation'] - person2_data['generation']
        
        if abs(gen_diff) != 1:
            return False
        
        if gen_diff == -1:  # person1 is uncle/aunt of person2
            # person1 should be sibling of person2's parent
            parents2 = [n for n in family_tree.neighbors(person2)
                       if family_tree.nodes[n]['generation'] == person2_data['generation'] - 1]
            
            for parent in parents2:
                if self._are_siblings(family_tree, person1, parent):
                    return True
        
        return False

    def _create_question(self, relationships: List[FamilyRelationship], target_person1: str, target_person2: str) -> str:
        """Create the problem question text."""
        question_parts = []
        
        # Add relationship statements
        question_parts.append("Based on the following information:")
        
        # Select a subset of relationships to include
        selected_relationships = random.sample(relationships, min(len(relationships), 4))
        
        for i, rel in enumerate(selected_relationships, 1):
            question_parts.append(f"{i}. {rel.description}.")
        
        # Add the question
        question_parts.append(f"What is the relationship between {target_person1} and {target_person2}?")
        
        return " ".join(question_parts)

    def _generate_choices(self, person1: str, person2: str, target_relationship: Optional[RelationType], 
                         family_tree: nx.Graph) -> Tuple[List[str], str]:
        """Generate multiple choice options."""
        person1_data = family_tree.nodes[person1]
        person2_data = family_tree.nodes[person2]
        
        # Determine correct answer
        if target_relationship:
            if target_relationship == RelationType.PARENT:
                if person1_data['gender'] == Gender.MALE:
                    correct_answer = f"{person1} is {person2}'s father"
                else:
                    correct_answer = f"{person1} is {person2}'s mother"
            elif target_relationship == RelationType.CHILD:
                if person1_data['gender'] == Gender.MALE:
                    correct_answer = f"{person1} is {person2}'s son"
                else:
                    correct_answer = f"{person1} is {person2}'s daughter"
            elif target_relationship == RelationType.SIBLING:
                if person1_data['gender'] == Gender.MALE:
                    correct_answer = f"{person1} is {person2}'s brother"
                else:
                    correct_answer = f"{person1} is {person2}'s sister"
            elif target_relationship == RelationType.GRANDPARENT:
                if person1_data['gender'] == Gender.MALE:
                    correct_answer = f"{person1} is {person2}'s grandfather"
                else:
                    correct_answer = f"{person1} is {person2}'s grandmother"
            elif target_relationship == RelationType.UNCLE_AUNT:
                if person1_data['gender'] == Gender.MALE:
                    correct_answer = f"{person1} is {person2}'s uncle"
                else:
                    correct_answer = f"{person1} is {person2}'s aunt"
            else:
                correct_answer = f"{person1} and {person2} are related"
        else:
            correct_answer = f"{person1} and {person2} are not directly related"
        
        # Generate distractors
        distractors = []
        
        # Add common relationship types as distractors
        if person1_data['gender'] == Gender.MALE:
            distractors.extend([
                f"{person1} is {person2}'s father",
                f"{person1} is {person2}'s son", 
                f"{person1} is {person2}'s brother",
                f"{person1} is {person2}'s grandfather",
                f"{person1} is {person2}'s uncle"
            ])
        else:
            distractors.extend([
                f"{person1} is {person2}'s mother",
                f"{person1} is {person2}'s daughter",
                f"{person1} is {person2}'s sister", 
                f"{person1} is {person2}'s grandmother",
                f"{person1} is {person2}'s aunt"
            ])
        
        # Remove correct answer from distractors
        distractors = [d for d in distractors if d != correct_answer]
        
        # Select 3 distractors
        if len(distractors) >= 3:
            selected_distractors = random.sample(distractors, 3)
        else:
            selected_distractors = distractors[:]
            while len(selected_distractors) < 3:
                selected_distractors.append("They are not related")
        
        # Create choices
        choices, correct_letter = self.generate_choices(correct_answer, selected_distractors)
        
        return choices, correct_letter

    def _create_explanation(self, family_tree: nx.Graph, person1: str, person2: str, 
                          target_relationship: Optional[RelationType]) -> str:
        """Create a clear explanation of the solution."""
        explanation_parts = []
        
        explanation_parts.append("Let's trace the family relationships step by step:")
        
        if target_relationship:
            # Explain the relationship path
            try:
                path = nx.shortest_path(family_tree, person1, person2)
                explanation_parts.append(f"Path from {person1} to {person2}: {' → '.join(path)}")
                
                # Explain each step
                for i in range(len(path) - 1):
                    current = path[i]
                    next_person = path[i + 1]
                    current_data = family_tree.nodes[current]
                    next_data = family_tree.nodes[next_person]
                    
                    if current_data['generation'] < next_data['generation']:
                        explanation_parts.append(f"{current} is the parent of {next_person}")
                    else:
                        explanation_parts.append(f"{next_person} is the parent of {current}")
                
                # Final relationship
                person1_data = family_tree.nodes[person1]
                if target_relationship == RelationType.PARENT:
                    if person1_data['gender'] == Gender.MALE:
                        explanation_parts.append(f"Therefore, {person1} is {person2}'s father.")
                    else:
                        explanation_parts.append(f"Therefore, {person1} is {person2}'s mother.")
                elif target_relationship == RelationType.GRANDPARENT:
                    if person1_data['gender'] == Gender.MALE:
                        explanation_parts.append(f"Therefore, {person1} is {person2}'s grandfather.")
                    else:
                        explanation_parts.append(f"Therefore, {person1} is {person2}'s grandmother.")
                # Add more relationship explanations as needed
                
            except nx.NetworkXNoPath:
                explanation_parts.append(f"{person1} and {person2} are not directly related in this family tree.")
        else:
            explanation_parts.append(f"{person1} and {person2} are not directly related.")
        
        return " ".join(explanation_parts)

    def _extract_constraints(self, relationships: List[FamilyRelationship]) -> List[str]:
        """Extract logical constraints from the relationships."""
        constraints = []
        
        for rel in relationships:
            constraints.append(f"Relationship constraint: {rel.description}")
        
        constraints.append("Family tree must be logically consistent")
        constraints.append("Each person has at most two parents")
        constraints.append("Relationships must be symmetric where applicable")
        
        return constraints

    def _extract_reasoning_steps(self, relationships: List[FamilyRelationship], target_relationship: Optional[RelationType]) -> List[str]:
        """Extract the logical reasoning steps."""
        steps = []
        
        steps.append("Parse all given family relationships")
        steps.append("Build a mental family tree from the relationships")
        steps.append("Identify the path between the target individuals")
        steps.append("Determine the relationship type based on generational difference")
        steps.append("Consider gender to specify the exact relationship term")
        
        return steps

    def validate_problem_logic(self, problem: GeneratedProblem) -> Tuple[bool, List[str]]:
        """Validate the logical consistency of the problem."""
        errors = []
        
        if not problem.question:
            errors.append("Question is empty")
        
        if len(problem.choices) != 4:
            errors.append("Must have exactly 4 choices")
        
        if not problem.answer:
            errors.append("Answer is empty")
        
        if not problem.explanation:
            errors.append("Explanation is empty")
        
        # Check that answer is one of the choices
        answer_found = False
        for choice in problem.choices:
            if problem.answer in choice:
                answer_found = True
                break
        
        if not answer_found:
            errors.append("Answer not found in choices")
        
        return len(errors) == 0, errors

    def calculate_difficulty_score(self, problem: GeneratedProblem) -> float:
        """Calculate the actual difficulty score of the problem."""
        score = 1.0
        
        # Base score from number of people
        num_people = problem.metadata.get('num_people', 3)
        score += (num_people - 3) * 0.2
        
        # Complexity from generations
        max_generations = problem.metadata.get('max_generations', 2)
        score += (max_generations - 2) * 0.3
        
        # Relationship complexity
        target_relationship = problem.metadata.get('target_relationship', '')
        if target_relationship in ['grandparent', 'grandchild']:
            score += 0.5
        elif target_relationship in ['uncle_aunt', 'nephew_niece']:
            score += 0.7
        elif target_relationship == 'cousin':
            score += 1.0
        
        return min(5.0, score)

