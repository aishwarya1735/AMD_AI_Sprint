"""
Optimization Utilities for AMD MI300x

This module provides specialized optimization utilities for AMD MI300x hardware,
including memory optimization, ROCm-specific optimizations, and performance
tuning for logical reasoning model training.
"""

import torch
import torch.nn as nn
import numpy as np
from typing import Dict, List, Any, Optional, Tuple, Union
import logging
import gc
import os
from contextlib import contextmanager

logger = logging.getLogger(__name__)


class AMDOptimizer:
    """AMD MI300x specific optimizations."""
    
    def __init__(self, config: Any):
        self.config = config
        self.device_info = self._get_device_info()
        self._apply_rocm_optimizations()
        
        logger.info("AMD Optimizer initialized")
        logger.info(f"Device info: {self.device_info}")
    
    def _get_device_info(self) -> Dict[str, Any]:
        """Get AMD device information."""
        info = {}
        
        if torch.cuda.is_available():
            info['device_count'] = torch.cuda.device_count()
            info['device_name'] = torch.cuda.get_device_name(0)
            info['memory_total'] = torch.cuda.get_device_properties(0).total_memory / 1024**3
            info['compute_capability'] = torch.cuda.get_device_capability(0)
            
            # ROCm specific information
            if hasattr(torch.version, 'hip'):
                info['rocm_version'] = torch.version.hip
            
            # Check for MI300x specific features
            device_name = info['device_name'].lower()
            if 'mi300' in device_name:
                info['is_mi300x'] = True
                info['hbm3_memory'] = True
                info['recommended_batch_size'] = self._get_recommended_batch_size()
            else:
                info['is_mi300x'] = False
                info['hbm3_memory'] = False
        
        return info
    
    def _get_recommended_batch_size(self) -> int:
        """Get recommended batch size for MI300x."""
        # MI300x has 192GB HBM3, can handle larger batches
        memory_gb = self.device_info.get('memory_total', 32)
        
        if memory_gb >= 180:  # MI300x
            return 64
        elif memory_gb >= 80:  # High-end GPU
            return 32
        elif memory_gb >= 40:  # Mid-range GPU
            return 16
        else:  # Lower-end GPU
            return 8
    
    def _apply_rocm_optimizations(self):
        """Apply ROCm specific optimizations."""
        if not torch.cuda.is_available():
            return
        
        # Enable TensorFloat-32 for better performance
        if hasattr(self.config, 'tf32') and self.config.tf32:
            torch.backends.cuda.matmul.allow_tf32 = True
            torch.backends.cudnn.allow_tf32 = True
            logger.info("TF32 enabled for AMD GPU")
        
        # Set memory fraction for MI300x
        if hasattr(self.config, 'rocm_memory_fraction'):
            torch.cuda.set_per_process_memory_fraction(self.config.rocm_memory_fraction)
            logger.info(f"Memory fraction set to {self.config.rocm_memory_fraction}")
        
        # Enable memory pool for better allocation
        os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:512'
        
        # ROCm specific environment variables
        rocm_env_vars = {
            'HSA_FORCE_FINE_GRAIN_PCIE': '1',  # Better PCIe performance
            'HIP_VISIBLE_DEVICES': '0',        # Use first GPU
            'ROCM_PATH': '/opt/rocm',          # ROCm installation path
        }
        
        for key, value in rocm_env_vars.items():
            if key not in os.environ:
                os.environ[key] = value
                logger.debug(f"Set {key}={value}")
    
    def optimize_model_for_amd(self, model: nn.Module) -> nn.Module:
        """Apply AMD-specific model optimizations."""
        # Enable gradient checkpointing for memory efficiency
        if hasattr(model, 'gradient_checkpointing_enable'):
            model.gradient_checkpointing_enable()
            logger.info("Gradient checkpointing enabled")
        
        # Optimize attention computation for AMD
        if hasattr(model.config, 'attn_implementation'):
            model.config.attn_implementation = 'flash_attention_2'
            logger.info("Flash Attention 2 enabled for AMD")
        
        # Set optimal data types
        if self.device_info.get('is_mi300x', False):
            # MI300x supports bfloat16 efficiently
            model = model.to(dtype=torch.bfloat16)
            logger.info("Model converted to bfloat16 for MI300x")
        
        return model
    
    def get_optimal_batch_size(self, model_size_gb: float) -> int:
        """Calculate optimal batch size based on model size and available memory."""
        available_memory = self.device_info.get('memory_total', 32)
        
        # Reserve memory for gradients, optimizer states, and activations
        usable_memory = available_memory * 0.7  # 70% of total memory
        
        # Estimate memory per sample (rough approximation)
        memory_per_sample = model_size_gb * 4  # Model + gradients + optimizer states
        
        optimal_batch_size = max(1, int(usable_memory / memory_per_sample))
        
        # Clamp to reasonable range
        optimal_batch_size = min(optimal_batch_size, 128)
        optimal_batch_size = max(optimal_batch_size, 1)
        
        logger.info(f"Calculated optimal batch size: {optimal_batch_size}")
        return optimal_batch_size
    
    def enable_mixed_precision(self) -> torch.cuda.amp.GradScaler:
        """Enable mixed precision training optimized for AMD."""
        scaler = torch.cuda.amp.GradScaler(
            init_scale=2.**16,
            growth_factor=2.0,
            backoff_factor=0.5,
            growth_interval=2000,
            enabled=True
        )
        
        logger.info("Mixed precision training enabled for AMD")
        return scaler


class MemoryOptimizer:
    """Advanced memory optimization for large model training."""
    
    def __init__(self, config: Any):
        self.config = config
        self.memory_stats = {}
        
    def optimize_memory_usage(self):
        """Apply comprehensive memory optimizations."""
        # Clear cache
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        # Force garbage collection
        gc.collect()
        
        # Set memory allocation strategy
        if torch.cuda.is_available():
            # Use memory pool for better allocation
            torch.cuda.memory._set_allocator_settings('max_split_size_mb:512')
        
        logger.info("Memory optimization applied")
    
    @contextmanager
    def memory_efficient_context(self):
        """Context manager for memory-efficient operations."""
        # Record initial memory
        initial_memory = self._get_memory_usage()
        
        try:
            # Enable memory efficient mode
            with torch.cuda.amp.autocast(enabled=True):
                yield
        finally:
            # Clean up memory
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            gc.collect()
            
            # Record final memory
            final_memory = self._get_memory_usage()
            memory_saved = initial_memory - final_memory
            
            if memory_saved > 0:
                logger.debug(f"Memory saved: {memory_saved:.2f} GB")
    
    def _get_memory_usage(self) -> float:
        """Get current memory usage in GB."""
        if torch.cuda.is_available():
            return torch.cuda.memory_allocated() / 1024**3
        return 0.0
    
    def monitor_memory_usage(self, step: int):
        """Monitor and log memory usage."""
        if torch.cuda.is_available():
            allocated = torch.cuda.memory_allocated() / 1024**3
            reserved = torch.cuda.memory_reserved() / 1024**3
            max_allocated = torch.cuda.max_memory_allocated() / 1024**3
            
            self.memory_stats[step] = {
                'allocated': allocated,
                'reserved': reserved,
                'max_allocated': max_allocated
            }
            
            # Log warning if memory usage is high
            total_memory = torch.cuda.get_device_properties(0).total_memory / 1024**3
            usage_ratio = allocated / total_memory
            
            if usage_ratio > 0.9:
                logger.warning(f"High memory usage: {usage_ratio:.1%} at step {step}")
    
    def get_memory_summary(self) -> Dict[str, Any]:
        """Get comprehensive memory usage summary."""
        if not torch.cuda.is_available():
            return {'error': 'CUDA not available'}
        
        summary = {
            'current_allocated_gb': torch.cuda.memory_allocated() / 1024**3,
            'current_reserved_gb': torch.cuda.memory_reserved() / 1024**3,
            'max_allocated_gb': torch.cuda.max_memory_allocated() / 1024**3,
            'total_memory_gb': torch.cuda.get_device_properties(0).total_memory / 1024**3
        }
        
        summary['usage_percentage'] = (summary['current_allocated_gb'] / summary['total_memory_gb']) * 100
        
        return summary


class KVCacheOptimizer:
    """Optimize KV cache for efficient inference."""
    
    def __init__(self, config: Any):
        self.config = config
        self.cache_config = self._get_cache_config()
    
    def _get_cache_config(self) -> Dict[str, Any]:
        """Get optimal KV cache configuration."""
        return {
            'cache_implementation': 'flash_attention',
            'max_cache_length': getattr(self.config, 'max_length', 2048),
            'cache_dtype': torch.bfloat16,
            'enable_cache_quantization': True,
            'cache_block_size': 16
        }
    
    def optimize_kv_cache(self, model: nn.Module) -> nn.Module:
        """Apply KV cache optimizations to the model."""
        if hasattr(model, 'config'):
            # Enable KV cache optimizations
            model.config.use_cache = True
            
            # Set optimal cache parameters
            if hasattr(model.config, 'max_position_embeddings'):
                model.config.max_position_embeddings = self.cache_config['max_cache_length']
            
            logger.info("KV cache optimizations applied")
        
        return model
    
    def create_cache_manager(self) -> 'CacheManager':
        """Create a cache manager for efficient memory management."""
        return CacheManager(self.cache_config)


class CacheManager:
    """Manage KV cache efficiently during training and inference."""
    
    def __init__(self, cache_config: Dict[str, Any]):
        self.config = cache_config
        self.cache_blocks = {}
        self.free_blocks = []
        
    def allocate_cache_block(self, batch_size: int, num_heads: int, head_dim: int) -> torch.Tensor:
        """Allocate a cache block."""
        block_size = self.config['cache_block_size']
        cache_shape = (batch_size, num_heads, block_size, head_dim)
        
        # Try to reuse existing block
        if self.free_blocks:
            block = self.free_blocks.pop()
            if block.shape == cache_shape:
                return block
        
        # Allocate new block
        block = torch.zeros(cache_shape, dtype=self.config['cache_dtype'])
        return block
    
    def free_cache_block(self, block: torch.Tensor):
        """Free a cache block for reuse."""
        self.free_blocks.append(block)
    
    def clear_cache(self):
        """Clear all cache blocks."""
        self.cache_blocks.clear()
        self.free_blocks.clear()
        
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


class GradientOptimizer:
    """Optimize gradient computation and accumulation."""
    
    def __init__(self, config: Any):
        self.config = config
        self.gradient_stats = {}
    
    def optimize_gradient_computation(self, model: nn.Module):
        """Apply gradient computation optimizations."""
        # Enable gradient checkpointing
        if hasattr(model, 'gradient_checkpointing_enable'):
            model.gradient_checkpointing_enable()
        
        # Set up gradient clipping
        if hasattr(self.config, 'max_grad_norm') and self.config.max_grad_norm > 0:
            self.max_grad_norm = self.config.max_grad_norm
        else:
            self.max_grad_norm = 1.0
        
        logger.info("Gradient computation optimizations applied")
    
    def clip_gradients(self, model: nn.Module) -> float:
        """Clip gradients and return the gradient norm."""
        grad_norm = torch.nn.utils.clip_grad_norm_(
            model.parameters(), 
            self.max_grad_norm
        )
        return grad_norm.item()
    
    def accumulate_gradients(self, 
                           loss: torch.Tensor, 
                           accumulation_steps: int,
                           current_step: int):
        """Accumulate gradients efficiently."""
        # Scale loss by accumulation steps
        scaled_loss = loss / accumulation_steps
        
        # Backward pass
        scaled_loss.backward()
        
        # Return whether to step optimizer
        return (current_step + 1) % accumulation_steps == 0


class InferenceOptimizer:
    """Optimize model for inference performance."""
    
    def __init__(self, config: Any):
        self.config = config
    
    def optimize_for_inference(self, model: nn.Module) -> nn.Module:
        """Apply inference-specific optimizations."""
        # Set model to evaluation mode
        model.eval()
        
        # Disable gradient computation
        for param in model.parameters():
            param.requires_grad = False
        
        # Enable inference optimizations
        if hasattr(model, 'config'):
            model.config.use_cache = True
        
        # Apply torch.jit optimizations if possible
        try:
            model = torch.jit.optimize_for_inference(model)
            logger.info("TorchScript inference optimizations applied")
        except Exception as e:
            logger.warning(f"Could not apply TorchScript optimizations: {e}")
        
        return model
    
    def enable_speculative_decoding(self, 
                                  main_model: nn.Module,
                                  draft_model: nn.Module) -> 'SpeculativeDecoder':
        """Enable speculative decoding for faster inference."""
        return SpeculativeDecoder(main_model, draft_model, self.config)


class SpeculativeDecoder:
    """Implement speculative decoding for faster inference."""
    
    def __init__(self, 
                 main_model: nn.Module,
                 draft_model: nn.Module,
                 config: Any):
        self.main_model = main_model
        self.draft_model = draft_model
        self.config = config
        
        # Speculative decoding parameters
        self.lookahead_steps = getattr(config, 'lookahead_steps', 4)
        self.acceptance_threshold = getattr(config, 'acceptance_threshold', 0.8)
    
    def generate_with_speculation(self, 
                                input_ids: torch.Tensor,
                                max_length: int,
                                **kwargs) -> torch.Tensor:
        """Generate text using speculative decoding."""
        current_length = input_ids.shape[1]
        
        while current_length < max_length:
            # Generate draft tokens
            draft_tokens = self._generate_draft_tokens(input_ids)
            
            # Verify with main model
            accepted_tokens = self._verify_tokens(input_ids, draft_tokens)
            
            # Update input_ids
            input_ids = torch.cat([input_ids, accepted_tokens], dim=1)
            current_length = input_ids.shape[1]
            
            # Break if no tokens were accepted
            if accepted_tokens.shape[1] == 0:
                break
        
        return input_ids
    
    def _generate_draft_tokens(self, input_ids: torch.Tensor) -> torch.Tensor:
        """Generate draft tokens using the draft model."""
        with torch.no_grad():
            draft_outputs = self.draft_model.generate(
                input_ids,
                max_new_tokens=self.lookahead_steps,
                do_sample=True,
                temperature=0.8,
                pad_token_id=self.draft_model.config.eos_token_id
            )
        
        # Extract only the new tokens
        new_tokens = draft_outputs[:, input_ids.shape[1]:]
        return new_tokens
    
    def _verify_tokens(self, 
                      input_ids: torch.Tensor,
                      draft_tokens: torch.Tensor) -> torch.Tensor:
        """Verify draft tokens using the main model."""
        accepted_tokens = []
        
        for i in range(draft_tokens.shape[1]):
            # Create candidate sequence
            candidate = torch.cat([input_ids, draft_tokens[:, :i+1]], dim=1)
            
            # Get main model probability
            with torch.no_grad():
                outputs = self.main_model(candidate)
                logits = outputs.logits[:, -1, :]
                probs = torch.softmax(logits, dim=-1)
                
                # Check if draft token is acceptable
                draft_token = draft_tokens[:, i]
                token_prob = probs.gather(1, draft_token.unsqueeze(1))
                
                if token_prob.item() > self.acceptance_threshold:
                    accepted_tokens.append(draft_token)
                else:
                    break
        
        if accepted_tokens:
            return torch.stack(accepted_tokens, dim=1)
        else:
            return torch.empty((input_ids.shape[0], 0), dtype=input_ids.dtype, device=input_ids.device)


def create_amd_optimized_config(base_config: Any) -> Any:
    """Create an AMD-optimized configuration."""
    # Clone the base config
    optimized_config = base_config
    
    # Apply AMD-specific optimizations
    optimized_config.use_rocm_optimizations = True
    optimized_config.rocm_memory_fraction = 0.95
    optimized_config.enable_kv_cache_optimization = True
    optimized_config.tf32 = True
    optimized_config.bf16 = True
    optimized_config.gradient_checkpointing = True
    
    # Optimize batch sizes for MI300x
    if hasattr(optimized_config, 'per_device_train_batch_size'):
        optimized_config.per_device_train_batch_size = min(
            optimized_config.per_device_train_batch_size, 64
        )
    
    # Enable advanced optimizations
    optimized_config.dataloader_pin_memory = True
    optimized_config.dataloader_num_workers = 4
    
    return optimized_config

