#!/usr/bin/env python3
"""
Main Inference Script for Enhanced AAIPL

This script provides high-performance inference using AMD MI300x optimizations
including speculative decoding, KV cache optimization, and reasoning-aware
generation for logical reasoning tasks.
"""

import os
import sys
import argparse
import json
import logging
import time
from pathlib import Path
from typing import Dict, List, Any, Optional
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from inference.inference_engine import InferenceEngine, InferenceConfig
from inference.optimization_manager import OptimizationManager, OptimizationConfig

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class EnhancedInferenceSystem:
    """
    Enhanced inference system with AMD MI300x optimizations.
    
    Provides high-performance inference for logical reasoning tasks
    with advanced optimization techniques.
    """
    
    def __init__(self, config_path: str):
        """
        Initialize inference system.
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        
        # Initialize components
        self.model = None
        self.tokenizer = None
        self.inference_engine = None
        self.optimization_manager = None
        
        # Performance tracking
        self.inference_stats = {
            'total_inferences': 0,
            'total_time': 0.0,
            'total_tokens': 0,
            'average_latency': 0.0,
            'average_throughput': 0.0
        }
        
        logger.info("Enhanced Inference System initialized")
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from file."""
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        # Set defaults
        default_config = {
            'model_path': 'Qwen/Qwen2.5-4B',
            'torch_dtype': 'bfloat16',
            'device_map': 'auto',
            'max_new_tokens': 512,
            'temperature': 0.1,
            'top_p': 0.9,
            'top_k': 50,
            'do_sample': True,
            'repetition_penalty': 1.1,
            
            # AMD MI300x optimizations
            'enable_rocm_optimizations': True,
            'enable_flash_attention': True,
            'enable_kv_cache_optimization': True,
            'enable_speculative_decoding': True,
            'enable_batch_processing': True,
            'enable_reasoning_optimization': True,
            
            # Speculative decoding
            'lookahead_steps': 4,
            'acceptance_threshold': 0.8,
            
            # Batch processing
            'max_batch_size': 32,
            'dynamic_batching': True,
            'batch_timeout_ms': 100,
            
            # Performance
            'enable_performance_monitoring': True,
            'log_inference_metrics': True,
            'memory_fraction': 0.95
        }
        
        # Merge with defaults
        for key, value in default_config.items():
            if key not in config:
                config[key] = value
        
        return config
    
    def setup_system(self):
        """Setup the complete inference system."""
        logger.info("Setting up enhanced inference system...")
        
        # Setup optimization manager
        opt_config = OptimizationConfig(
            enable_rocm_optimizations=self.config['enable_rocm_optimizations'],
            enable_memory_optimization=True,
            enable_mixed_precision=True,
            enable_flash_attention=self.config['enable_flash_attention'],
            enable_model_compilation=True
        )
        
        self.optimization_manager = OptimizationManager(opt_config)
        
        # Load model and tokenizer
        self._load_model_and_tokenizer()
        
        # Apply optimizations
        self.model = self.optimization_manager.apply_optimizations(self.model)
        
        # Setup inference engine
        self._setup_inference_engine()
        
        # Start monitoring
        self.optimization_manager.start_monitoring()
        
        logger.info("Enhanced inference system setup completed")
    
    def _load_model_and_tokenizer(self):
        """Load model and tokenizer."""
        logger.info(f"Loading model: {self.config['model_path']}")
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.config['model_path'],
            trust_remote_code=True
        )
        
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Load model
        self.model = AutoModelForCausalLM.from_pretrained(
            self.config['model_path'],
            torch_dtype=getattr(torch, self.config['torch_dtype']),
            device_map=self.config['device_map'],
            trust_remote_code=True,
            attn_implementation="flash_attention_2" if self.config['enable_flash_attention'] else None,
            low_cpu_mem_usage=True,
            use_cache=True
        )
        
        # Set to evaluation mode
        self.model.eval()
        
        logger.info("Model and tokenizer loaded successfully")
    
    def _setup_inference_engine(self):
        """Setup the inference engine."""
        inference_config = InferenceConfig(
            model_path=self.config['model_path'],
            torch_dtype=self.config['torch_dtype'],
            device_map=self.config['device_map'],
            max_new_tokens=self.config['max_new_tokens'],
            temperature=self.config['temperature'],
            top_p=self.config['top_p'],
            top_k=self.config['top_k'],
            do_sample=self.config['do_sample'],
            repetition_penalty=self.config['repetition_penalty'],
            
            # Optimizations
            enable_rocm_optimizations=self.config['enable_rocm_optimizations'],
            enable_flash_attention=self.config['enable_flash_attention'],
            enable_kv_cache_optimization=self.config['enable_kv_cache_optimization'],
            enable_speculative_decoding=self.config['enable_speculative_decoding'],
            enable_batch_processing=self.config['enable_batch_processing'],
            enable_reasoning_optimization=self.config['enable_reasoning_optimization'],
            
            # Speculative decoding
            lookahead_steps=self.config['lookahead_steps'],
            acceptance_threshold=self.config['acceptance_threshold'],
            
            # Batch processing
            max_batch_size=self.config['max_batch_size'],
            dynamic_batching=self.config['dynamic_batching'],
            batch_timeout_ms=self.config['batch_timeout_ms'],
            
            # Performance
            enable_performance_monitoring=self.config['enable_performance_monitoring'],
            log_inference_metrics=self.config['log_inference_metrics'],
            memory_fraction=self.config['memory_fraction']
        )
        
        self.inference_engine = InferenceEngine(inference_config)
        
        logger.info("Inference engine setup completed")
    
    def generate_single(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Generate response for a single prompt.
        
        Args:
            prompt: Input prompt
            **kwargs: Additional generation parameters
            
        Returns:
            Generation result with metrics
        """
        start_time = time.time()
        
        # Generate response
        result = self.inference_engine.generate(prompt, **kwargs)
        
        # Update statistics
        self._update_stats(result, time.time() - start_time)
        
        return {
            'prompt': prompt,
            'generated_text': result.generated_text,
            'input_tokens': result.input_tokens,
            'output_tokens': result.output_tokens,
            'total_time': result.total_time,
            'tokens_per_second': result.tokens_per_second,
            'reasoning_steps': result.reasoning_steps,
            'confidence_score': result.confidence_score,
            'memory_usage': result.memory_usage
        }
    
    def generate_batch(self, prompts: List[str], **kwargs) -> List[Dict[str, Any]]:
        """
        Generate responses for multiple prompts using batch processing.
        
        Args:
            prompts: List of input prompts
            **kwargs: Additional generation parameters
            
        Returns:
            List of generation results
        """
        start_time = time.time()
        
        # Generate batch responses
        results = self.inference_engine.generate_batch(prompts, **kwargs)
        
        # Process results
        batch_results = []
        for i, (prompt, result) in enumerate(zip(prompts, results)):
            batch_result = {
                'prompt': prompt,
                'generated_text': result.generated_text,
                'input_tokens': result.input_tokens,
                'output_tokens': result.output_tokens,
                'total_time': result.total_time,
                'tokens_per_second': result.tokens_per_second,
                'reasoning_steps': result.reasoning_steps,
                'confidence_score': result.confidence_score,
                'batch_size': len(prompts),
                'batch_index': i
            }
            batch_results.append(batch_result)
            
            # Update statistics
            self._update_stats(result, time.time() - start_time)
        
        return batch_results
    
    def interactive_mode(self):
        """Run interactive inference mode."""
        logger.info("Starting interactive mode. Type 'quit' to exit.")
        
        print("Enhanced AAIPL Inference System")
        print("=" * 50)
        print("Enter your logical reasoning questions below.")
        print("Type 'quit' to exit, 'stats' to see performance statistics.")
        print()
        
        while True:
            try:
                # Get user input
                prompt = input("Question: ").strip()
                
                if prompt.lower() == 'quit':
                    break
                elif prompt.lower() == 'stats':
                    self._print_statistics()
                    continue
                elif not prompt:
                    continue
                
                # Generate response
                print("Thinking...")
                result = self.generate_single(prompt)
                
                # Display result
                print(f"\nAnswer: {result['generated_text']}")
                print(f"Confidence: {result['confidence_score']:.3f}")
                print(f"Time: {result['total_time']:.3f}s")
                print(f"Speed: {result['tokens_per_second']:.1f} tokens/sec")
                
                if result['reasoning_steps']:
                    print("\nReasoning Steps:")
                    for i, step in enumerate(result['reasoning_steps'], 1):
                        print(f"  {i}. {step}")
                
                print("-" * 50)
                
            except KeyboardInterrupt:
                print("\nExiting...")
                break
            except Exception as e:
                print(f"Error: {e}")
                continue
    
    def benchmark_performance(self, test_prompts: List[str]) -> Dict[str, Any]:
        """
        Benchmark system performance.
        
        Args:
            test_prompts: List of test prompts
            
        Returns:
            Benchmark results
        """
        logger.info(f"Running performance benchmark with {len(test_prompts)} prompts...")
        
        # Single inference benchmark
        single_times = []
        single_throughputs = []
        
        for prompt in test_prompts[:10]:  # Test first 10 for single inference
            result = self.generate_single(prompt)
            single_times.append(result['total_time'])
            single_throughputs.append(result['tokens_per_second'])
        
        # Batch inference benchmark
        batch_result = self.generate_batch(test_prompts[:32])  # Test batch of 32
        batch_times = [r['total_time'] for r in batch_result]
        batch_throughputs = [r['tokens_per_second'] for r in batch_result]
        
        # System information
        system_info = self.optimization_manager.get_system_info()
        
        benchmark_results = {
            'single_inference': {
                'avg_time_ms': sum(single_times) / len(single_times) * 1000,
                'avg_throughput': sum(single_throughputs) / len(single_throughputs),
                'min_time_ms': min(single_times) * 1000,
                'max_time_ms': max(single_times) * 1000
            },
            'batch_inference': {
                'avg_time_ms': sum(batch_times) / len(batch_times) * 1000,
                'avg_throughput': sum(batch_throughputs) / len(batch_throughputs),
                'batch_size': len(batch_result)
            },
            'system_info': system_info,
            'inference_engine_stats': self.inference_engine.get_performance_stats()
        }
        
        logger.info("Performance benchmark completed")
        return benchmark_results
    
    def _update_stats(self, result, total_time: float):
        """Update inference statistics."""
        self.inference_stats['total_inferences'] += 1
        self.inference_stats['total_time'] += total_time
        self.inference_stats['total_tokens'] += result.output_tokens
        
        # Update averages
        total_inferences = self.inference_stats['total_inferences']
        self.inference_stats['average_latency'] = (
            self.inference_stats['total_time'] / total_inferences
        )
        self.inference_stats['average_throughput'] = (
            self.inference_stats['total_tokens'] / self.inference_stats['total_time']
            if self.inference_stats['total_time'] > 0 else 0
        )
    
    def _print_statistics(self):
        """Print performance statistics."""
        stats = self.get_statistics()
        
        print("\nPerformance Statistics:")
        print("=" * 30)
        print(f"Total inferences: {stats['total_inferences']}")
        print(f"Average latency: {stats['average_latency']*1000:.1f}ms")
        print(f"Average throughput: {stats['average_throughput']:.1f} tokens/sec")
        print(f"Total tokens generated: {stats['total_tokens']}")
        print(f"Total time: {stats['total_time']:.1f}s")
        
        if 'memory_usage' in stats:
            print(f"Memory usage: {stats['memory_usage'].get('allocated_gb', 0):.1f}GB")
        
        print()
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive statistics."""
        stats = self.inference_stats.copy()
        
        # Add engine statistics
        if self.inference_engine:
            engine_stats = self.inference_engine.get_performance_stats()
            stats.update(engine_stats)
        
        # Add system information
        if self.optimization_manager:
            system_info = self.optimization_manager.get_system_info()
            stats['system_info'] = system_info
        
        return stats
    
    def save_statistics(self, output_path: str):
        """Save statistics to file."""
        stats = self.get_statistics()
        
        with open(output_path, 'w') as f:
            json.dump(stats, f, indent=2, default=str)
        
        logger.info(f"Statistics saved to {output_path}")
    
    def cleanup(self):
        """Clean up system resources."""
        if self.optimization_manager:
            self.optimization_manager.cleanup()
        
        if self.inference_engine:
            self.inference_engine.cleanup()
        
        logger.info("System cleanup completed")


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Enhanced AAIPL Inference System")
    parser.add_argument(
        '--config',
        type=str,
        required=True,
        help='Path to configuration file'
    )
    parser.add_argument(
        '--mode',
        type=str,
        choices=['interactive', 'single', 'batch', 'benchmark'],
        default='interactive',
        help='Inference mode'
    )
    parser.add_argument(
        '--prompt',
        type=str,
        help='Single prompt for inference (single mode)'
    )
    parser.add_argument(
        '--prompts-file',
        type=str,
        help='File containing prompts (batch/benchmark mode)'
    )
    parser.add_argument(
        '--output',
        type=str,
        help='Output file for results'
    )
    parser.add_argument(
        '--stats-output',
        type=str,
        help='Output file for statistics'
    )
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug logging'
    )
    
    args = parser.parse_args()
    
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Initialize system
    system = EnhancedInferenceSystem(args.config)
    
    try:
        # Setup system
        system.setup_system()
        
        if args.mode == 'interactive':
            # Interactive mode
            system.interactive_mode()
            
        elif args.mode == 'single':
            # Single inference
            if not args.prompt:
                print("Error: --prompt required for single mode")
                sys.exit(1)
            
            result = system.generate_single(args.prompt)
            
            print(f"Prompt: {result['prompt']}")
            print(f"Answer: {result['generated_text']}")
            print(f"Confidence: {result['confidence_score']:.3f}")
            print(f"Time: {result['total_time']:.3f}s")
            print(f"Speed: {result['tokens_per_second']:.1f} tokens/sec")
            
            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(result, f, indent=2, default=str)
                print(f"Result saved to {args.output}")
            
        elif args.mode == 'batch':
            # Batch inference
            if not args.prompts_file:
                print("Error: --prompts-file required for batch mode")
                sys.exit(1)
            
            # Load prompts
            with open(args.prompts_file, 'r') as f:
                prompts = [line.strip() for line in f if line.strip()]
            
            results = system.generate_batch(prompts)
            
            print(f"Processed {len(results)} prompts")
            print(f"Average time: {sum(r['total_time'] for r in results) / len(results):.3f}s")
            print(f"Average speed: {sum(r['tokens_per_second'] for r in results) / len(results):.1f} tokens/sec")
            
            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(results, f, indent=2, default=str)
                print(f"Results saved to {args.output}")
            
        elif args.mode == 'benchmark':
            # Benchmark mode
            if not args.prompts_file:
                print("Error: --prompts-file required for benchmark mode")
                sys.exit(1)
            
            # Load test prompts
            with open(args.prompts_file, 'r') as f:
                test_prompts = [line.strip() for line in f if line.strip()]
            
            benchmark_results = system.benchmark_performance(test_prompts)
            
            print("Benchmark Results:")
            print("=" * 50)
            print(f"Single inference avg: {benchmark_results['single_inference']['avg_time_ms']:.1f}ms")
            print(f"Single inference throughput: {benchmark_results['single_inference']['avg_throughput']:.1f} tokens/sec")
            print(f"Batch inference avg: {benchmark_results['batch_inference']['avg_time_ms']:.1f}ms")
            print(f"Batch inference throughput: {benchmark_results['batch_inference']['avg_throughput']:.1f} tokens/sec")
            
            if args.output:
                with open(args.output, 'w') as f:
                    json.dump(benchmark_results, f, indent=2, default=str)
                print(f"Benchmark results saved to {args.output}")
        
        # Save statistics if requested
        if args.stats_output:
            system.save_statistics(args.stats_output)
        
    except Exception as e:
        logger.error(f"System error: {e}")
        sys.exit(1)
    
    finally:
        # Cleanup
        system.cleanup()


if __name__ == "__main__":
    main()

