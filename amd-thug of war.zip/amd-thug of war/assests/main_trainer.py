#!/usr/bin/env python3
"""
Main Training Script for Enhanced AAIPL

This script integrates all advanced training methodologies including
synthetic data generation, GRPO/DPO training, curriculum learning,
and self-training for optimal Qwen3-4B performance on logical reasoning tasks.
"""

import os
import sys
import argparse
import json
import logging
from pathlib import Path
from typing import Dict, List, Any, Optional
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

# Add project root to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from data_generation.dataset_builder import DatasetBuilder
from training.grpo_trainer import GRPOTrainer
from training.dpo_trainer import DPOTrainer
from training.curriculum_trainer import CurriculumTrainer
from training.self_training import SelfTrainer
from training.training_config import (
    GRPOConfig, DPOConfig, CurriculumConfig, SelfTrainingConfig
)
from inference.inference_engine import InferenceEngine, InferenceConfig

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('training.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)


class EnhancedTrainingPipeline:
    """
    Enhanced training pipeline that orchestrates all training methodologies.
    
    Integrates synthetic data generation, advanced training methods,
    curriculum learning, and self-training for optimal performance.
    """
    
    def __init__(self, config_path: str):
        """
        Initialize training pipeline.
        
        Args:
            config_path: Path to configuration file
        """
        self.config = self._load_config(config_path)
        self.output_dir = Path(self.config['output_dir'])
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize components
        self.model = None
        self.tokenizer = None
        self.dataset_builder = None
        self.trainers = {}
        self.inference_engine = None
        
        # Training state
        self.training_history = []
        self.best_model_path = None
        self.best_performance = 0.0
        
        logger.info("Enhanced Training Pipeline initialized")
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from file."""
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        # Set defaults
        default_config = {
            'model_name': 'Qwen/Qwen2.5-4B',
            'output_dir': './enhanced_output',
            'max_length': 2048,
            'num_epochs': 3,
            'learning_rate': 1e-5,
            'batch_size': 8,
            'gradient_accumulation_steps': 4,
            'enable_synthetic_data': True,
            'enable_grpo': True,
            'enable_dpo': True,
            'enable_curriculum': True,
            'enable_self_training': True,
            'synthetic_data_size': 10000,
            'curriculum_stages': 4,
            'self_training_iterations': 3,
            'evaluation_strategy': 'steps',
            'eval_steps': 500,
            'save_steps': 1000,
            'logging_steps': 100,
            'warmup_steps': 500,
            'weight_decay': 0.01,
            'adam_epsilon': 1e-8,
            'max_grad_norm': 1.0,
            'fp16': True,
            'dataloader_num_workers': 4,
            'remove_unused_columns': False,
            'load_best_model_at_end': True,
            'metric_for_best_model': 'eval_accuracy',
            'greater_is_better': True,
            'save_total_limit': 3
        }
        
        # Merge with defaults
        for key, value in default_config.items():
            if key not in config:
                config[key] = value
        
        return config
    
    def setup_model_and_tokenizer(self):
        """Setup model and tokenizer."""
        logger.info(f"Loading model: {self.config['model_name']}")
        
        # Load tokenizer
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.config['model_name'],
            trust_remote_code=True
        )
        
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        
        # Load model
        self.model = AutoModelForCausalLM.from_pretrained(
            self.config['model_name'],
            torch_dtype=torch.bfloat16,
            device_map="auto",
            trust_remote_code=True,
            attn_implementation="flash_attention_2"
        )
        
        # Enable gradient checkpointing for memory efficiency
        self.model.gradient_checkpointing_enable()
        
        logger.info("Model and tokenizer loaded successfully")
    
    def generate_synthetic_data(self) -> List[Dict[str, Any]]:
        """Generate synthetic training data."""
        if not self.config['enable_synthetic_data']:
            logger.info("Synthetic data generation disabled")
            return []
        
        logger.info("Generating synthetic training data...")
        
        # Initialize dataset builder
        self.dataset_builder = DatasetBuilder(
            output_dir=str(self.output_dir / "synthetic_data"),
            total_problems=self.config['synthetic_data_size']
        )
        
        # Generate data for all topics
        synthetic_data = self.dataset_builder.build_complete_dataset()
        
        logger.info(f"Generated {len(synthetic_data)} synthetic problems")
        
        # Save synthetic data
        synthetic_data_path = self.output_dir / "synthetic_data.json"
        with open(synthetic_data_path, 'w') as f:
            json.dump(synthetic_data, f, indent=2)
        
        return synthetic_data
    
    def setup_trainers(self):
        """Setup all training components."""
        logger.info("Setting up trainers...")
        
        # GRPO Trainer
        if self.config['enable_grpo']:
            grpo_config = GRPOConfig(
                model_name=self.config['model_name'],
                output_dir=str(self.output_dir / "grpo"),
                num_train_epochs=self.config['num_epochs'],
                per_device_train_batch_size=self.config['batch_size'],
                gradient_accumulation_steps=self.config['gradient_accumulation_steps'],
                learning_rate=self.config['learning_rate'],
                max_length=self.config['max_length'],
                eval_steps=self.config['eval_steps'],
                save_steps=self.config['save_steps'],
                logging_steps=self.config['logging_steps'],
                warmup_steps=self.config['warmup_steps'],
                weight_decay=self.config['weight_decay'],
                fp16=self.config['fp16']
            )
            
            self.trainers['grpo'] = GRPOTrainer(
                config=grpo_config,
                model=self.model,
                tokenizer=self.tokenizer
            )
        
        # DPO Trainer
        if self.config['enable_dpo']:
            dpo_config = DPOConfig(
                model_name=self.config['model_name'],
                output_dir=str(self.output_dir / "dpo"),
                num_train_epochs=self.config['num_epochs'],
                per_device_train_batch_size=self.config['batch_size'],
                gradient_accumulation_steps=self.config['gradient_accumulation_steps'],
                learning_rate=self.config['learning_rate'],
                max_length=self.config['max_length'],
                eval_steps=self.config['eval_steps'],
                save_steps=self.config['save_steps'],
                logging_steps=self.config['logging_steps']
            )
            
            self.trainers['dpo'] = DPOTrainer(
                config=dpo_config,
                model=self.model,
                tokenizer=self.tokenizer
            )
        
        # Curriculum Trainer
        if self.config['enable_curriculum']:
            curriculum_config = CurriculumConfig(
                model_name=self.config['model_name'],
                output_dir=str(self.output_dir / "curriculum"),
                num_stages=self.config['curriculum_stages'],
                stage_epochs=self.config['num_epochs'] // self.config['curriculum_stages'],
                per_device_train_batch_size=self.config['batch_size'],
                learning_rate=self.config['learning_rate'],
                max_length=self.config['max_length']
            )
            
            self.trainers['curriculum'] = CurriculumTrainer(
                config=curriculum_config,
                model=self.model,
                tokenizer=self.tokenizer
            )
        
        # Self-Training
        if self.config['enable_self_training']:
            self_training_config = SelfTrainingConfig(
                model_name=self.config['model_name'],
                output_dir=str(self.output_dir / "self_training"),
                num_iterations=self.config['self_training_iterations'],
                per_device_train_batch_size=self.config['batch_size'],
                learning_rate=self.config['learning_rate'],
                max_length=self.config['max_length']
            )
            
            self.trainers['self_training'] = SelfTrainer(
                config=self_training_config,
                model=self.model,
                tokenizer=self.tokenizer
            )
        
        logger.info(f"Setup {len(self.trainers)} trainers")
    
    def run_training_pipeline(self, training_data: List[Dict[str, Any]]):
        """Run the complete training pipeline."""
        logger.info("Starting enhanced training pipeline...")
        
        current_data = training_data.copy()
        
        # Phase 1: Curriculum Learning (if enabled)
        if 'curriculum' in self.trainers:
            logger.info("Phase 1: Curriculum Learning")
            curriculum_result = self.trainers['curriculum'].train_curriculum(current_data)
            self.training_history.append({
                'phase': 'curriculum',
                'result': curriculum_result
            })
            
            # Update model with best curriculum checkpoint
            if curriculum_result.get('best_model_path'):
                self.model = AutoModelForCausalLM.from_pretrained(
                    curriculum_result['best_model_path'],
                    torch_dtype=torch.bfloat16,
                    device_map="auto"
                )
        
        # Phase 2: GRPO Training (if enabled)
        if 'grpo' in self.trainers:
            logger.info("Phase 2: GRPO Training")
            grpo_result = self.trainers['grpo'].train(current_data)
            self.training_history.append({
                'phase': 'grpo',
                'result': grpo_result
            })
            
            # Update model
            if grpo_result.get('best_model_path'):
                self.model = AutoModelForCausalLM.from_pretrained(
                    grpo_result['best_model_path'],
                    torch_dtype=torch.bfloat16,
                    device_map="auto"
                )
        
        # Phase 3: DPO Training (if enabled)
        if 'dpo' in self.trainers:
            logger.info("Phase 3: DPO Training")
            
            # Create preference pairs for DPO
            preference_data = self._create_preference_pairs(current_data)
            
            dpo_result = self.trainers['dpo'].train(preference_data)
            self.training_history.append({
                'phase': 'dpo',
                'result': dpo_result
            })
            
            # Update model
            if dpo_result.get('best_model_path'):
                self.model = AutoModelForCausalLM.from_pretrained(
                    dpo_result['best_model_path'],
                    torch_dtype=torch.bfloat16,
                    device_map="auto"
                )
        
        # Phase 4: Self-Training (if enabled)
        if 'self_training' in self.trainers:
            logger.info("Phase 4: Self-Training")
            self_training_result = self.trainers['self_training'].train_iteratively(current_data)
            self.training_history.append({
                'phase': 'self_training',
                'result': self_training_result
            })
        
        logger.info("Enhanced training pipeline completed")
    
    def _create_preference_pairs(self, data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Create preference pairs for DPO training."""
        preference_pairs = []
        
        for item in data:
            # Create a preference pair with correct and incorrect answers
            # This is a simplified version - in practice would use more sophisticated methods
            
            correct_answer = item.get('answer', '')
            question = item.get('question', '')
            
            # Generate an incorrect answer (simplified)
            incorrect_answer = self._generate_incorrect_answer(correct_answer)
            
            preference_pair = {
                'prompt': question,
                'chosen': correct_answer,
                'rejected': incorrect_answer
            }
            
            preference_pairs.append(preference_pair)
        
        return preference_pairs
    
    def _generate_incorrect_answer(self, correct_answer: str) -> str:
        """Generate an incorrect answer for preference learning."""
        # Simplified incorrect answer generation
        # In practice, would use more sophisticated methods
        
        if correct_answer.lower() in ['a', 'b', 'c', 'd']:
            # Multiple choice - pick different option
            options = ['a', 'b', 'c', 'd']
            options.remove(correct_answer.lower())
            return options[0].upper()
        
        elif correct_answer.lower() in ['true', 'false']:
            return 'False' if correct_answer.lower() == 'true' else 'True'
        
        else:
            # For other answers, add "not" or modify slightly
            return f"Not {correct_answer}"
    
    def evaluate_model(self, test_data: Optional[List[Dict[str, Any]]] = None) -> Dict[str, float]:
        """Evaluate the trained model."""
        logger.info("Evaluating trained model...")
        
        if test_data is None:
            # Use a subset of training data for evaluation
            test_data = self.training_history[0]['result'].get('eval_data', [])
        
        if not test_data:
            logger.warning("No test data available for evaluation")
            return {}
        
        # Setup inference engine
        inference_config = InferenceConfig(
            model_path=self.config['model_name'],
            max_new_tokens=256,
            temperature=0.1,
            enable_reasoning_optimization=True
        )
        
        self.inference_engine = InferenceEngine(inference_config)
        
        # Evaluate on test data
        correct_predictions = 0
        total_predictions = 0
        
        for item in test_data[:100]:  # Evaluate on first 100 items
            question = item.get('question', '')
            correct_answer = item.get('answer', '')
            
            # Generate prediction
            result = self.inference_engine.generate(question)
            predicted_answer = result.generated_text.strip()
            
            # Simple accuracy check
            if self._answers_match(predicted_answer, correct_answer):
                correct_predictions += 1
            
            total_predictions += 1
        
        accuracy = correct_predictions / total_predictions if total_predictions > 0 else 0.0
        
        evaluation_results = {
            'accuracy': accuracy,
            'correct_predictions': correct_predictions,
            'total_predictions': total_predictions
        }
        
        logger.info(f"Evaluation results: {evaluation_results}")
        
        # Update best model if this is better
        if accuracy > self.best_performance:
            self.best_performance = accuracy
            self.best_model_path = str(self.output_dir / "best_model")
            self.model.save_pretrained(self.best_model_path)
            self.tokenizer.save_pretrained(self.best_model_path)
        
        return evaluation_results
    
    def _answers_match(self, predicted: str, correct: str) -> bool:
        """Check if predicted answer matches correct answer."""
        # Normalize answers for comparison
        pred_norm = predicted.lower().strip()
        correct_norm = correct.lower().strip()
        
        # Direct match
        if pred_norm == correct_norm:
            return True
        
        # Check if correct answer is contained in prediction
        if correct_norm in pred_norm:
            return True
        
        # Check for common answer patterns
        if correct_norm in ['a', 'b', 'c', 'd'] and correct_norm in pred_norm:
            return True
        
        if correct_norm in ['true', 'false'] and correct_norm in pred_norm:
            return True
        
        return False
    
    def save_training_results(self):
        """Save comprehensive training results."""
        results = {
            'config': self.config,
            'training_history': self.training_history,
            'best_model_path': self.best_model_path,
            'best_performance': self.best_performance
        }
        
        results_path = self.output_dir / "training_results.json"
        with open(results_path, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"Training results saved to {results_path}")
    
    def run_complete_pipeline(self):
        """Run the complete enhanced training pipeline."""
        try:
            # Setup
            self.setup_model_and_tokenizer()
            
            # Generate synthetic data
            synthetic_data = self.generate_synthetic_data()
            
            # Setup trainers
            self.setup_trainers()
            
            # Run training
            self.run_training_pipeline(synthetic_data)
            
            # Evaluate
            evaluation_results = self.evaluate_model()
            
            # Save results
            self.save_training_results()
            
            logger.info("Complete enhanced training pipeline finished successfully")
            logger.info(f"Best performance: {self.best_performance:.4f}")
            logger.info(f"Best model saved to: {self.best_model_path}")
            
            return {
                'success': True,
                'best_performance': self.best_performance,
                'best_model_path': self.best_model_path,
                'evaluation_results': evaluation_results
            }
            
        except Exception as e:
            logger.error(f"Training pipeline failed: {e}")
            return {
                'success': False,
                'error': str(e)
            }


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(description="Enhanced AAIPL Training Pipeline")
    parser.add_argument(
        '--config',
        type=str,
        required=True,
        help='Path to configuration file'
    )
    parser.add_argument(
        '--output-dir',
        type=str,
        help='Output directory (overrides config)'
    )
    parser.add_argument(
        '--model-name',
        type=str,
        help='Model name (overrides config)'
    )
    parser.add_argument(
        '--debug',
        action='store_true',
        help='Enable debug logging'
    )
    
    args = parser.parse_args()
    
    if args.debug:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Load and modify config
    with open(args.config, 'r') as f:
        config = json.load(f)
    
    if args.output_dir:
        config['output_dir'] = args.output_dir
    
    if args.model_name:
        config['model_name'] = args.model_name
    
    # Save modified config
    config_path = Path(args.config).parent / "modified_config.json"
    with open(config_path, 'w') as f:
        json.dump(config, f, indent=2)
    
    # Run pipeline
    pipeline = EnhancedTrainingPipeline(str(config_path))
    result = pipeline.run_complete_pipeline()
    
    if result['success']:
        print(f"Training completed successfully!")
        print(f"Best performance: {result['best_performance']:.4f}")
        print(f"Best model: {result['best_model_path']}")
    else:
        print(f"Training failed: {result['error']}")
        sys.exit(1)


if __name__ == "__main__":
    main()

