#!/bin/bash

# Enhanced AAIPL System Setup Script (Root Compatible Version)
# Modified for containerized environments and root access

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Configuration
PYTHON_VERSION="3.9"
ROCM_VERSION="5.7"
PYTORCH_ROCM_VERSION="rocm5.7"
VENV_NAME="enhanced_aaipl"

# System information
log_info "Enhanced AAIPL System Setup (Root Compatible)"
log_info "=============================================="
log_info "Target Hardware: AMD MI300x"
log_info "Python Version: ${PYTHON_VERSION}+"
log_info "ROCm Version: ${ROCM_VERSION}+"
log_info "Running as: $(whoami)"
log_info "=============================================="

# Check if running as root and warn
if [[ $EUID -eq 0 ]]; then
   log_warning "Running as root. This is acceptable in containerized environments."
   log_warning "Please ensure this is a secure environment."
fi

# Function to check command availability
check_command() {
    if command -v "$1" &> /dev/null; then
        log_success "$1 is available"
        return 0
    else
        log_warning "$1 is not available"
        return 1
    fi
}

# Function to check Python version
check_python_version() {
    if command -v python3 &> /dev/null; then
        PYTHON_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
        log_info "Python version: $PYTHON_VER"
        
        if python3 -c "import sys; exit(0 if sys.version_info >= (3, 9) else 1)"; then
            log_success "Python version is compatible"
            return 0
        else
            log_error "Python 3.9+ is required, found $PYTHON_VER"
            return 1
        fi
    else
        log_error "Python3 is not installed"
        return 1
    fi
}

# Function to check GPU availability
check_gpu() {
    log_info "Checking GPU availability..."
    
    if command -v rocm-smi &> /dev/null; then
        log_success "ROCm tools are available"
        rocm-smi --showproductname || log_warning "Could not get GPU information"
    else
        log_warning "ROCm tools not found. Installing ROCm is recommended for AMD GPU support."
    fi
    
    # Check if GPU is accessible
    if python3 -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}'); print(f'Device count: {torch.cuda.device_count()}')" 2>/dev/null; then
        log_success "PyTorch can access GPU"
    else
        log_warning "PyTorch cannot access GPU or PyTorch not installed yet"
    fi
}

# Function to install system dependencies
install_system_dependencies() {
    log_info "Installing system dependencies..."
    
    # Update package list
    apt-get update
    
    # Install essential packages
    apt-get install -y \
        python3-pip \
        python3-venv \
        python3-dev \
        build-essential \
        git \
        curl \
        wget \
        unzip \
        htop \
        tmux \
        vim \
        software-properties-common
    
    # Try to install nvtop (may not be available in all repos)
    apt-get install -y nvtop || log_warning "nvtop not available in repositories"
    
    log_success "System dependencies installed"
}

# Function to setup Python virtual environment (root compatible)
setup_virtual_environment() {
    log_info "Setting up Python virtual environment..."
    
    # Remove existing virtual environment if it exists
    if [ -d "$VENV_NAME" ]; then
        log_warning "Removing existing virtual environment"
        rm -rf "$VENV_NAME"
    fi
    
    # Create new virtual environment
    python3 -m venv "$VENV_NAME"
    
    # Activate virtual environment
    source "$VENV_NAME/bin/activate"
    
    # Upgrade pip
    pip install --upgrade pip setuptools wheel
    
    log_success "Virtual environment created and activated"
}

# Function to install Python dependencies
install_python_dependencies() {
    log_info "Installing Python dependencies..."
    
    # Ensure virtual environment is activated
    if [[ "$VIRTUAL_ENV" == "" ]]; then
        source "$VENV_NAME/bin/activate"
    fi
    
    # Install PyTorch with ROCm support
    log_info "Installing PyTorch with ROCm support..."
    pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/${PYTORCH_ROCM_VERSION}
    
    # Install transformers and related packages
    log_info "Installing Transformers and related packages..."
    pip install transformers>=4.35.0
    pip install accelerate>=0.24.0
    pip install datasets>=2.14.0
    pip install tokenizers>=0.14.0
    
    # Install TRL for advanced training methods
    log_info "Installing TRL for GRPO and DPO..."
    pip install trl>=0.7.0
    
    # Install PEFT for LoRA
    log_info "Installing PEFT for LoRA..."
    pip install peft>=0.6.0
    
    # Install evaluation and monitoring packages
    log_info "Installing evaluation and monitoring packages..."
    pip install wandb
    pip install matplotlib seaborn
    pip install numpy pandas
    pip install scikit-learn
    pip install tqdm
    
    # Install additional utilities
    log_info "Installing additional utilities..."
    pip install pyyaml
    pip install jsonlines
    pip install psutil
    
    # Install development tools
    log_info "Installing development tools..."
    pip install pytest
    pip install black
    pip install flake8
    
    log_success "Python dependencies installed"
}

# Function to verify installation
verify_installation() {
    log_info "Verifying installation..."
    
    # Ensure virtual environment is activated
    if [[ "$VIRTUAL_ENV" == "" ]]; then
        source "$VENV_NAME/bin/activate"
    fi
    
    # Test PyTorch installation
    python3 -c "
import torch
print(f'PyTorch version: {torch.__version__}')
print(f'CUDA available: {torch.cuda.is_available()}')
print(f'Device count: {torch.cuda.device_count()}')
if torch.cuda.is_available():
    print(f'Current device: {torch.cuda.current_device()}')
    print(f'Device name: {torch.cuda.get_device_name()}')
"
    
    # Test transformers
    python3 -c "
import transformers
print(f'Transformers version: {transformers.__version__}')
"
    
    # Test TRL
    python3 -c "
import trl
print(f'TRL version: {trl.__version__}')
"
    
    # Test other packages
    python3 -c "
import peft, datasets, accelerate
print('All core packages imported successfully')
"
    
    log_success "Installation verification completed"
}

# Function to setup ROCm environment variables
setup_rocm_environment() {
    log_info "Setting up ROCm environment variables..."
    
    # Create environment setup script
    cat > setup_env.sh << 'EOF'
#!/bin/bash
# ROCm Environment Variables for Enhanced AAIPL

# Basic ROCm settings
export ROCM_PATH=/opt/rocm
export PATH=$ROCM_PATH/bin:$PATH
export LD_LIBRARY_PATH=$ROCM_PATH/lib:$LD_LIBRARY_PATH

# vLLM ROCm optimizations
export VLLM_USE_TRITON_FLASH_ATTN=0
export VLLM_ROCM_USE_AITER=1
export VLLM_WORKER_MULTIPROC_METHOD=spawn
export SAFETENSORS_FAST_GPU=1

# PyTorch optimizations
export PYTORCH_ROCM_ARCH="gfx942"  # MI300x architecture
export HSA_OVERRIDE_GFX_VERSION=9.4.2

# Memory optimizations
export HIP_VISIBLE_DEVICES=0
export CUDA_VISIBLE_DEVICES=0

# Performance optimizations
export OMP_NUM_THREADS=8
export MKL_NUM_THREADS=8

echo "ROCm environment variables set for Enhanced AAIPL"
EOF
    
    chmod +x setup_env.sh
    
    log_success "ROCm environment setup script created (setup_env.sh)"
    log_info "Run 'source setup_env.sh' before training or inference"
}

# Function to create sample configuration files
create_sample_configs() {
    log_info "Creating sample configuration files..."
    
    # Create configs directory if it doesn't exist
    mkdir -p configs
    
    # Create sample training config
    cat > configs/sample_training_config.json << 'EOF'
{
  "model_name": "google/gemma-2b-it",
  "training_type": "sft",
  "topic": "truth_teller_liar",
  "output_dir": "./checkpoints/sample_training",
  "dataset_file": "./data/sample_dataset.json",
  "num_train_epochs": 2,
  "per_device_train_batch_size": 2,
  "learning_rate": 2e-5,
  "enable_curriculum": true,
  "lora_r": 8,
  "lora_alpha": 16,
  "max_seq_length": 512
}
EOF
    
    # Create sample evaluation config
    cat > configs/sample_evaluation_config.json << 'EOF'
{
  "topics": ["truth_teller_liar"],
  "difficulty_levels": ["easy", "medium"],
  "sample_sizes": [5, 10],
  "output_dir": "./evaluation_results",
  "save_detailed_results": true,
  "generate_plots": false
}
EOF
    
    log_success "Sample configuration files created in configs/"
}

# Function to create sample data
create_sample_data() {
    log_info "Creating sample data files..."
    
    # Create data directory
    mkdir -p data
    
    # Create sample dataset
    cat > data/sample_dataset.json << 'EOF'
[
  {
    "question": "Alice says 'Bob is a truth-teller' and Bob says 'I am a liar'. What are Alice and Bob?",
    "choices": [
      "A) Both truth-tellers",
      "B) Both liars", 
      "C) Alice is truth-teller, Bob is liar",
      "D) Alice is liar, Bob is truth-teller"
    ],
    "answer": "B",
    "reasoning": "If Bob is a truth-teller, then his statement 'I am a liar' would be false, which contradicts him being a truth-teller. So Bob must be a liar. Since Alice says Bob is a truth-teller, and Bob is actually a liar, Alice's statement is false, making Alice a liar too.",
    "topic": "truth_teller_liar",
    "difficulty": "medium"
  },
  {
    "question": "In a village, Charlie says 'I am a truth-teller' and Diana says 'Charlie is a liar'. What are Charlie and Diana?",
    "choices": [
      "A) Both truth-tellers",
      "B) Both liars",
      "C) Charlie is truth-teller, Diana is liar", 
      "D) Charlie is liar, Diana is truth-teller"
    ],
    "answer": "C",
    "reasoning": "If Charlie is a truth-teller, then his statement 'I am a truth-teller' is true, which is consistent. If Charlie is a liar, then his statement would be false, but liars can't make true statements about themselves being truth-tellers. So Charlie must be a truth-teller. Since Diana says Charlie is a liar, and Charlie is actually a truth-teller, Diana's statement is false, making Diana a liar.",
    "topic": "truth_teller_liar", 
    "difficulty": "easy"
  }
]
EOF
    
    log_success "Sample data files created in data/"
}

# Function to create quick test script
create_test_script() {
    log_info "Creating quick test script..."
    
    cat > quick_test.py << 'EOF'
#!/usr/bin/env python3
"""
Quick test script for Enhanced AAIPL System
"""

import json
import sys
from pathlib import Path

def test_imports():
    """Test that all required packages can be imported."""
    print("Testing imports...")
    
    try:
        import torch
        print(f"✓ PyTorch {torch.__version__}")
        print(f"  CUDA available: {torch.cuda.is_available()}")
        print(f"  Device count: {torch.cuda.device_count()}")
    except ImportError as e:
        print(f"✗ PyTorch import failed: {e}")
        return False
    
    try:
        import transformers
        print(f"✓ Transformers {transformers.__version__}")
    except ImportError as e:
        print(f"✗ Transformers import failed: {e}")
        return False
    
    try:
        import trl
        print(f"✓ TRL {trl.__version__}")
    except ImportError as e:
        print(f"✗ TRL import failed: {e}")
        return False
    
    try:
        import peft
        print(f"✓ PEFT {peft.__version__}")
    except ImportError as e:
        print(f"✗ PEFT import failed: {e}")
        return False
    
    return True

def test_agents():
    """Test that enhanced agents can be imported and initialized."""
    print("\nTesting enhanced agents...")
    
    try:
        # Add current directory to path
        sys.path.insert(0, str(Path.cwd()))
        
        from agents.question_agent import EnhancedQuestioningAgent
        from agents.answer_agent import EnhancedAnsweringAgent
        
        print("✓ Enhanced agents imported successfully")
        
        # Test basic initialization
        q_agent = EnhancedQuestioningAgent()
        a_agent = EnhancedAnsweringAgent()
        
        print("✓ Enhanced agents initialized successfully")
        return True
        
    except Exception as e:
        print(f"✗ Enhanced agents test failed: {e}")
        return False

def test_sample_data():
    """Test that sample data exists and is valid."""
    print("\nTesting sample data...")
    
    data_file = Path("data/sample_dataset.json")
    if not data_file.exists():
        print("✗ Sample dataset not found")
        return False
    
    try:
        with open(data_file, 'r') as f:
            data = json.load(f)
        
        print(f"✓ Sample dataset loaded: {len(data)} samples")
        
        # Validate sample structure
        required_fields = ['question', 'choices', 'answer', 'reasoning', 'topic', 'difficulty']
        for i, sample in enumerate(data[:2]):  # Check first 2 samples
            missing_fields = [field for field in required_fields if field not in sample]
            if missing_fields:
                print(f"✗ Sample {i} missing fields: {missing_fields}")
                return False
        
        print("✓ Sample data structure is valid")
        return True
        
    except Exception as e:
        print(f"✗ Sample data test failed: {e}")
        return False

def main():
    """Run all tests."""
    print("Enhanced AAIPL System - Quick Test")
    print("=" * 40)
    
    tests = [
        ("Package Imports", test_imports),
        ("Enhanced Agents", test_agents),
        ("Sample Data", test_sample_data)
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n{test_name}:")
        print("-" * len(test_name))
        
        if test_func():
            passed += 1
            print(f"✓ {test_name} PASSED")
        else:
            print(f"✗ {test_name} FAILED")
    
    print("\n" + "=" * 40)
    print(f"Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! System is ready to use.")
        return 0
    else:
        print("❌ Some tests failed. Please check the installation.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
EOF
    
    chmod +x quick_test.py
    
    log_success "Quick test script created (quick_test.py)"
}

# Function to display usage instructions
display_usage_instructions() {
    log_info "Setup completed! Here's how to get started:"
    echo ""
    echo "1. Activate the virtual environment:"
    echo "   source ${VENV_NAME}/bin/activate"
    echo ""
    echo "2. Set up ROCm environment (for AMD GPU):"
    echo "   source setup_env.sh"
    echo ""
    echo "3. Run quick test:"
    echo "   python quick_test.py"
    echo ""
    echo "4. Generate sample questions:"
    echo "   python -c \"from agents.question_agent import EnhancedQuestioningAgent; agent = EnhancedQuestioningAgent(); questions = agent.generate_questions_batch('truth_teller_liar', 'medium', 5); print(f'Generated {len(questions)} questions')\""
    echo ""
    echo "5. Run comprehensive evaluation:"
    echo "   python utils/evaluation_suite.py --quick_test"
    echo ""
    echo "6. Start training:"
    echo "   python tutorial/enhanced_trainer.py --training_type sft --topic truth_teller_liar --enable_curriculum"
    echo ""
    echo "For more information, see ENHANCED_README.md"
}

# Main setup function
main() {
    log_info "Starting Enhanced AAIPL System setup..."
    
    # Check prerequisites
    log_info "Checking prerequisites..."
    check_command "python3" || { log_error "Python3 is required"; exit 1; }
    check_python_version || { log_error "Python 3.9+ is required"; exit 1; }
    check_command "git" || { log_error "Git is required"; exit 1; }
    
    # Check GPU
    check_gpu
    
    # Install system dependencies
    if [[ "$1" != "--skip-system" ]]; then
        install_system_dependencies
    else
        log_info "Skipping system dependencies installation"
    fi
    
    # Setup virtual environment
    setup_virtual_environment
    
    # Install Python dependencies
    install_python_dependencies
    
    # Verify installation
    verify_installation
    
    # Setup ROCm environment
    setup_rocm_environment
    
    # Create sample files
    create_sample_configs
    create_sample_data
    create_test_script
    
    # Display usage instructions
    display_usage_instructions
    
    log_success "Enhanced AAIPL System setup completed successfully!"
}

# Handle command line arguments
case "${1:-}" in
    --help|-h)
        echo "Enhanced AAIPL System Setup Script (Root Compatible)"
        echo ""
        echo "Usage: $0 [OPTIONS]"
        echo ""
        echo "Options:"
        echo "  --help, -h          Show this help message"
        echo "  --skip-system       Skip system dependencies installation"
        echo "  --quick-test        Run quick test after setup"
        echo ""
        exit 0
        ;;
    --quick-test)
        main "$@"
        log_info "Running quick test..."
        source "${VENV_NAME}/bin/activate"
        python quick_test.py
        ;;
    *)
        main "$@"
        ;;
esac

