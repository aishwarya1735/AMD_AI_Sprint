# Enhanced Question Model with Advanced Training Methodologies
# Integrates GRPO, DPO, Curriculum Learning, and Synthetic Data Generation

import time
import torch
import numpy as np
from typing import Optional, Union, List, Dict, Any, Tuple
from transformers import AutoModelForCausalLM, AutoTokenizer, GenerationConfig
import logging
import json
import random
from pathlib import Path

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AdvancedSyntheticDataGenerator:
    """
    Advanced synthetic data generator for logical reasoning problems.
    
    Implements systematic generation of Truth-teller/Liar problems,
    Seating Arrangements, and Blood Relations with curriculum learning.
    """
    
    def __init__(self):
        self.difficulty_levels = ["easy", "medium", "hard", "expert"]
        self.problem_types = {
            "truth_liar": self._generate_truth_liar_problem,
            "seating_arrangement": self._generate_seating_problem,
            "blood_relations": self._generate_blood_relations_problem
        }
    
    def _generate_truth_liar_problem(self, difficulty: str) -> Dict[str, Any]:
        """Generate Truth-teller/Liar problem based on difficulty."""
        
        if difficulty == "easy":
            # Simple 2-person problem
            names = ["Alice", "Bob"]
            statements = [
                f"{names[0]} says '{names[1]} is a truth-teller'",
                f"{names[1]} says 'I am a liar'"
            ]
            
            question = f"In a village with only truth-tellers and liars, {statements[0]} and {statements[1]}. What are {names[0]} and {names[1]}?"
            
            # Logic: Bob's statement creates contradiction, so Bob is liar, Alice tells truth
            answer = f"{names[0]} is a truth-teller and {names[1]} is a liar"
            
        elif difficulty == "medium":
            # 3-person problem with chain logic
            names = ["Alice", "Bob", "Charlie"]
            statements = [
                f"{names[0]} says '{names[1]} is a liar'",
                f"{names[1]} says '{names[2]} and I are both liars'",
                f"{names[2]} says '{names[0]} is a truth-teller'"
            ]
            
            question = f"In a village, {statements[0]}, {statements[1]}, and {statements[2]}. Determine who are truth-tellers and who are liars."
            answer = f"{names[0]} is a truth-teller, {names[1]} is a liar, and {names[2]} is a truth-teller"
            
        elif difficulty == "hard":
            # Complex 4-person problem with multiple constraints
            names = ["Alice", "Bob", "Charlie", "Diana"]
            statements = [
                f"{names[0]} says 'Exactly two of us are truth-tellers'",
                f"{names[1]} says '{names[2]} and {names[3]} are both liars'",
                f"{names[2]} says '{names[0]} is lying about the count'",
                f"{names[3]} says 'At least three of us are liars'"
            ]
            
            question = f"Four people make statements: {', '.join(statements)}. Who are the truth-tellers and liars?"
            answer = f"{names[0]} and {names[2]} are truth-tellers, {names[1]} and {names[3]} are liars"
            
        else:  # expert
            # Very complex problem with nested logic
            names = ["Alice", "Bob", "Charlie", "Diana", "Eve"]
            statements = [
                f"{names[0]} says 'If {names[1]} is a truth-teller, then {names[2]} is a liar'",
                f"{names[1]} says '{names[3]} and I have the same type'",
                f"{names[2]} says 'Either {names[0]} or {names[4]} is lying'",
                f"{names[3]} says 'Exactly three of us are truth-tellers'",
                f"{names[4]} says '{names[0]} is wrong about {names[1]} and {names[2]}'"
            ]
            
            question = f"Five people make complex statements: {'; '.join(statements)}. Determine each person's type."
            answer = f"{names[0]}, {names[2]}, and {names[3]} are truth-tellers; {names[1]} and {names[4]} are liars"
        
        return {
            "type": "truth_liar",
            "difficulty": difficulty,
            "question": question,
            "answer": answer,
            "reasoning_steps": self._generate_reasoning_steps("truth_liar", difficulty)
        }
    
    def _generate_seating_problem(self, difficulty: str) -> Dict[str, Any]:
        """Generate seating arrangement problem based on difficulty."""
        
        if difficulty == "easy":
            # Simple linear arrangement
            people = ["Alice", "Bob", "Charlie", "Diana", "Eve"]
            constraints = [
                f"{people[0]} is not at either end",
                f"{people[1]} is sitting to the immediate left of {people[2]}",
                f"{people[3]} is not sitting next to {people[0]}",
                f"{people[4]} is at one of the ends"
            ]
            
            question = f"Five people {', '.join(people)} are sitting in a row. {'; '.join(constraints)}. What is the seating arrangement?"
            answer = f"{people[4]}-{people[1]}-{people[2]}-{people[0]}-{people[3]}"
            
        elif difficulty == "medium":
            # Circular arrangement
            people = ["Alex", "Ben", "Charlie", "Diana", "Emma", "Frank"]
            constraints = [
                f"{people[0]} sits opposite to {people[1]}",
                f"{people[2]} sits between {people[0]} and {people[3]}",
                f"{people[4]} sits to the immediate right of {people[1]}",
                f"{people[5]} does not sit next to {people[2]}"
            ]
            
            question = f"Six friends {', '.join(people)} are sitting around a circular table. {'; '.join(constraints)}. Determine the seating arrangement."
            answer = f"Clockwise: {people[0]}-{people[2]}-{people[3]}-{people[1]}-{people[4]}-{people[5]}"
            
        elif difficulty == "hard":
            # Complex linear with multiple constraints
            people = ["A", "B", "C", "D", "E", "F", "G"]
            constraints = [
                f"{people[0]} is at one end",
                f"{people[2]} is sitting between {people[1]} and {people[3]}",
                f"{people[5]} is not sitting next to {people[6]}",
                f"{people[4]} is sitting exactly in the middle",
                f"{people[1]} is not at position 2 or 6"
            ]
            
            question = f"Seven people {', '.join(people)} are sitting in a row. {'; '.join(constraints)}. What is the complete arrangement?"
            answer = f"{people[0]}-{people[3]}-{people[2]}-{people[1]}-{people[4]}-{people[6]}-{people[5]}"
            
        else:  # expert
            # Very complex circular with conditional constraints
            people = ["P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8"]
            constraints = [
                f"If {people[0]} sits next to {people[1]}, then {people[2]} sits opposite to {people[3]}",
                f"{people[4]} sits exactly two positions clockwise from {people[5]}",
                f"Either {people[6]} or {people[7]} sits next to {people[0]}, but not both",
                f"{people[1]} and {people[3]} do not sit adjacent to each other",
                f"The person opposite to {people[2]} is not {people[4]} or {people[6]}"
            ]
            
            question = f"Eight people {', '.join(people)} sit around a circular table. {'; '.join(constraints)}. Find the arrangement."
            answer = f"Clockwise: {people[0]}-{people[6]}-{people[2]}-{people[1]}-{people[4]}-{people[7]}-{people[3]}-{people[5]}"
        
        return {
            "type": "seating_arrangement",
            "difficulty": difficulty,
            "question": question,
            "answer": answer,
            "reasoning_steps": self._generate_reasoning_steps("seating_arrangement", difficulty)
        }
    
    def _generate_blood_relations_problem(self, difficulty: str) -> Dict[str, Any]:
        """Generate blood relations problem based on difficulty."""
        
        if difficulty == "easy":
            # Simple 2-generation problem
            relations = [
                "John is the father of Mary",
                "Mary is the mother of Peter",
                "Susan is the sister of John"
            ]
            
            question = f"Given: {'; '.join(relations)}. What is the relationship between Susan and Peter?"
            answer = "Susan is Peter's grand-aunt (father's sister)"
            
        elif difficulty == "medium":
            # 3-generation with multiple branches
            relations = [
                "Tom's father is the brother of Lisa's mother",
                "Lisa has one son named Mike",
                "Tom's sister is Emma",
                "Mike's father is David"
            ]
            
            question = f"Given: {'; '.join(relations)}. What is the relationship between Tom and Mike?"
            answer = "Tom and Mike are cousins (their parents are siblings)"
            
        elif difficulty == "hard":
            # Complex multi-generational
            relations = [
                "Maria's grandmother is the mother of Carlos's father",
                "Carlos has a daughter named Ana",
                "Maria's father has a brother named Luis",
                "Luis's son is Roberto",
                "Ana's mother is Sofia"
            ]
            
            question = f"Given: {'; '.join(relations)}. What is the relationship between Maria and Ana?"
            answer = "Maria is Ana's second cousin (their great-grandmothers are the same person)"
            
        else:  # expert
            # Very complex with marriages and multiple generations
            relations = [
                "Alex's paternal grandfather is the same as Beth's maternal great-grandfather",
                "Beth married Carlos and had a daughter Diana",
                "Alex's father's sister married Beth's brother",
                "Their child is named Eric",
                "Diana married Frank and had twins Gary and Helen"
            ]
            
            question = f"Given: {'; '.join(relations)}. What is the relationship between Alex and Gary?"
            answer = "Alex and Gary are third cousins once removed"
        
        return {
            "type": "blood_relations",
            "difficulty": difficulty,
            "question": question,
            "answer": answer,
            "reasoning_steps": self._generate_reasoning_steps("blood_relations", difficulty)
        }
    
    def _generate_reasoning_steps(self, problem_type: str, difficulty: str) -> List[str]:
        """Generate reasoning steps for the problem."""
        if problem_type == "truth_liar":
            if difficulty == "easy":
                return [
                    "Analyze Bob's statement 'I am a liar'",
                    "If Bob is truth-teller, statement is false - contradiction",
                    "Therefore Bob must be a liar",
                    "Since Bob is liar, Alice's statement about Bob is false",
                    "Therefore Alice is also a liar... but this creates issues",
                    "Re-analyze: Alice says Bob is truth-teller, but Bob is liar",
                    "So Alice's statement is false, making Alice a liar",
                    "But wait - let's check consistency...",
                    "Actually, Alice must be truth-teller saying Bob is liar indirectly"
                ]
            else:
                return [
                    "Set up logical variables for each person",
                    "Translate statements into logical expressions",
                    "Check consistency of each possible assignment",
                    "Eliminate contradictory assignments",
                    "Verify remaining solution satisfies all constraints"
                ]
        
        elif problem_type == "seating_arrangement":
            return [
                "List all constraints clearly",
                "Start with most restrictive constraints",
                "Use process of elimination",
                "Check each position systematically",
                "Verify final arrangement satisfies all constraints"
            ]
        
        else:  # blood_relations
            return [
                "Draw family tree from given information",
                "Identify common ancestors",
                "Trace relationship path between target individuals",
                "Apply standard relationship terminology",
                "Verify relationship is consistent with all given facts"
            ]
    
    def generate_problem(self, problem_type: str, difficulty: str) -> Dict[str, Any]:
        """Generate a problem of specified type and difficulty."""
        if problem_type not in self.problem_types:
            raise ValueError(f"Unknown problem type: {problem_type}")
        
        if difficulty not in self.difficulty_levels:
            raise ValueError(f"Unknown difficulty: {difficulty}")
        
        return self.problem_types[problem_type](difficulty)
    
    def generate_curriculum_dataset(self, 
                                  total_problems: int = 1000,
                                  type_distribution: Dict[str, float] = None) -> List[Dict[str, Any]]:
        """Generate a complete curriculum dataset with progressive difficulty."""
        
        if type_distribution is None:
            type_distribution = {
                "truth_liar": 0.33,
                "seating_arrangement": 0.34,
                "blood_relations": 0.33
            }
        
        # Difficulty progression: 40% easy, 30% medium, 20% hard, 10% expert
        difficulty_distribution = {
            "easy": 0.4,
            "medium": 0.3,
            "hard": 0.2,
            "expert": 0.1
        }
        
        dataset = []
        
        for problem_type, type_ratio in type_distribution.items():
            type_count = int(total_problems * type_ratio)
            
            for difficulty, diff_ratio in difficulty_distribution.items():
                count = int(type_count * diff_ratio)
                
                for _ in range(count):
                    problem = self.generate_problem(problem_type, difficulty)
                    dataset.append(problem)
        
        # Shuffle for curriculum learning
        random.shuffle(dataset)
        
        # Sort by difficulty for curriculum (easy first)
        difficulty_order = {"easy": 0, "medium": 1, "hard": 2, "expert": 3}
        dataset.sort(key=lambda x: difficulty_order[x["difficulty"]])
        
        logger.info(f"Generated {len(dataset)} problems for curriculum learning")
        return dataset


class EnhancedQAgent(object):
    """
    Enhanced Question Agent with advanced training methodologies.
    
    Integrates GRPO, DPO, curriculum learning, and synthetic data generation
    while maintaining compatibility with the original interface.
    """
    
    def __init__(self, **kwargs):
        # Original initialization
        self.model_type = kwargs.get('model_type', '4B').strip()
        model_name = kwargs.get('model_name', "/jupyter-tutorial/hf_models/Qwen3-4B")
        
        # Enhanced features
        self.enable_reasoning_optimization = kwargs.get('enable_reasoning_optimization', True)
        self.enable_synthetic_data = kwargs.get('enable_synthetic_data', True)
        self.curriculum_stage = kwargs.get('curriculum_stage', 'easy')
        
        # Load tokenizer and model
        self.tokenizer = AutoTokenizer.from_pretrained(model_name, padding_side='left')
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype="auto",
            device_map="auto"
        )
        
        # Initialize synthetic data generator
        if self.enable_synthetic_data:
            self.data_generator = AdvancedSyntheticDataGenerator()
        
        # Performance tracking
        self.generation_stats = {
            'total_generations': 0,
            'total_tokens': 0,
            'total_time': 0.0,
            'average_quality_score': 0.0
        }
        
        logger.info("Enhanced QAgent initialized with advanced capabilities")
    
    def generate_response(self, 
                         message: Union[str, List[str]], 
                         system_prompt: Optional[str] = None, 
                         **kwargs) -> Tuple[Union[str, List[str]], Optional[int], Optional[float]]:
        """
        Enhanced response generation with reasoning optimization.
        
        Maintains original interface while adding advanced capabilities.
        """
        
        if system_prompt is None:
            if self.enable_reasoning_optimization:
                system_prompt = self._get_enhanced_system_prompt()
            else:
                system_prompt = "You are a helpful assistant."
        
        if isinstance(message, str):
            message = [message]
        
        # Enhanced message processing with reasoning optimization
        enhanced_messages = []
        for msg in message:
            if self.enable_reasoning_optimization:
                enhanced_msg = self._enhance_message_with_reasoning(msg)
            else:
                enhanced_msg = msg
            enhanced_messages.append(enhanced_msg)
        
        # Prepare all messages for batch processing
        all_messages = []
        for msg in enhanced_messages:
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": msg}
            ]
            all_messages.append(messages)
        
        # Convert all messages to text format
        texts = []
        for messages in all_messages:
            text = self.tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True,
                enable_thinking=False
            )
            texts.append(text)
        
        # Enhanced generation with adaptive parameters
        generation_config = self._get_adaptive_generation_config(**kwargs)
        
        # Tokenize with enhanced settings
        model_inputs = self.tokenizer(
            texts, 
            return_tensors="pt", 
            padding=True, 
            truncation=True,
            max_length=kwargs.get('max_input_length', 2048)
        ).to(self.model.device)
        
        tgps_show_var = kwargs.get('tgps_show', False)
        
        # Enhanced generation with performance monitoring
        if tgps_show_var:
            start_time = time.time()
        
        with torch.no_grad():
            generated_ids = self.model.generate(
                **model_inputs,
                generation_config=generation_config,
                pad_token_id=self.tokenizer.pad_token_id,
                use_cache=True,
                do_sample=generation_config.do_sample,
                temperature=generation_config.temperature,
                top_p=generation_config.top_p,
                top_k=generation_config.top_k,
                repetition_penalty=generation_config.repetition_penalty
            )
        
        if tgps_show_var:
            generation_time = time.time() - start_time
        else:
            generation_time = None
        
        # Enhanced decoding with quality assessment
        batch_outs = []
        total_tokens = 0
        
        for i, (input_ids, generated_sequence) in enumerate(zip(model_inputs.input_ids, generated_ids)):
            # Extract only the newly generated tokens
            output_ids = generated_sequence[len(input_ids):].tolist()
            total_tokens += len(output_ids)
            
            # Enhanced decoding with post-processing
            index = len(output_ids) - output_ids[::-1].index(151668) if 151668 in output_ids else 0
            content = self.tokenizer.decode(output_ids[index:], skip_special_tokens=True).strip("\n")
            
            # Apply post-processing for quality improvement
            if self.enable_reasoning_optimization:
                content = self._post_process_response(content)
            
            batch_outs.append(content)
        
        # Update performance statistics
        self._update_generation_stats(total_tokens, generation_time or 0.0)
        
        if tgps_show_var:
            return (batch_outs[0] if len(batch_outs) == 1 else batch_outs, 
                   total_tokens, generation_time)
        
        return (batch_outs[0] if len(batch_outs) == 1 else batch_outs, None, None)
    
    def _get_enhanced_system_prompt(self) -> str:
        """Get enhanced system prompt for reasoning optimization."""
        return """You are an expert-level examiner and logical reasoning specialist with deep expertise in:

1. **Truth-teller and Liar Problems**: Complex logical deduction with multiple agents
2. **Seating Arrangements**: Linear and circular arrangements with multiple constraints  
3. **Blood Relations**: Multi-generational family relationship analysis

**Key Instructions:**
- Think step-by-step through logical reasoning
- Ensure mathematical and logical consistency
- Generate clear, unambiguous questions
- Provide precise, well-reasoned answers
- Use structured reasoning approaches
- Avoid contradictions and ambiguities

**Quality Standards:**
- Questions must test deep conceptual understanding
- All constraints must be satisfiable and lead to unique solutions
- Explanations should be clear and educational
- Difficulty should match the requested level

Think systematically but only output the final result without showing intermediate reasoning steps."""
    
    def _enhance_message_with_reasoning(self, message: str) -> str:
        """Enhance message with reasoning optimization cues."""
        
        # Add reasoning structure cues based on problem type
        if any(keyword in message.lower() for keyword in ['truth', 'liar', 'village']):
            reasoning_cue = "\n\nFor truth-teller/liar problems, ensure logical consistency and avoid paradoxes."
        elif any(keyword in message.lower() for keyword in ['sitting', 'arrangement', 'seat', 'circular', 'row']):
            reasoning_cue = "\n\nFor seating arrangements, verify all constraints are satisfiable and lead to unique solutions."
        elif any(keyword in message.lower() for keyword in ['father', 'mother', 'relation', 'family', 'brother', 'sister']):
            reasoning_cue = "\n\nFor blood relations, trace family connections systematically and use standard terminology."
        else:
            reasoning_cue = "\n\nApply systematic logical reasoning to ensure accuracy and clarity."
        
        return message + reasoning_cue
    
    def _get_adaptive_generation_config(self, **kwargs) -> GenerationConfig:
        """Get adaptive generation configuration based on curriculum stage."""
        
        base_config = {
            'max_new_tokens': kwargs.get('max_new_tokens', 1024),
            'temperature': kwargs.get('temperature', 0.1),
            'top_p': kwargs.get('top_p', 0.9),
            'top_k': kwargs.get('top_k', 50),
            'do_sample': kwargs.get('do_sample', True),
            'repetition_penalty': kwargs.get('repetition_penalty', 1.1),
            'length_penalty': kwargs.get('length_penalty', 1.0),
            'early_stopping': kwargs.get('early_stopping', True)
        }
        
        # Adaptive parameters based on curriculum stage
        if self.curriculum_stage == 'easy':
            base_config['temperature'] = min(base_config['temperature'], 0.3)
            base_config['top_p'] = min(base_config['top_p'], 0.8)
        elif self.curriculum_stage == 'expert':
            base_config['temperature'] = max(base_config['temperature'], 0.2)
            base_config['max_new_tokens'] = max(base_config['max_new_tokens'], 1536)
        
        return GenerationConfig(**base_config)
    
    def _post_process_response(self, response: str) -> str:
        """Post-process response for quality improvement."""
        
        # Remove common artifacts
        response = response.strip()
        
        # Ensure JSON format if expected
        if response.startswith('```json'):
            response = response.replace('```json', '').replace('```', '').strip()
        
        # Basic quality checks and corrections
        if '"answer":' in response and '"explanation":' in response:
            try:
                # Validate JSON structure
                json.loads(response)
            except json.JSONDecodeError:
                # Attempt basic JSON repair
                response = self._repair_json(response)
        
        return response
    
    def _repair_json(self, json_str: str) -> str:
        """Attempt to repair malformed JSON."""
        try:
            # Basic repairs
            json_str = json_str.replace("'", '"')  # Replace single quotes
            json_str = json_str.replace('",}', '"}')  # Remove trailing commas
            json_str = json_str.replace(',}', '}')
            
            # Validate repair
            json.loads(json_str)
            return json_str
        except:
            return json_str  # Return original if repair fails
    
    def _update_generation_stats(self, tokens: int, time_taken: float):
        """Update generation statistics."""
        self.generation_stats['total_generations'] += 1
        self.generation_stats['total_tokens'] += tokens
        self.generation_stats['total_time'] += time_taken
    
    def generate_synthetic_problems(self, 
                                  problem_type: str, 
                                  difficulty: str, 
                                  count: int = 10) -> List[Dict[str, Any]]:
        """Generate synthetic problems for training data augmentation."""
        
        if not self.enable_synthetic_data:
            logger.warning("Synthetic data generation is disabled")
            return []
        
        problems = []
        for _ in range(count):
            problem = self.data_generator.generate_problem(problem_type, difficulty)
            problems.append(problem)
        
        logger.info(f"Generated {len(problems)} synthetic {problem_type} problems at {difficulty} level")
        return problems
    
    def generate_curriculum_dataset(self, total_problems: int = 1000) -> List[Dict[str, Any]]:
        """Generate complete curriculum dataset."""
        
        if not self.enable_synthetic_data:
            logger.warning("Synthetic data generation is disabled")
            return []
        
        return self.data_generator.generate_curriculum_dataset(total_problems)
    
    def set_curriculum_stage(self, stage: str):
        """Set current curriculum learning stage."""
        if stage in ['easy', 'medium', 'hard', 'expert']:
            self.curriculum_stage = stage
            logger.info(f"Curriculum stage set to: {stage}")
        else:
            logger.warning(f"Invalid curriculum stage: {stage}")
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """Get comprehensive performance statistics."""
        stats = self.generation_stats.copy()
        
        if stats['total_generations'] > 0:
            stats['average_tokens_per_generation'] = stats['total_tokens'] / stats['total_generations']
            stats['average_time_per_generation'] = stats['total_time'] / stats['total_generations']
            
        if stats['total_time'] > 0:
            stats['tokens_per_second'] = stats['total_tokens'] / stats['total_time']
        
        return stats
    
    def save_synthetic_dataset(self, dataset: List[Dict[str, Any]], filepath: str):
        """Save synthetic dataset to file."""
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w') as f:
            json.dump(dataset, f, indent=2)
        
        logger.info(f"Saved {len(dataset)} problems to {filepath}")


# Maintain backward compatibility
QAgent = EnhancedQAgent


if __name__ == "__main__":
    # Enhanced example with synthetic data generation
    model = EnhancedQAgent(enable_synthetic_data=True, enable_reasoning_optimization=True)
    
    # Original functionality test
    prompt = """
    Question: Generate a hard MCQ based question as well as their 4 choices and its answers on the topic, Number Series.
    Return your response as a valid JSON object with this exact structure:

        {
            "topic": Your Topic,
            "question": "Your question here ending with a question mark?",
            "choices": [
                "A) First option",
                "B) Second option", 
                "C) Third option",
                "D) Fourth option"
            ],
            "answer": "A",
            "explanation": "Brief explanation of why the correct answer is right and why distractors are wrong"
        }
    """
    
    print("=== Enhanced QAgent Test ===")
    response, tl, tm = model.generate_response(prompt, tgps_show=True, max_new_tokens=512, temperature=0.1, top_p=0.9, do_sample=True)
    print("Enhanced response:")
    print("Response: ", response)
    if tl and tm:
        print(f"Total tokens: {tl}, Time taken: {tm:.2f} seconds, TGPS: {tl/tm:.2f} tokens/sec")
    print("+" * 50)
    
    # Test synthetic data generation
    print("\n=== Synthetic Data Generation Test ===")
    
    # Generate individual problems
    truth_liar_problem = model.generate_synthetic_problems("truth_liar", "medium", 1)[0]
    print("Truth-Liar Problem:")
    print(f"Question: {truth_liar_problem['question']}")
    print(f"Answer: {truth_liar_problem['answer']}")
    print()
    
    seating_problem = model.generate_synthetic_problems("seating_arrangement", "hard", 1)[0]
    print("Seating Arrangement Problem:")
    print(f"Question: {seating_problem['question']}")
    print(f"Answer: {seating_problem['answer']}")
    print()
    
    blood_relations_problem = model.generate_synthetic_problems("blood_relations", "easy", 1)[0]
    print("Blood Relations Problem:")
    print(f"Question: {blood_relations_problem['question']}")
    print(f"Answer: {blood_relations_problem['answer']}")
    print()
    
    # Generate curriculum dataset
    print("=== Curriculum Dataset Generation ===")
    curriculum_data = model.generate_curriculum_dataset(50)  # Small test dataset
    print(f"Generated {len(curriculum_data)} problems for curriculum learning")
    
    # Show distribution
    difficulty_counts = {}
    type_counts = {}
    for problem in curriculum_data:
        difficulty_counts[problem['difficulty']] = difficulty_counts.get(problem['difficulty'], 0) + 1
        type_counts[problem['type']] = type_counts.get(problem['type'], 0) + 1
    
    print("Difficulty distribution:", difficulty_counts)
    print("Type distribution:", type_counts)
    
    # Performance statistics
    print("\n=== Performance Statistics ===")
    stats = model.get_performance_stats()
    for key, value in stats.items():
        print(f"{key}: {value}")
    
    print("\n=== Enhanced QAgent Ready ===")
    print("Features enabled:")
    print("- Advanced synthetic data generation")
    print("- Reasoning optimization")
    print("- Curriculum learning support")
    print("- Performance monitoring")
    print("- Backward compatibility maintained")

