#!/bin/bash

# Enhanced AAIPL Evaluation Deployment Script
# Comprehensive evaluation of question generation and answer accuracy

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Logging functions
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Default configuration
EVALUATION_TYPE="comprehensive"
TOPICS="truth_teller_liar"
DIFFICULTIES="medium"
SAMPLE_SIZES="10"
OUTPUT_DIR="./evaluation_results"
MODEL_PATH=""
DATASET_FILE=""
QUICK_TEST=false
GENERATE_PLOTS=true
ENABLE_WANDB=false
GPU_IDS="0"

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --type)
            EVALUATION_TYPE="$2"
            shift 2
            ;;
        --topics)
            TOPICS="$2"
            shift 2
            ;;
        --difficulties)
            DIFFICULTIES="$2"
            shift 2
            ;;
        --sample-sizes)
            SAMPLE_SIZES="$2"
            shift 2
            ;;
        --output-dir)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        --model-path)
            MODEL_PATH="$2"
            shift 2
            ;;
        --dataset)
            DATASET_FILE="$2"
            shift 2
            ;;
        --quick-test)
            QUICK_TEST=true
            shift
            ;;
        --no-plots)
            GENERATE_PLOTS=false
            shift
            ;;
        --wandb)
            ENABLE_WANDB=true
            shift
            ;;
        --gpu-ids)
            GPU_IDS="$2"
            shift 2
            ;;
        --help|-h)
            echo "Enhanced AAIPL Evaluation Script"
            echo ""
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Evaluation Options:"
            echo "  --type TYPE            Evaluation type: comprehensive, question-gen, answer-gen, end-to-end"
            echo "  --topics TOPICS        Space-separated topics (default: truth_teller_liar)"
            echo "  --difficulties DIFFS   Space-separated difficulties (default: medium)"
            echo "  --sample-sizes SIZES   Space-separated sample sizes (default: 10)"
            echo "  --output-dir DIR       Output directory for results"
            echo "  --model-path PATH      Path to trained model checkpoints"
            echo "  --dataset FILE         Dataset file for evaluation"
            echo "  --quick-test           Run quick test with minimal samples"
            echo "  --no-plots             Disable plot generation"
            echo "  --wandb                Enable Weights & Biases logging"
            echo "  --gpu-ids IDS          GPU IDs to use (default: 0)"
            echo ""
            echo "Examples:"
            echo "  $0 --quick-test"
            echo "  $0 --type comprehensive --topics \"truth_teller_liar seating_arrangements\""
            echo "  $0 --type answer-gen --model-path ./checkpoints/sft --dataset ./data/test_set.json"
            echo ""
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Set quick test defaults
if [[ "$QUICK_TEST" == "true" ]]; then
    TOPICS="truth_teller_liar"
    DIFFICULTIES="easy"
    SAMPLE_SIZES="5"
    GENERATE_PLOTS=false
    log_info "Quick test mode enabled"
fi

# Display configuration
log_info "Enhanced AAIPL Evaluation Configuration"
log_info "======================================="
log_info "Evaluation Type: $EVALUATION_TYPE"
log_info "Topics: $TOPICS"
log_info "Difficulties: $DIFFICULTIES"
log_info "Sample Sizes: $SAMPLE_SIZES"
log_info "Output Directory: $OUTPUT_DIR"
log_info "Model Path: ${MODEL_PATH:-'Default models'}"
log_info "Dataset File: ${DATASET_FILE:-'Generated data'}"
log_info "Quick Test: $QUICK_TEST"
log_info "Generate Plots: $GENERATE_PLOTS"
log_info "Weights & Biases: $ENABLE_WANDB"
log_info "GPU IDs: $GPU_IDS"
log_info "======================================="

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if virtual environment is activated
    if [[ "$VIRTUAL_ENV" == "" ]]; then
        log_warning "Virtual environment not activated. Attempting to activate..."
        if [[ -d "enhanced_aaipl" ]]; then
            source enhanced_aaipl/bin/activate
            log_success "Virtual environment activated"
        else
            log_error "Virtual environment not found. Please run setup.sh first."
            exit 1
        fi
    fi
    
    # Check Python packages
    python -c "import torch, transformers, matplotlib, seaborn" || {
        log_error "Required packages not installed. Please run setup.sh first."
        exit 1
    }
    
    # Check evaluation suite
    if [[ ! -f "utils/evaluation_suite.py" ]]; then
        log_error "Evaluation suite not found: utils/evaluation_suite.py"
        exit 1
    fi
    
    # Check model path if provided
    if [[ -n "$MODEL_PATH" ]] && [[ ! -d "$MODEL_PATH" ]]; then
        log_error "Model path not found: $MODEL_PATH"
        exit 1
    fi
    
    # Check dataset file if provided
    if [[ -n "$DATASET_FILE" ]] && [[ ! -f "$DATASET_FILE" ]]; then
        log_error "Dataset file not found: $DATASET_FILE"
        exit 1
    fi
    
    # Check GPU availability
    if ! python -c "import torch; exit(0 if torch.cuda.is_available() else 1)" 2>/dev/null; then
        log_warning "GPU not available. Evaluation will use CPU (slower)."
    else
        GPU_COUNT=$(python -c "import torch; print(torch.cuda.device_count())")
        log_success "GPU available. Device count: $GPU_COUNT"
    fi
    
    log_success "Prerequisites check completed"
}

# Setup environment
setup_environment() {
    log_info "Setting up evaluation environment..."
    
    # Set ROCm environment variables if setup_env.sh exists
    if [[ -f "setup_env.sh" ]]; then
        source setup_env.sh
        log_success "ROCm environment variables loaded"
    fi
    
    # Create output directory
    mkdir -p "$OUTPUT_DIR"
    log_success "Output directory created: $OUTPUT_DIR"
    
    # Set CUDA_VISIBLE_DEVICES
    export CUDA_VISIBLE_DEVICES="$GPU_IDS"
    log_info "Using GPU devices: $GPU_IDS"
    
    # Set evaluation timestamp
    export EVAL_TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    log_info "Evaluation timestamp: $EVAL_TIMESTAMP"
}

# Generate evaluation command
generate_evaluation_command() {
    local cmd="python utils/evaluation_suite.py"
    
    # Convert space-separated strings to arrays for proper argument passing
    local topics_array=($TOPICS)
    local difficulties_array=($DIFFICULTIES)
    local sample_sizes_array=($SAMPLE_SIZES)
    
    # Basic arguments
    cmd="$cmd --output_dir $OUTPUT_DIR"
    
    # Add topics
    if [[ ${#topics_array[@]} -gt 0 ]]; then
        cmd="$cmd --topics ${topics_array[@]}"
    fi
    
    # Add difficulties
    if [[ ${#difficulties_array[@]} -gt 0 ]]; then
        cmd="$cmd --difficulties ${difficulties_array[@]}"
    fi
    
    # Add sample sizes
    if [[ ${#sample_sizes_array[@]} -gt 0 ]]; then
        cmd="$cmd --sample_sizes ${sample_sizes_array[@]}"
    fi
    
    # Optional arguments
    if [[ "$QUICK_TEST" == "true" ]]; then
        cmd="$cmd --quick_test"
    fi
    
    echo "$cmd"
}

# Run question generation evaluation
evaluate_question_generation() {
    log_info "Running question generation evaluation..."
    
    python -c "
import sys
sys.path.append('.')
from agents.question_agent import EnhancedQuestioningAgent
from utils.evaluation_suite import EnhancedEvaluationSuite
import json
import time

# Setup evaluator
evaluator = EnhancedEvaluationSuite()
evaluator.setup_agents()

topics = '$TOPICS'.split()
difficulties = '$DIFFICULTIES'.split()
sample_sizes = [int(x) for x in '$SAMPLE_SIZES'.split()]

results = {}
for topic in topics:
    results[topic] = {}
    for difficulty in difficulties:
        results[topic][difficulty] = {}
        for sample_size in sample_sizes:
            print(f'Evaluating {topic}, {difficulty}, {sample_size} samples...')
            result = evaluator.evaluate_question_generation(topic, difficulty, sample_size)
            results[topic][difficulty][sample_size] = result

# Save results
timestamp = time.strftime('%Y%m%d_%H%M%S')
output_file = f'$OUTPUT_DIR/question_generation_results_{timestamp}.json'
with open(output_file, 'w') as f:
    json.dump(results, f, indent=2)

print(f'Question generation evaluation completed. Results saved to {output_file}')
"
    
    log_success "Question generation evaluation completed"
}

# Run answer generation evaluation
evaluate_answer_generation() {
    log_info "Running answer generation evaluation..."
    
    local dataset_arg=""
    if [[ -n "$DATASET_FILE" ]]; then
        dataset_arg="--dataset $DATASET_FILE"
    fi
    
    local model_arg=""
    if [[ -n "$MODEL_PATH" ]]; then
        model_arg="--model-path $MODEL_PATH"
    fi
    
    python -c "
import sys
sys.path.append('.')
from agents.answer_agent import EnhancedAnsweringAgent
from utils.evaluation_suite import EnhancedEvaluationSuite
import json
import time

# Load test questions
dataset_file = '$DATASET_FILE' if '$DATASET_FILE' else 'data/sample_dataset.json'
try:
    with open(dataset_file, 'r') as f:
        questions = json.load(f)
    print(f'Loaded {len(questions)} questions from {dataset_file}')
except FileNotFoundError:
    print(f'Dataset file not found: {dataset_file}. Using sample questions.')
    questions = [
        {
            'question': 'Alice says Bob is a liar and Bob says I am telling the truth. What are Alice and Bob?',
            'choices': ['A) Both truth-tellers', 'B) Both liars', 'C) Alice truth-teller, Bob liar', 'D) Alice liar, Bob truth-teller'],
            'answer': 'C',
            'topic': 'truth_teller_liar'
        }
    ]

# Setup evaluator
evaluator = EnhancedEvaluationSuite()
evaluator.setup_agents()

# Run evaluation
topics = '$TOPICS'.split()
for topic in topics:
    topic_questions = [q for q in questions if q.get('topic') == topic][:int('$SAMPLE_SIZES'.split()[0])]
    
    if topic_questions:
        print(f'Evaluating {len(topic_questions)} {topic} questions...')
        result = evaluator.evaluate_answer_generation(topic_questions, topic)
        
        # Save results
        timestamp = time.strftime('%Y%m%d_%H%M%S')
        output_file = f'$OUTPUT_DIR/answer_generation_results_{topic}_{timestamp}.json'
        with open(output_file, 'w') as f:
            json.dump(result, f, indent=2)
        
        print(f'Answer generation evaluation for {topic} completed. Results saved to {output_file}')
    else:
        print(f'No questions found for topic: {topic}')

print('Answer generation evaluation completed')
"
    
    log_success "Answer generation evaluation completed"
}

# Run comprehensive evaluation
evaluate_comprehensive() {
    log_info "Running comprehensive evaluation..."
    
    local eval_cmd=$(generate_evaluation_command)
    log_info "Evaluation command: $eval_cmd"
    
    # Create evaluation config file
    local config_file="$OUTPUT_DIR/evaluation_config_${EVAL_TIMESTAMP}.json"
    cat > "$config_file" << EOF
{
    "topics": [$(echo "$TOPICS" | sed 's/ /", "/g' | sed 's/^/"/; s/$/"/')],
    "difficulty_levels": [$(echo "$DIFFICULTIES" | sed 's/ /", "/g' | sed 's/^/"/; s/$/"/')],
    "sample_sizes": [$(echo "$SAMPLE_SIZES" | sed 's/ /, /g')],
    "output_dir": "$OUTPUT_DIR",
    "save_detailed_results": true,
    "generate_plots": $GENERATE_PLOTS,
    "log_level": "INFO"
}
EOF
    
    # Run evaluation with config
    eval "$eval_cmd --config $config_file" || {
        log_error "Comprehensive evaluation failed"
        return 1
    }
    
    log_success "Comprehensive evaluation completed"
}

# Generate performance report
generate_performance_report() {
    log_info "Generating performance report..."
    
    python -c "
import json
import glob
import os
from pathlib import Path
import time

output_dir = '$OUTPUT_DIR'
timestamp = '$EVAL_TIMESTAMP'

# Find result files
result_files = glob.glob(f'{output_dir}/*results*.json')
if not result_files:
    print('No result files found')
    exit(1)

# Aggregate results
all_results = {}
for file_path in result_files:
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)
            filename = os.path.basename(file_path)
            all_results[filename] = data
    except Exception as e:
        print(f'Error loading {file_path}: {e}')

# Generate report
report_lines = []
report_lines.append('# Enhanced AAIPL Evaluation Report')
report_lines.append(f'Generated on: {time.strftime(\"%Y-%m-%d %H:%M:%S\")}')
report_lines.append(f'Evaluation ID: {timestamp}')
report_lines.append('')

# Summary statistics
report_lines.append('## Summary')
report_lines.append(f'- Total result files: {len(result_files)}')
report_lines.append(f'- Topics evaluated: $TOPICS')
report_lines.append(f'- Difficulties tested: $DIFFICULTIES')
report_lines.append(f'- Sample sizes: $SAMPLE_SIZES')
report_lines.append('')

# Detailed results
for filename, results in all_results.items():
    report_lines.append(f'## {filename}')
    
    if isinstance(results, dict):
        for key, value in results.items():
            if isinstance(value, (int, float)):
                if isinstance(value, float):
                    report_lines.append(f'- {key}: {value:.3f}')
                else:
                    report_lines.append(f'- {key}: {value}')
            elif isinstance(value, dict):
                report_lines.append(f'- {key}:')
                for sub_key, sub_value in value.items():
                    if isinstance(sub_value, (int, float)):
                        if isinstance(sub_value, float):
                            report_lines.append(f'  - {sub_key}: {sub_value:.3f}')
                        else:
                            report_lines.append(f'  - {sub_key}: {sub_value}')
    
    report_lines.append('')

# Save report
report_file = f'{output_dir}/performance_report_{timestamp}.md'
with open(report_file, 'w') as f:
    f.write('\\n'.join(report_lines))

print(f'Performance report generated: {report_file}')
"
    
    log_success "Performance report generated"
}

# Create evaluation summary
create_evaluation_summary() {
    local start_time=$1
    local end_time=$2
    local duration=$((end_time - start_time))
    
    log_info "Creating evaluation summary..."
    
    cat > "$OUTPUT_DIR/evaluation_summary_${EVAL_TIMESTAMP}.md" << EOF
# Evaluation Summary

## Configuration
- **Evaluation Type**: $EVALUATION_TYPE
- **Topics**: $TOPICS
- **Difficulties**: $DIFFICULTIES
- **Sample Sizes**: $SAMPLE_SIZES
- **Model Path**: ${MODEL_PATH:-'Default models'}
- **Dataset File**: ${DATASET_FILE:-'Generated data'}
- **Evaluation Duration**: ${duration} seconds ($(($duration / 60)) minutes)
- **Start Time**: $(date -d @$start_time)
- **End Time**: $(date -d @$end_time)

## Environment
- **GPU IDs**: $GPU_IDS
- **Output Directory**: $OUTPUT_DIR
- **Generate Plots**: $GENERATE_PLOTS
- **Weights & Biases**: $ENABLE_WANDB

## Results
- **Result Files**: $(ls -1 $OUTPUT_DIR/*results*.json 2>/dev/null | wc -l) files created
- **Total Output Size**: $(du -sh $OUTPUT_DIR | cut -f1)

## Files Generated
$(ls -la $OUTPUT_DIR | grep -E '\.(json|md|png)$' | awk '{print "- " $9 " (" $5 " bytes)"}')

## Next Steps
1. Review detailed results in JSON files
2. Check performance report for insights
3. Compare with baseline metrics
4. Consider model improvements based on findings

## Commands Used
\`\`\`bash
# Evaluation command
$0 --type $EVALUATION_TYPE --topics "$TOPICS" --difficulties "$DIFFICULTIES" --sample-sizes "$SAMPLE_SIZES"
\`\`\`
EOF
    
    log_success "Evaluation summary created: $OUTPUT_DIR/evaluation_summary_${EVAL_TIMESTAMP}.md"
}

# Main evaluation function
main() {
    local start_time=$(date +%s)
    
    log_info "Starting Enhanced AAIPL Evaluation..."
    
    # Check prerequisites
    check_prerequisites
    
    # Setup environment
    setup_environment
    
    # Run evaluation based on type
    case $EVALUATION_TYPE in
        comprehensive)
            evaluate_comprehensive
            ;;
        question-gen)
            evaluate_question_generation
            ;;
        answer-gen)
            evaluate_answer_generation
            ;;
        end-to-end)
            evaluate_question_generation
            evaluate_answer_generation
            ;;
        *)
            log_error "Invalid evaluation type: $EVALUATION_TYPE"
            exit 1
            ;;
    esac
    
    local end_time=$(date +%s)
    
    # Generate performance report
    generate_performance_report
    
    # Create evaluation summary
    create_evaluation_summary $start_time $end_time
    
    log_success "Enhanced AAIPL Evaluation completed successfully!"
    log_info "Evaluation duration: $((end_time - start_time)) seconds"
    log_info "Results saved to: $OUTPUT_DIR"
    log_info "Summary: $OUTPUT_DIR/evaluation_summary_${EVAL_TIMESTAMP}.md"
    
    # Show quick results summary
    if [[ -f "$OUTPUT_DIR/performance_report_${EVAL_TIMESTAMP}.md" ]]; then
        log_info "Performance report preview:"
        head -n 20 "$OUTPUT_DIR/performance_report_${EVAL_TIMESTAMP}.md"
    fi
}

# Run main function
main "$@"

