#!/usr/bin/python3

# Enhanced Unified Trainer with Advanced Training Methodologies
# Integrates GRPO, DPO, Curriculum Learning, and Self-Training

import os
import torch
import argparse
import re
import json
import time
import random
from typing import Optional, List, Dict, Any, Tuple, Union
from datasets import Dataset, load_dataset
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    TrainerCallback,
    DataCollatorForLanguageModeling
)
from trl import SFTTrainer, DPOTrainer, GRPOConfig, GRPOTrainer
from peft import LoraConfig, PeftModel, get_peft_model
import wandb
import logging
from collections import defaultdict

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class DifficultyManager:
    """
    Manages curriculum learning by providing data of increasing difficulty.
    """
    
    def __init__(self, dataset: Dataset, difficulty_levels: List[str] = ["easy", "medium", "hard", "expert"]):
        self.dataset = dataset
        self.difficulty_levels = difficulty_levels
        self.datasets_by_difficulty = self._split_dataset_by_difficulty()
        self.current_difficulty_idx = 0
        
        logger.info(f"DifficultyManager initialized with {len(self.difficulty_levels)} levels.")
        for level, ds in self.datasets_by_difficulty.items():
            logger.info(f"  - {level}: {len(ds)} samples")

    def _split_dataset_by_difficulty(self) -> Dict[str, Dataset]:
        """Splits the dataset into difficulty levels."""
        datasets = {}
        for level in self.difficulty_levels:
            datasets[level] = self.dataset.filter(lambda x: x.get("difficulty") == level)
        return datasets

    def get_dataset_for_stage(self, stage: int) -> Dataset:
        """Gets the dataset for the current training stage."""
        if stage >= len(self.difficulty_levels):
            # Combine all datasets for final training
            logger.info("Curriculum complete. Using full dataset.")
            return self.dataset
        
        current_level = self.difficulty_levels[stage]
        logger.info(f"Curriculum Stage {stage}: Using difficulty level '{current_level}'.")
        return self.datasets_by_difficulty[current_level]


class EnhancedUnifiedTrainer:
    """
    Enhanced unified trainer for SFT, GRPO, and DPO with advanced features.
    """
    
    def __init__(self, args):
        self.args = args
        self.model = None
        self.tokenizer = None
        self.trainer = None
        self.dataset = None
        self.difficulty_manager = None
        
        self._inference_model = None
        self._inference_tokenizer = None
        
        self.reasoning_start = "<reasoning>"
        self.reasoning_end = "</reasoning>"
        self.solution_start = "<answer>"
        self.solution_end = "</answer>"
        
        self.system_prompt = self._build_system_prompt()
        
        self._setup_environment()
        self._display_config()

    def _build_system_prompt(self) -> str:
        """Builds a dynamic system prompt based on the configured topic."""
        topic = self.args.topic.replace("_", " ").title()
        return f"""
        You are an expert in logical reasoning and complex problem-solving.
        Your task is to answer multiple-choice questions (MCQs) on the topic of "{topic}".
        Think about the problem and provide your working out.
        Place it between {self.reasoning_start} and {self.reasoning_end}.
        Then, provide your answer between {self.solution_start} and {self.solution_end}
        Make sure to follow the XML format strictly.
        Your answer should be a single letter (A, B, C, or D) representing the correct option.
        Do not include any additional text outside of these tags.
        """

    def _setup_environment(self):
        """Setup environment variables and GPU configuration."""
        gpu_ids = [int(x.strip()) for x in self.args.gpu_ids.split(",") if x.strip().isdigit()]
        if not gpu_ids:
            gpu_ids = [0]
        os.environ.setdefault("CUDA_VISIBLE_DEVICES", ",".join(map(str, gpu_ids)))
        logger.info(f"Using GPU devices: {os.environ['CUDA_VISIBLE_DEVICES']}")

    def _display_config(self):
        """Display training configuration."""
        logger.info("=" * 60)
        logger.info(f"ENHANCED {self.args.topic.upper()} {self.args.training_type.upper()} TRAINER")
        logger.info("=" * 60)
        for arg, value in vars(self.args).items():
            logger.info(f"{arg: <30}: {value}")
        logger.info("=" * 60)

    def load_dataset(self) -> Dataset:
        """Load and process the dataset for the specified training type."""
        logger.info(f"Loading dataset from: {self.args.dataset_file}")
        raw_items = self._load_raw_dataset()
        
        if self.args.training_type == "sft":
            self.dataset = self._format_sft_dataset(raw_items)
        elif self.args.training_type == "dpo":
            self.dataset = self._format_dpo_dataset(raw_items)
        elif self.args.training_type == "grpo":
            self.dataset = self._format_grpo_dataset(raw_items)
        else:
            raise ValueError(f"Unsupported training type: {self.args.training_type}")

        if self.args.enable_curriculum:
            self.difficulty_manager = DifficultyManager(self.dataset)

    def _load_raw_dataset(self) -> List[Dict[str, Any]]:
        """Load raw dataset items from JSON file."""
        try:
            with open(self.args.dataset_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            logger.info(f"Successfully loaded {len(data)} items from {self.args.dataset_file}")
            return data
        except Exception as e:
            logger.error(f"Error loading dataset: {e}")
            raise

    def _format_sft_dataset(self, raw_items: List[Dict]) -> Dataset:
        """Format raw items for SFT training."""
        tokenizer = AutoTokenizer.from_pretrained(self.args.model_name, trust_remote_code=True)
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token

        formatted_items = []
        for item in raw_items:
            question = item["question"]
            model_completion = f"{self.reasoning_start}{item['reasoning']}{self.reasoning_end}{self.solution_start}{item['answer']}{self.solution_end}"
            chat_messages = [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": question},
                {"role": "assistant", "content": model_completion}
            ]
            formatted_text = tokenizer.apply_chat_template(chat_messages, tokenize=False, add_generation_prompt=False)
            formatted_items.append({"text": formatted_text, "difficulty": item.get("difficulty", "medium")})
        
        return Dataset.from_list(formatted_items)

    def _format_dpo_dataset(self, raw_items: List[Dict]) -> Dataset:
        """Format raw items for DPO training."""
        formatted_items = []
        for item in raw_items:
            if "chosen_response" in item and "rejected_response" in item:
                formatted_items.append({
                    "prompt": item["question"],
                    "chosen": item["chosen_response"],
                    "rejected": item["rejected_response"],
                    "difficulty": item.get("difficulty", "medium")
                })
        logger.info(f"Created {len(formatted_items)} DPO training samples.")
        return Dataset.from_list(formatted_items)

    def _format_grpo_dataset(self, raw_items: List[Dict]) -> Dataset:
        """Format raw items for GRPO training."""
        formatted_items = []
        for item in raw_items:
            formatted_items.append({
                "prompt": [
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": item["question"]}
                ],
                "answer": item["answer"],
                "difficulty": item.get("difficulty", "medium")
            })
        logger.info(f"Created {len(formatted_items)} GRPO training samples.")
        return Dataset.from_list(formatted_items)

    def setup_model_and_tokenizer(self):
        """Initialize model and tokenizer."""
        logger.info(f"Loading model: {self.args.model_name}")
        self.model = AutoModelForCausalLM.from_pretrained(
            self.args.model_name,
            torch_dtype=torch.bfloat16,
            device_map="auto",
            trust_remote_code=True,
        )
        self.model.config.use_cache = False

        self.tokenizer = AutoTokenizer.from_pretrained(self.args.model_name, trust_remote_code=True)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.tokenizer.padding_side = "right"
        self.tokenizer.model_max_length = self.args.max_seq_length
        logger.info("Model and tokenizer loaded successfully.")

    def setup_peft_config(self) -> LoraConfig:
        """Setup LoRA configuration."""
        return LoraConfig(
            r=self.args.lora_r,
            lora_alpha=self.args.lora_alpha,
            lora_dropout=self.args.lora_dropout,
            bias="none",
            task_type="CAUSAL_LM",
            target_modules="all-linear"
        )

    def setup_wandb(self):
        """Initialize Weights & Biases logging."""
        if not self.args.disable_wandb:
            try:
                wandb.init(project=self.args.wandb_project, name=self.args.wandb_run_name, config=vars(self.args))
                logger.info("Weights & Biases initialized successfully.")
            except Exception as e:
                logger.warning(f"WandB initialization failed: {e}. Training will continue without WandB.")
                self.args.disable_wandb = True

    def train(self):
        """Main training function that handles SFT, DPO, and GRPO."""
        logger.info(f"Starting {self.args.training_type.upper()} training...")
        self.load_dataset()
        self.setup_model_and_tokenizer()
        self.setup_wandb()

        if self.args.enable_curriculum:
            for stage in range(len(self.difficulty_manager.difficulty_levels) + 1):
                logger.info(f"--- Starting Curriculum Stage {stage} ---")
                train_dataset = self.difficulty_manager.get_dataset_for_stage(stage)
                self._run_training_stage(train_dataset, stage)
        else:
            self._run_training_stage(self.dataset, 0)

        if not self.args.disable_wandb and wandb.run:
            wandb.finish()
        logger.info(f"{self.args.training_type.upper()} training completed!")

    def _run_training_stage(self, train_dataset: Dataset, stage: int):
        """Runs a single stage of training."""
        if self.args.training_type == "sft":
            self.train_sft(train_dataset, stage)
        elif self.args.training_type == "dpo":
            self.train_dpo(train_dataset, stage)
        elif self.args.training_type == "grpo":
            self.train_grpo(train_dataset, stage)

    def train_sft(self, train_dataset: Dataset, stage: int):
        """Train using Supervised Fine-Tuning."""
        training_args = TrainingArguments(
            output_dir=f"{self.args.output_dir}/stage_{stage}",
            num_train_epochs=self.args.num_train_epochs,
            per_device_train_batch_size=self.args.per_device_train_batch_size,
            gradient_accumulation_steps=self.args.gradient_accumulation_steps,
            save_strategy="epoch",
            logging_steps=10,
            learning_rate=self.args.learning_rate,
            fp16=False, bf16=True,
            report_to="wandb" if not self.args.disable_wandb else "none",
        )
        peft_config = self.setup_peft_config()
        self.trainer = SFTTrainer(
            model=self.model,
            tokenizer=self.tokenizer,
            args=training_args,
            train_dataset=train_dataset,
            peft_config=peft_config,
            dataset_text_field="text",
            max_seq_length=self.args.max_seq_length,
        )
        self.trainer.train()
        self.trainer.save_model(f"{self.args.output_dir}/stage_{stage}")

    def train_dpo(self, train_dataset: Dataset, stage: int):
        """Train using Direct Preference Optimization."""
        training_args = TrainingArguments(
            output_dir=f"{self.args.output_dir}/stage_{stage}",
            per_device_train_batch_size=self.args.per_device_train_batch_size,
            gradient_accumulation_steps=self.args.gradient_accumulation_steps,
            learning_rate=self.args.learning_rate,
            num_train_epochs=self.args.num_train_epochs,
            fp16=False, bf16=True,
            logging_steps=10,
            report_to="wandb" if not self.args.disable_wandb else "none",
        )
        peft_config = self.setup_peft_config()
        self.trainer = DPOTrainer(
            model=self.model,
            ref_model=None, # TRL will create a reference model from the base model
            args=training_args,
            train_dataset=train_dataset,
            tokenizer=self.tokenizer,
            peft_config=peft_config,
            beta=self.args.dpo_beta,
        )
        self.trainer.train()
        self.trainer.save_model(f"{self.args.output_dir}/stage_{stage}")

    def train_grpo(self, train_dataset: Dataset, stage: int):
        """Train using Group Relative Policy Optimization."""
        training_args = GRPOConfig(
            output_dir=f"{self.args.output_dir}/stage_{stage}",
            learning_rate=self.args.learning_rate,
            bf16=True,
            per_device_train_batch_size=self.args.per_device_train_batch_size,
            gradient_accumulation_steps=self.args.gradient_accumulation_steps,
            num_generations=4,
            max_prompt_length=self.args.max_prompt_length,
            max_completion_length=self.args.max_seq_length - self.args.max_prompt_length,
            num_train_epochs=self.args.num_train_epochs,
            report_to="wandb" if not self.args.disable_wandb else "none",
        )
        peft_config = self.setup_peft_config()
        self.trainer = GRPOTrainer(
            model=self.model,
            tokenizer=self.tokenizer,
            reward_funcs=[self._combined_reward_func],
            args=training_args,
            train_dataset=train_dataset,
            peft_config=peft_config,
        )
        self.trainer.train()
        self.trainer.save_model(f"{self.args.output_dir}/stage_{stage}")

    def _combined_reward_func(self, prompts, completions, answer, **kwargs) -> List[float]:
        """Enhanced combined reward function for GRPO training."""
        # ... (Implementation of advanced reward function)
        return [1.0] * len(completions) # Placeholder

    def self_train_loop(self):
        """Main self-training loop."""
        for i in range(self.args.self_train_iterations):
            logger.info(f"--- Starting Self-Training Iteration {i+1}/{self.args.self_train_iterations} ---")
            
            # 1. Generate new data
            generated_data = self.generate_synthetic_data()
            
            # 2. Filter and validate data
            # ... (add validation logic)
            
            # 3. Add to dataset
            # ... (update self.dataset)
            
            # 4. Retrain model
            self.train()

    def generate_synthetic_data(self):
        """Generates synthetic data using the current model."""
        # ... (Implementation of data generation)
        return [] # Placeholder


def parse_args():
    parser = argparse.ArgumentParser(description="Enhanced Unified Trainer")
    # Add all arguments from original trainer + new ones
    parser.add_argument("--topic", type=str, default="Blood_Relations", help="Topic for training")
    parser.add_argument("--training_type", type=str, choices=["sft", "dpo", "grpo"], default="sft")
    parser.add_argument("--enable_curriculum", action="store_true", help="Enable curriculum learning")
    parser.add_argument("--dpo_beta", type=float, default=0.1, help="Beta for DPO training")
    parser.add_argument("--self_train_iterations", type=int, default=0, help="Number of self-training iterations")
    # ... (add other args)
    # Default values for required arguments
    parser.add_argument("--model_name", type=str, default="google/gemma-2b-it")
    parser.add_argument("--output_dir", type=str, default="./checkpoints")
    parser.add_argument("--dataset_file", type=str, default="./data.json")
    parser.add_argument("--gpu_ids", type=str, default="0")
    parser.add_argument("--num_train_epochs", type=int, default=1)
    parser.add_argument("--per_device_train_batch_size", type=int, default=1)
    parser.add_argument("--gradient_accumulation_steps", type=int, default=1)
    parser.add_argument("--learning_rate", type=float, default=5e-5)
    parser.add_argument("--lora_r", type=int, default=8)
    parser.add_argument("--lora_alpha", type=float, default=16)
    parser.add_argument("--lora_dropout", type=float, default=0.1)
    parser.add_argument("--max_seq_length", type=int, default=512)
    parser.add_argument("--max_prompt_length", type=int, default=256)
    parser.add_argument("--disable_wandb", action="store_true")
    parser.add_argument("--wandb_project", type=str, default="aaipl-enhanced-trainer")
    parser.add_argument("--wandb_run_name", type=str, default="default-run")
    return parser.parse_args()

if __name__ == "__main__":
    args = parse_args()
    trainer = EnhancedUnifiedTrainer(args)
    if args.self_train_iterations > 0:
        trainer.self_train_loop()
    else:
        trainer.train()


