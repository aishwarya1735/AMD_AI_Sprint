#!/bin/bash

# Enhanced AAIPL Training Deployment Script
# Supports SFT, GRPO, DPO training with curriculum learning

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Logging functions
log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# Default configuration
TRAINING_TYPE="sft"
TOPIC="truth_teller_liar"
MODEL_NAME="google/gemma-2b-it"
OUTPUT_DIR="./checkpoints"
DATASET_FILE="./data/sample_dataset.json"
NUM_EPOCHS=3
BATCH_SIZE=2
LEARNING_RATE=2e-5
ENABLE_CURRICULUM=false
ENABLE_WANDB=true
GPU_IDS="0"
LORA_R=8
LORA_ALPHA=16

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        --training-type)
            TRAINING_TYPE="$2"
            shift 2
            ;;
        --topic)
            TOPIC="$2"
            shift 2
            ;;
        --model)
            MODEL_NAME="$2"
            shift 2
            ;;
        --output-dir)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        --dataset)
            DATASET_FILE="$2"
            shift 2
            ;;
        --epochs)
            NUM_EPOCHS="$2"
            shift 2
            ;;
        --batch-size)
            BATCH_SIZE="$2"
            shift 2
            ;;
        --learning-rate)
            LEARNING_RATE="$2"
            shift 2
            ;;
        --curriculum)
            ENABLE_CURRICULUM=true
            shift
            ;;
        --no-wandb)
            ENABLE_WANDB=false
            shift
            ;;
        --gpu-ids)
            GPU_IDS="$2"
            shift 2
            ;;
        --lora-r)
            LORA_R="$2"
            shift 2
            ;;
        --lora-alpha)
            LORA_ALPHA="$2"
            shift 2
            ;;
        --help|-h)
            echo "Enhanced AAIPL Training Script"
            echo ""
            echo "Usage: $0 [OPTIONS]"
            echo ""
            echo "Training Options:"
            echo "  --training-type TYPE    Training method: sft, grpo, dpo (default: sft)"
            echo "  --topic TOPIC          Topic: truth_teller_liar, seating_arrangements, blood_relations"
            echo "  --model MODEL          Model name or path (default: google/gemma-2b-it)"
            echo "  --output-dir DIR       Output directory for checkpoints"
            echo "  --dataset FILE         Dataset file path"
            echo "  --epochs N             Number of training epochs (default: 3)"
            echo "  --batch-size N         Per-device batch size (default: 2)"
            echo "  --learning-rate LR     Learning rate (default: 2e-5)"
            echo "  --curriculum           Enable curriculum learning"
            echo "  --no-wandb             Disable Weights & Biases logging"
            echo "  --gpu-ids IDS          GPU IDs to use (default: 0)"
            echo "  --lora-r R             LoRA rank (default: 8)"
            echo "  --lora-alpha ALPHA     LoRA alpha (default: 16)"
            echo ""
            echo "Examples:"
            echo "  $0 --training-type sft --topic truth_teller_liar --curriculum"
            echo "  $0 --training-type grpo --topic seating_arrangements --epochs 2"
            echo "  $0 --training-type dpo --topic blood_relations --batch-size 1"
            echo ""
            exit 0
            ;;
        *)
            log_error "Unknown option: $1"
            exit 1
            ;;
    esac
done

# Validate training type
case $TRAINING_TYPE in
    sft|grpo|dpo)
        ;;
    *)
        log_error "Invalid training type: $TRAINING_TYPE. Must be one of: sft, grpo, dpo"
        exit 1
        ;;
esac

# Validate topic
case $TOPIC in
    truth_teller_liar|seating_arrangements|blood_relations)
        ;;
    *)
        log_error "Invalid topic: $TOPIC. Must be one of: truth_teller_liar, seating_arrangements, blood_relations"
        exit 1
        ;;
esac

# Display configuration
log_info "Enhanced AAIPL Training Configuration"
log_info "====================================="
log_info "Training Type: $TRAINING_TYPE"
log_info "Topic: $TOPIC"
log_info "Model: $MODEL_NAME"
log_info "Output Directory: $OUTPUT_DIR"
log_info "Dataset: $DATASET_FILE"
log_info "Epochs: $NUM_EPOCHS"
log_info "Batch Size: $BATCH_SIZE"
log_info "Learning Rate: $LEARNING_RATE"
log_info "Curriculum Learning: $ENABLE_CURRICULUM"
log_info "Weights & Biases: $ENABLE_WANDB"
log_info "GPU IDs: $GPU_IDS"
log_info "LoRA Rank: $LORA_R"
log_info "LoRA Alpha: $LORA_ALPHA"
log_info "====================================="

# Check prerequisites
check_prerequisites() {
    log_info "Checking prerequisites..."
    
    # Check if virtual environment is activated
    if [[ "$VIRTUAL_ENV" == "" ]]; then
        log_warning "Virtual environment not activated. Attempting to activate..."
        if [[ -d "enhanced_aaipl" ]]; then
            source enhanced_aaipl/bin/activate
            log_success "Virtual environment activated"
        else
            log_error "Virtual environment not found. Please run setup.sh first."
            exit 1
        fi
    fi
    
    # Check Python packages
    python -c "import torch, transformers, trl, peft" || {
        log_error "Required packages not installed. Please run setup.sh first."
        exit 1
    }
    
    # Check dataset file
    if [[ ! -f "$DATASET_FILE" ]]; then
        log_error "Dataset file not found: $DATASET_FILE"
        exit 1
    fi
    
    # Check GPU availability
    if ! python -c "import torch; exit(0 if torch.cuda.is_available() else 1)" 2>/dev/null; then
        log_warning "GPU not available. Training will use CPU (much slower)."
    else
        GPU_COUNT=$(python -c "import torch; print(torch.cuda.device_count())")
        log_success "GPU available. Device count: $GPU_COUNT"
    fi
    
    log_success "Prerequisites check completed"
}

# Setup environment
setup_environment() {
    log_info "Setting up training environment..."
    
    # Set ROCm environment variables if setup_env.sh exists
    if [[ -f "setup_env.sh" ]]; then
        source setup_env.sh
        log_success "ROCm environment variables loaded"
    fi
    
    # Create output directory
    mkdir -p "$OUTPUT_DIR"
    log_success "Output directory created: $OUTPUT_DIR"
    
    # Set CUDA_VISIBLE_DEVICES
    export CUDA_VISIBLE_DEVICES="$GPU_IDS"
    log_info "Using GPU devices: $GPU_IDS"
}

# Generate training command
generate_training_command() {
    local cmd="python tutorial/enhanced_trainer.py"
    
    # Basic arguments
    cmd="$cmd --training_type $TRAINING_TYPE"
    cmd="$cmd --topic $TOPIC"
    cmd="$cmd --model_name $MODEL_NAME"
    cmd="$cmd --output_dir $OUTPUT_DIR"
    cmd="$cmd --dataset_file $DATASET_FILE"
    cmd="$cmd --num_train_epochs $NUM_EPOCHS"
    cmd="$cmd --per_device_train_batch_size $BATCH_SIZE"
    cmd="$cmd --learning_rate $LEARNING_RATE"
    cmd="$cmd --gpu_ids $GPU_IDS"
    cmd="$cmd --lora_r $LORA_R"
    cmd="$cmd --lora_alpha $LORA_ALPHA"
    
    # Optional arguments
    if [[ "$ENABLE_CURRICULUM" == "true" ]]; then
        cmd="$cmd --enable_curriculum"
    fi
    
    if [[ "$ENABLE_WANDB" == "false" ]]; then
        cmd="$cmd --disable_wandb"
    fi
    
    # Training-specific arguments
    case $TRAINING_TYPE in
        grpo)
            cmd="$cmd --gradient_accumulation_steps 4"
            cmd="$cmd --max_prompt_length 512"
            cmd="$cmd --vllm_gpu_memory_utilization 0.8"
            ;;
        dpo)
            cmd="$cmd --dpo_beta 0.1"
            cmd="$cmd --gradient_accumulation_steps 4"
            ;;
        sft)
            cmd="$cmd --gradient_accumulation_steps 2"
            ;;
    esac
    
    echo "$cmd"
}

# Monitor training progress
monitor_training() {
    local pid=$1
    local log_file="$OUTPUT_DIR/training.log"
    
    log_info "Monitoring training progress (PID: $pid)"
    log_info "Log file: $log_file"
    
    # Monitor GPU usage if available
    if command -v nvidia-smi &> /dev/null; then
        log_info "GPU monitoring available (nvidia-smi)"
    elif command -v rocm-smi &> /dev/null; then
        log_info "GPU monitoring available (rocm-smi)"
    fi
    
    # Wait for training to complete
    while kill -0 $pid 2>/dev/null; do
        sleep 30
        
        # Show recent log entries
        if [[ -f "$log_file" ]]; then
            echo "--- Recent Training Log ---"
            tail -n 5 "$log_file" 2>/dev/null || echo "No recent log entries"
            echo "-------------------------"
        fi
        
        # Show GPU usage
        if command -v nvidia-smi &> /dev/null; then
            echo "--- GPU Usage ---"
            nvidia-smi --query-gpu=utilization.gpu,memory.used,memory.total --format=csv,noheader,nounits 2>/dev/null || echo "GPU info unavailable"
            echo "----------------"
        elif command -v rocm-smi &> /dev/null; then
            echo "--- GPU Usage ---"
            rocm-smi --showuse 2>/dev/null || echo "GPU info unavailable"
            echo "----------------"
        fi
    done
    
    # Check if training completed successfully
    wait $pid
    local exit_code=$?
    
    if [[ $exit_code -eq 0 ]]; then
        log_success "Training completed successfully"
    else
        log_error "Training failed with exit code: $exit_code"
        return $exit_code
    fi
}

# Validate training results
validate_results() {
    log_info "Validating training results..."
    
    # Check if checkpoints were created
    if [[ -d "$OUTPUT_DIR" ]] && [[ -n "$(ls -A $OUTPUT_DIR 2>/dev/null)" ]]; then
        log_success "Training checkpoints found in $OUTPUT_DIR"
        
        # List checkpoint contents
        echo "Checkpoint contents:"
        ls -la "$OUTPUT_DIR"
        
        # Check for specific files
        if [[ -f "$OUTPUT_DIR/adapter_config.json" ]]; then
            log_success "LoRA adapter configuration found"
        fi
        
        if [[ -f "$OUTPUT_DIR/adapter_model.safetensors" ]] || [[ -f "$OUTPUT_DIR/adapter_model.bin" ]]; then
            log_success "LoRA adapter weights found"
        fi
        
        if [[ -f "$OUTPUT_DIR/tokenizer_config.json" ]]; then
            log_success "Tokenizer configuration found"
        fi
        
    else
        log_error "No training checkpoints found"
        return 1
    fi
    
    # Test model loading
    log_info "Testing model loading..."
    python -c "
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
from peft import PeftModel
import sys

try:
    # Load base model
    base_model = AutoModelForCausalLM.from_pretrained(
        '$MODEL_NAME',
        torch_dtype=torch.bfloat16,
        device_map='auto',
        trust_remote_code=True
    )
    
    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained('$MODEL_NAME', trust_remote_code=True)
    
    # Load LoRA adapter
    model = PeftModel.from_pretrained(base_model, '$OUTPUT_DIR')
    
    print('✓ Model and adapter loaded successfully')
    
    # Test generation
    test_prompt = 'Alice says Bob is a liar. What can we conclude?'
    inputs = tokenizer(test_prompt, return_tensors='pt')
    
    with torch.no_grad():
        outputs = model.generate(**inputs, max_new_tokens=50, do_sample=False)
    
    response = tokenizer.decode(outputs[0], skip_special_tokens=True)
    print(f'✓ Test generation successful: {len(response)} characters')
    
except Exception as e:
    print(f'✗ Model validation failed: {e}')
    sys.exit(1)
" || {
        log_error "Model validation failed"
        return 1
    }
    
    log_success "Training results validation completed"
}

# Create training summary
create_summary() {
    local start_time=$1
    local end_time=$2
    local duration=$((end_time - start_time))
    
    log_info "Creating training summary..."
    
    cat > "$OUTPUT_DIR/training_summary.md" << EOF
# Training Summary

## Configuration
- **Training Type**: $TRAINING_TYPE
- **Topic**: $TOPIC
- **Model**: $MODEL_NAME
- **Dataset**: $DATASET_FILE
- **Output Directory**: $OUTPUT_DIR
- **Training Duration**: ${duration} seconds ($(($duration / 60)) minutes)
- **Start Time**: $(date -d @$start_time)
- **End Time**: $(date -d @$end_time)

## Parameters
- **Epochs**: $NUM_EPOCHS
- **Batch Size**: $BATCH_SIZE
- **Learning Rate**: $LEARNING_RATE
- **Curriculum Learning**: $ENABLE_CURRICULUM
- **LoRA Rank**: $LORA_R
- **LoRA Alpha**: $LORA_ALPHA
- **GPU IDs**: $GPU_IDS

## Results
- **Checkpoints**: $(ls -1 $OUTPUT_DIR | wc -l) files created
- **Model Size**: $(du -sh $OUTPUT_DIR | cut -f1)

## Next Steps
1. Evaluate the trained model:
   \`\`\`bash
   python utils/evaluation_suite.py --model-path $OUTPUT_DIR
   \`\`\`

2. Run inference:
   \`\`\`bash
   python tutorial/enhanced_trainer.py --mode inference --output_dir $OUTPUT_DIR
   \`\`\`

3. Continue training with more data or different parameters
EOF
    
    log_success "Training summary created: $OUTPUT_DIR/training_summary.md"
}

# Main training function
main() {
    local start_time=$(date +%s)
    
    log_info "Starting Enhanced AAIPL Training..."
    
    # Check prerequisites
    check_prerequisites
    
    # Setup environment
    setup_environment
    
    # Generate training command
    local training_cmd=$(generate_training_command)
    log_info "Training command: $training_cmd"
    
    # Create log file
    local log_file="$OUTPUT_DIR/training.log"
    mkdir -p "$(dirname "$log_file")"
    
    # Start training
    log_info "Starting training process..."
    echo "Training started at $(date)" > "$log_file"
    echo "Command: $training_cmd" >> "$log_file"
    echo "----------------------------------------" >> "$log_file"
    
    # Run training with logging
    eval "$training_cmd" 2>&1 | tee -a "$log_file" &
    local training_pid=$!
    
    # Monitor training
    monitor_training $training_pid || {
        log_error "Training failed"
        exit 1
    }
    
    local end_time=$(date +%s)
    
    # Validate results
    validate_results || {
        log_error "Training validation failed"
        exit 1
    }
    
    # Create summary
    create_summary $start_time $end_time
    
    log_success "Enhanced AAIPL Training completed successfully!"
    log_info "Training duration: $((end_time - start_time)) seconds"
    log_info "Checkpoints saved to: $OUTPUT_DIR"
    log_info "Training log: $log_file"
    log_info "Training summary: $OUTPUT_DIR/training_summary.md"
}

# Run main function
main "$@"

