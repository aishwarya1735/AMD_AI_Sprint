#!/usr/bin/python3

# Enhanced Prompt Building Utilities
# Advanced prompt engineering for logical reasoning tasks

import json
import random
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class EnhancedPromptBuilder:
    """
    Enhanced prompt builder with topic-specific optimization and reasoning strategies.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        self.config = self._load_config(config_path)
        self.topic_strategies = self._initialize_topic_strategies()
        self.few_shot_examples = self._load_few_shot_examples()
        
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """Load configuration from file or use defaults."""
        if config_path and Path(config_path).exists():
            with open(config_path, 'r') as f:
                return json.load(f)
        
        # Default configuration
        return {
            "enable_few_shot": True,
            "few_shot_count": 3,
            "enable_chain_of_thought": True,
            "enable_step_by_step": True,
            "reasoning_style": "systematic",
            "max_reasoning_steps": 10
        }
    
    def _initialize_topic_strategies(self) -> Dict[str, Dict[str, Any]]:
        """Initialize topic-specific reasoning strategies."""
        return {
            "truth_teller_liar": {
                "approach": "logical_deduction",
                "key_concepts": ["truth-teller", "liar", "consistency", "contradiction"],
                "reasoning_steps": [
                    "Identify the characters and their statements",
                    "Assume each character type and check for consistency",
                    "Look for contradictions in statements",
                    "Determine the logical conclusion"
                ],
                "common_patterns": [
                    "If X says Y is a liar, then X and Y are different types",
                    "If X says 'I am a liar', this creates a paradox",
                    "Truth-tellers always tell the truth, liars always lie"
                ]
            },
            
            "seating_arrangements": {
                "approach": "constraint_satisfaction",
                "key_concepts": ["position", "relative_position", "constraints", "arrangement"],
                "reasoning_steps": [
                    "List all people and constraints",
                    "Identify fixed positions if any",
                    "Apply constraints systematically",
                    "Check for conflicts and resolve",
                    "Verify the final arrangement"
                ],
                "common_patterns": [
                    "Linear arrangements: left-right relationships",
                    "Circular arrangements: clockwise-counterclockwise",
                    "Adjacent means next to each other",
                    "Opposite means across from each other"
                ]
            },
            
            "blood_relations": {
                "approach": "relationship_mapping",
                "key_concepts": ["family_tree", "generation", "direct_relation", "indirect_relation"],
                "reasoning_steps": [
                    "Identify all mentioned people",
                    "Map direct relationships",
                    "Trace the connection path",
                    "Determine the final relationship"
                ],
                "common_patterns": [
                    "Parent's sibling is aunt/uncle",
                    "Sibling's child is nephew/niece",
                    "Parent's parent is grandparent",
                    "Two generations up/down changes relationship type"
                ]
            }
        }
    
    def _load_few_shot_examples(self) -> Dict[str, List[Dict[str, str]]]:
        """Load few-shot examples for each topic."""
        return {
            "truth_teller_liar": [
                {
                    "question": "Alice says 'Bob is a truth-teller' and Bob says 'I am a liar'. What are Alice and Bob?",
                    "reasoning": "If Bob is a truth-teller, then his statement 'I am a liar' would be false, which contradicts him being a truth-teller. So Bob must be a liar. Since Alice says Bob is a truth-teller, and Bob is actually a liar, Alice's statement is false, making Alice a liar too.",
                    "answer": "Both are liars"
                }
            ],
            
            "seating_arrangements": [
                {
                    "question": "Five people A, B, C, D, E sit in a row. A sits two seats to the left of E. B sits immediately to the right of A. Where does C sit relative to D?",
                    "reasoning": "If A sits two seats left of E, possible positions are A-X-E or A-X-X-E. Since B sits immediately right of A, we have A-B-E or A-B-X-E. With 5 people total, the arrangement must be A-B-C-D-E or A-B-D-C-E. Checking constraints, A-B-C-D-E works.",
                    "answer": "C sits immediately to the left of D"
                }
            ],
            
            "blood_relations": [
                {
                    "question": "A is B's father. B is C's mother. What is A to C?",
                    "reasoning": "A is B's father means A is male and one generation above B. B is C's mother means B is female and one generation above C. Therefore, A is two generations above C and is male, making A the grandfather of C.",
                    "answer": "Grandfather"
                }
            ]
        }
    
    def build_system_prompt(self, topic: str, difficulty: str = "medium") -> str:
        """Build topic-specific system prompt with reasoning guidance."""
        
        topic_key = topic.lower().replace(" ", "_")
        strategy = self.topic_strategies.get(topic_key, {})
        
        base_prompt = f"""You are an expert in logical reasoning and problem-solving, specializing in {topic.replace('_', ' ').title()} problems.

Your task is to solve multiple-choice questions with systematic reasoning and provide the correct answer.

**Problem-Solving Approach:**
{strategy.get('approach', 'systematic_analysis').replace('_', ' ').title()}

**Key Concepts to Consider:**
{', '.join(strategy.get('key_concepts', ['logic', 'reasoning', 'analysis']))}

**Reasoning Process:**"""
        
        # Add reasoning steps
        if 'reasoning_steps' in strategy:
            for i, step in enumerate(strategy['reasoning_steps'], 1):
                base_prompt += f"\n{i}. {step}"
        
        # Add common patterns
        if 'common_patterns' in strategy:
            base_prompt += f"\n\n**Important Patterns:**"
            for pattern in strategy['common_patterns']:
                base_prompt += f"\n• {pattern}"
        
        # Add difficulty-specific guidance
        difficulty_guidance = self._get_difficulty_guidance(difficulty)
        base_prompt += f"\n\n**Difficulty Level: {difficulty.title()}**\n{difficulty_guidance}"
        
        # Add output format requirements
        base_prompt += """

**Output Format:**
Provide your response as a valid JSON object with exactly these fields:
{
    "answer": "Single letter A, B, C, or D",
    "reasoning": "Clear step-by-step explanation (50-150 words)"
}

**Quality Requirements:**
• Use systematic logical reasoning, not guessing
• Explain each step of your analysis clearly
• Verify your answer against all given conditions
• Ensure reasoning is complete but concise
• Double-check for logical consistency"""
        
        return base_prompt
    
    def _get_difficulty_guidance(self, difficulty: str) -> str:
        """Get difficulty-specific guidance."""
        guidance = {
            "easy": "Focus on direct relationships and simple logical steps. Problems typically involve 2-4 entities with clear constraints.",
            "medium": "Consider multiple constraints and indirect relationships. May require 3-5 reasoning steps with some complexity.",
            "hard": "Handle complex scenarios with multiple entities and intricate relationships. Requires careful systematic analysis.",
            "expert": "Solve highly complex problems with many entities, multiple constraint types, and potential edge cases. Requires advanced logical reasoning."
        }
        return guidance.get(difficulty, guidance["medium"])
    
    def build_question_prompt(self, 
                            question_data: Dict[str, Any], 
                            topic: str,
                            include_few_shot: bool = True,
                            reasoning_style: str = "step_by_step") -> str:
        """Build complete question prompt with few-shot examples and reasoning guidance."""
        
        prompt_parts = []
        
        # Add few-shot examples if enabled
        if include_few_shot and self.config.get("enable_few_shot", True):
            few_shot_examples = self._get_few_shot_examples(topic)
            if few_shot_examples:
                prompt_parts.append("**Example Problems:**\n")
                for i, example in enumerate(few_shot_examples, 1):
                    prompt_parts.append(f"Example {i}:")
                    prompt_parts.append(f"Question: {example['question']}")
                    prompt_parts.append(f"Reasoning: {example['reasoning']}")
                    prompt_parts.append(f"Answer: {example['answer']}\n")
        
        # Add reasoning guidance
        if reasoning_style == "step_by_step":
            prompt_parts.append(self._build_step_by_step_guidance(topic))
        elif reasoning_style == "chain_of_thought":
            prompt_parts.append(self._build_chain_of_thought_guidance(topic))
        
        # Add the actual question
        prompt_parts.append("**Problem to Solve:**")
        prompt_parts.append(f"Question: {question_data['question']}")
        
        # Format choices
        if 'choices' in question_data:
            choices_text = self._format_choices(question_data['choices'])
            prompt_parts.append(f"Choices: {choices_text}")
        
        # Add final instructions
        prompt_parts.append("\n**Instructions:**")
        prompt_parts.append("1. Read the problem carefully and identify key information")
        prompt_parts.append("2. Apply systematic reasoning using the approach shown in examples")
        prompt_parts.append("3. Consider all constraints and relationships")
        prompt_parts.append("4. Verify your answer makes logical sense")
        prompt_parts.append("5. Provide your response in the required JSON format")
        
        return "\n".join(prompt_parts)
    
    def _get_few_shot_examples(self, topic: str) -> List[Dict[str, str]]:
        """Get few-shot examples for the specified topic."""
        topic_key = topic.lower().replace(" ", "_")
        examples = self.few_shot_examples.get(topic_key, [])
        
        # Limit number of examples based on configuration
        max_examples = self.config.get("few_shot_count", 3)
        return examples[:max_examples]
    
    def _build_step_by_step_guidance(self, topic: str) -> str:
        """Build step-by-step reasoning guidance."""
        return """**Step-by-Step Approach:**
1. **Understand**: Carefully read and identify what is being asked
2. **Analyze**: Break down the problem and identify key constraints/information
3. **Strategy**: Apply the most appropriate reasoning approach for this problem type
4. **Execute**: Work through the logic systematically
5. **Verify**: Ensure your answer satisfies all given conditions
6. **Explain**: Provide clear reasoning for your conclusion"""
    
    def _build_chain_of_thought_guidance(self, topic: str) -> str:
        """Build chain-of-thought reasoning guidance."""
        return """**Chain-of-Thought Reasoning:**
Think through this problem step by step, showing your reasoning process:
• Start with what you know for certain
• Build logical connections between pieces of information
• Consider implications of each constraint or statement
• Work towards the conclusion systematically
• Check your reasoning for consistency and completeness"""
    
    def _format_choices(self, choices: List[str]) -> str:
        """Format multiple choice options."""
        formatted_choices = []
        for i, choice in enumerate(choices):
            letter = chr(65 + i)  # A, B, C, D
            if not choice.strip().startswith(f"{letter})"):
                formatted_choices.append(f"{letter}) {choice.strip()}")
            else:
                formatted_choices.append(choice.strip())
        return " ".join(formatted_choices)
    
    def build_validation_prompt(self, question: str, answer: str, reasoning: str) -> str:
        """Build prompt for validating generated answers."""
        return f"""**Answer Validation Task:**

Question: {question}
Provided Answer: {answer}
Provided Reasoning: {reasoning}

**Validation Criteria:**
1. Is the answer format correct (single letter A, B, C, or D)?
2. Is the reasoning logically sound and complete?
3. Does the reasoning support the chosen answer?
4. Are there any logical inconsistencies or errors?
5. Is the explanation clear and well-structured?

**Provide validation results as JSON:**
{{
    "is_valid": true/false,
    "format_correct": true/false,
    "reasoning_sound": true/false,
    "consistency_check": true/false,
    "clarity_score": 0.0-1.0,
    "issues": ["list of any issues found"],
    "suggestions": ["list of improvement suggestions"]
}}"""
    
    def build_difficulty_assessment_prompt(self, question: str) -> str:
        """Build prompt for assessing question difficulty."""
        return f"""**Difficulty Assessment Task:**

Question: {question}

**Assessment Criteria:**
1. Number of entities/people involved
2. Complexity of relationships or constraints
3. Number of logical steps required
4. Presence of edge cases or tricky elements
5. Overall cognitive load required

**Difficulty Levels:**
• Easy: 2-4 entities, direct relationships, 2-3 reasoning steps
• Medium: 4-6 entities, some indirect relationships, 3-5 reasoning steps
• Hard: 6-8 entities, complex relationships, 5-8 reasoning steps
• Expert: 8+ entities, very complex relationships, 8+ reasoning steps

**Provide assessment as JSON:**
{{
    "difficulty_level": "easy/medium/hard/expert",
    "entity_count": number,
    "reasoning_steps_required": number,
    "complexity_factors": ["list of complexity factors"],
    "difficulty_score": 0.0-1.0
}}"""


class PromptTemplateManager:
    """
    Manages different prompt templates for various use cases.
    """
    
    def __init__(self):
        self.templates = self._initialize_templates()
    
    def _initialize_templates(self) -> Dict[str, str]:
        """Initialize prompt templates."""
        return {
            "question_generation": """Generate a {difficulty} level {topic} question with the following requirements:
- Include {entity_count} entities/people
- Create {constraint_count} logical constraints
- Ensure the question has exactly one correct answer
- Provide 4 multiple choice options (A, B, C, D)
- Include clear reasoning for the correct answer

Format your response as JSON:
{{
    "question": "The question text",
    "choices": ["A) option 1", "B) option 2", "C) option 3", "D) option 4"],
    "answer": "Correct letter (A, B, C, or D)",
    "reasoning": "Step-by-step explanation",
    "difficulty": "{difficulty}",
    "topic": "{topic}"
}}""",
            
            "answer_generation": """Solve this {topic} problem using systematic reasoning:

Question: {question}
Choices: {choices}

Use the following approach:
1. Identify key information and constraints
2. Apply logical reasoning step by step
3. Eliminate incorrect options
4. Verify your answer

Provide your response as JSON:
{{
    "answer": "Single letter A, B, C, or D",
    "reasoning": "Clear explanation of your reasoning process"
}}""",
            
            "quality_evaluation": """Evaluate the quality of this question and answer pair:

Question: {question}
Answer: {answer}
Reasoning: {reasoning}

Rate each aspect from 0.0 to 1.0:
- Question clarity and completeness
- Answer correctness
- Reasoning quality and logic
- Overall difficulty appropriateness

Provide evaluation as JSON:
{{
    "question_clarity": 0.0-1.0,
    "answer_correctness": 0.0-1.0,
    "reasoning_quality": 0.0-1.0,
    "difficulty_appropriate": 0.0-1.0,
    "overall_score": 0.0-1.0,
    "feedback": "Detailed feedback and suggestions"
}}"""
        }
    
    def get_template(self, template_name: str, **kwargs) -> str:
        """Get formatted template with provided parameters."""
        template = self.templates.get(template_name, "")
        if not template:
            raise ValueError(f"Template '{template_name}' not found")
        
        try:
            return template.format(**kwargs)
        except KeyError as e:
            raise ValueError(f"Missing required parameter for template '{template_name}': {e}")


# Utility functions for backward compatibility
def build_prompt(question_data: Dict[str, Any], 
                topic: str = "general",
                style: str = "systematic") -> Tuple[str, str]:
    """
    Build prompt for question answering (backward compatible).
    
    Returns:
        Tuple of (user_prompt, system_prompt)
    """
    builder = EnhancedPromptBuilder()
    
    system_prompt = builder.build_system_prompt(topic)
    user_prompt = builder.build_question_prompt(
        question_data, 
        topic, 
        reasoning_style=style
    )
    
    return user_prompt, system_prompt


def build_generation_prompt(topic: str, 
                          difficulty: str = "medium",
                          **kwargs) -> str:
    """
    Build prompt for question generation.
    """
    template_manager = PromptTemplateManager()
    return template_manager.get_template(
        "question_generation",
        topic=topic,
        difficulty=difficulty,
        **kwargs
    )


# Example usage and testing
if __name__ == "__main__":
    # Test the enhanced prompt builder
    builder = EnhancedPromptBuilder()
    
    # Test question data
    test_question = {
        "question": "Alice says 'Bob is a liar' and Bob says 'I am telling the truth'. What are Alice and Bob?",
        "choices": [
            "A) Both truth-tellers",
            "B) Both liars", 
            "C) Alice is truth-teller, Bob is liar",
            "D) Alice is liar, Bob is truth-teller"
        ]
    }
    
    # Build prompts for different topics
    topics = ["truth_teller_liar", "seating_arrangements", "blood_relations"]
    
    for topic in topics:
        print(f"\n{'='*60}")
        print(f"TESTING {topic.upper()} PROMPTS")
        print(f"{'='*60}")
        
        system_prompt = builder.build_system_prompt(topic, "medium")
        user_prompt = builder.build_question_prompt(test_question, topic)
        
        print("SYSTEM PROMPT:")
        print(system_prompt[:500] + "..." if len(system_prompt) > 500 else system_prompt)
        
        print("\nUSER PROMPT:")
        print(user_prompt[:500] + "..." if len(user_prompt) > 500 else user_prompt)
    
    print(f"\n{'='*60}")
    print("ENHANCED PROMPT BUILDER TEST COMPLETE")
    print(f"{'='*60}")

