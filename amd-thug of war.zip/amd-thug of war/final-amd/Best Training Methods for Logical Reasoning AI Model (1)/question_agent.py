#!/usr/bin/python3

# Enhanced Question Agent with Advanced Synthetic Data Generation
# Integrates curriculum learning, quality validation, and systematic problem generation

from tqdm import tqdm
from pathlib import Path
from typing import List, Tuple, Dict, Any, Optional, Union
import logging
import numpy as np

from .question_model import EnhancedQAgent

import random
import json
import time
import re
from collections import defaultdict

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class QualityValidator:
    """
    Advanced quality validator for generated questions.
    
    Implements comprehensive validation including logical consistency,
    difficulty assessment, and curriculum alignment.
    """
    
    def __init__(self):
        self.validation_criteria = {
            'json_format': self._validate_json_format,
            'required_fields': self._validate_required_fields,
            'logical_consistency': self._validate_logical_consistency,
            'difficulty_alignment': self._validate_difficulty_alignment,
            'uniqueness': self._validate_uniqueness,
            'token_length': self._validate_token_length
        }
        
        self.seen_questions = set()
        self.quality_thresholds = {
            'easy': 0.7,
            'medium': 0.75,
            'hard': 0.8,
            'expert': 0.85
        }
    
    def validate_question(self, question: Union[str, Dict], difficulty: str = 'medium') -> Tuple[bool, float, List[str]]:
        """
        Comprehensive question validation.
        
        Returns:
            (is_valid, quality_score, issues)
        """
        issues = []
        scores = []
        
        # Convert string to dict if needed
        if isinstance(question, str):
            try:
                question = json.loads(question)
            except json.JSONDecodeError:
                return False, 0.0, ["Invalid JSON format"]
        
        # Run all validation criteria
        for criterion_name, validator in self.validation_criteria.items():
            try:
                is_valid, score, criterion_issues = validator(question, difficulty)
                scores.append(score)
                if not is_valid:
                    issues.extend([f"{criterion_name}: {issue}" for issue in criterion_issues])
            except Exception as e:
                issues.append(f"{criterion_name}: Validation error - {str(e)}")
                scores.append(0.0)
        
        # Calculate overall quality score
        quality_score = np.mean(scores) if scores else 0.0
        
        # Determine if question meets quality threshold
        threshold = self.quality_thresholds.get(difficulty, 0.75)
        is_valid = quality_score >= threshold and len(issues) == 0
        
        return is_valid, quality_score, issues
    
    def _validate_json_format(self, question: Dict, difficulty: str) -> Tuple[bool, float, List[str]]:
        """Validate JSON format and structure."""
        issues = []
        
        if not isinstance(question, dict):
            issues.append("Not a valid dictionary")
            return False, 0.0, issues
        
        return True, 1.0, issues
    
    def _validate_required_fields(self, question: Dict, difficulty: str) -> Tuple[bool, float, List[str]]:
        """Validate required fields are present and properly formatted."""
        issues = []
        required_fields = ['topic', 'question', 'choices', 'answer', 'explanation']
        
        # Check all required fields exist
        missing_fields = [field for field in required_fields if field not in question]
        if missing_fields:
            issues.extend([f"Missing field: {field}" for field in missing_fields])
        
        # Validate choices format
        if 'choices' in question:
            choices = question['choices']
            if not isinstance(choices, list) or len(choices) != 4:
                issues.append("Choices must be a list of exactly 4 options")
            else:
                for i, choice in enumerate(choices):
                    expected_prefix = ['A)', 'B)', 'C)', 'D)'][i]
                    if not isinstance(choice, str) or not choice.startswith(expected_prefix):
                        issues.append(f"Choice {i+1} must start with '{expected_prefix}'")
        
        # Validate answer format
        if 'answer' in question:
            answer = question['answer']
            if not isinstance(answer, str) or answer.upper() not in ['A', 'B', 'C', 'D']:
                issues.append("Answer must be one of: A, B, C, D")
        
        score = 1.0 - (len(issues) / 10)  # Penalize issues
        return len(issues) == 0, max(0.0, score), issues
    
    def _validate_logical_consistency(self, question: Dict, difficulty: str) -> Tuple[bool, float, List[str]]:
        """Validate logical consistency of the question and answer."""
        issues = []
        
        if 'question' not in question or 'answer' not in question:
            return False, 0.0, ["Missing question or answer"]
        
        question_text = question['question'].lower()
        
        # Check for logical reasoning patterns
        reasoning_patterns = {
            'truth_liar': ['truth', 'liar', 'village', 'says'],
            'seating': ['sitting', 'seat', 'arrangement', 'row', 'circular', 'table'],
            'blood_relations': ['father', 'mother', 'brother', 'sister', 'relation', 'family']
        }
        
        # Identify problem type
        problem_type = None
        for ptype, keywords in reasoning_patterns.items():
            if any(keyword in question_text for keyword in keywords):
                problem_type = ptype
                break
        
        if problem_type:
            # Type-specific validation
            if problem_type == 'truth_liar':
                score = self._validate_truth_liar_logic(question)
            elif problem_type == 'seating':
                score = self._validate_seating_logic(question)
            elif problem_type == 'blood_relations':
                score = self._validate_blood_relations_logic(question)
            else:
                score = 0.7  # Default score for unrecognized patterns
        else:
            score = 0.5  # Lower score for unclear problem type
        
        return score > 0.6, score, issues
    
    def _validate_truth_liar_logic(self, question: Dict) -> float:
        """Validate truth-teller/liar problem logic."""
        question_text = question['question'].lower()
        
        # Check for logical consistency indicators
        consistency_score = 0.8  # Base score
        
        # Look for contradiction patterns
        if 'contradiction' in question_text or 'paradox' in question_text:
            consistency_score += 0.1
        
        # Check for proper logical structure
        if 'says' in question_text and ('truth' in question_text or 'liar' in question_text):
            consistency_score += 0.1
        
        return min(1.0, consistency_score)
    
    def _validate_seating_logic(self, question: Dict) -> float:
        """Validate seating arrangement logic."""
        question_text = question['question'].lower()
        
        # Check for constraint satisfaction indicators
        constraint_score = 0.8  # Base score
        
        # Look for proper constraint language
        constraint_words = ['next to', 'opposite', 'between', 'left', 'right', 'end']
        constraint_count = sum(1 for word in constraint_words if word in question_text)
        
        if constraint_count >= 2:
            constraint_score += 0.1
        if constraint_count >= 4:
            constraint_score += 0.1
        
        return min(1.0, constraint_score)
    
    def _validate_blood_relations_logic(self, question: Dict) -> float:
        """Validate blood relations logic."""
        question_text = question['question'].lower()
        
        # Check for relationship consistency
        relation_score = 0.8  # Base score
        
        # Look for proper relationship terms
        relation_words = ['father', 'mother', 'son', 'daughter', 'brother', 'sister', 'cousin']
        relation_count = sum(1 for word in relation_words if word in question_text)
        
        if relation_count >= 2:
            relation_score += 0.1
        if relation_count >= 4:
            relation_score += 0.1
        
        return min(1.0, relation_score)
    
    def _validate_difficulty_alignment(self, question: Dict, difficulty: str) -> Tuple[bool, float, List[str]]:
        """Validate that question difficulty matches expected level."""
        issues = []
        
        if 'question' not in question:
            return False, 0.0, ["Missing question text"]
        
        question_text = question['question']
        
        # Difficulty indicators
        complexity_indicators = {
            'easy': ['simple', 'basic', 'two people', 'three people'],
            'medium': ['multiple', 'several', 'four people', 'five people'],
            'hard': ['complex', 'many', 'six people', 'seven people', 'exactly'],
            'expert': ['extremely', 'very complex', 'eight people', 'conditional', 'if and only if']
        }
        
        # Count complexity indicators for target difficulty
        target_indicators = complexity_indicators.get(difficulty, [])
        indicator_count = sum(1 for indicator in target_indicators if indicator in question_text.lower())
        
        # Calculate alignment score
        if indicator_count > 0:
            alignment_score = min(1.0, 0.7 + (indicator_count * 0.1))
        else:
            # Check length as proxy for complexity
            word_count = len(question_text.split())
            if difficulty == 'easy' and word_count < 30:
                alignment_score = 0.8
            elif difficulty == 'medium' and 30 <= word_count < 50:
                alignment_score = 0.8
            elif difficulty == 'hard' and 50 <= word_count < 80:
                alignment_score = 0.8
            elif difficulty == 'expert' and word_count >= 80:
                alignment_score = 0.8
            else:
                alignment_score = 0.6
        
        return alignment_score > 0.7, alignment_score, issues
    
    def _validate_uniqueness(self, question: Dict, difficulty: str) -> Tuple[bool, float, List[str]]:
        """Validate question uniqueness."""
        issues = []
        
        if 'question' not in question:
            return False, 0.0, ["Missing question text"]
        
        question_text = question['question']
        question_hash = hash(question_text.lower().strip())
        
        if question_hash in self.seen_questions:
            issues.append("Duplicate question detected")
            return False, 0.0, issues
        
        self.seen_questions.add(question_hash)
        return True, 1.0, issues
    
    def _validate_token_length(self, question: Dict, difficulty: str) -> Tuple[bool, float, List[str]]:
        """Validate token length constraints."""
        issues = []
        
        # Estimate token count (rough approximation)
        total_text = ""
        for key in ['question', 'explanation']:
            if key in question:
                total_text += question[key] + " "
        
        if 'choices' in question:
            for choice in question['choices']:
                total_text += choice + " "
        
        estimated_tokens = len(total_text.split()) * 1.3  # Rough token estimation
        
        # Token limits by difficulty
        token_limits = {
            'easy': 150,
            'medium': 200,
            'hard': 300,
            'expert': 400
        }
        
        limit = token_limits.get(difficulty, 200)
        
        if estimated_tokens > limit:
            issues.append(f"Estimated tokens ({estimated_tokens:.0f}) exceed limit ({limit})")
            score = max(0.0, 1.0 - (estimated_tokens - limit) / limit)
        else:
            score = 1.0
        
        return len(issues) == 0, score, issues


class CurriculumManager:
    """
    Manages curriculum learning progression for question generation.
    
    Implements adaptive difficulty progression based on performance metrics.
    """
    
    def __init__(self):
        self.stages = ['easy', 'medium', 'hard', 'expert']
        self.current_stage = 0
        self.stage_performance = defaultdict(list)
        self.progression_threshold = 0.8
        self.min_samples_per_stage = 50
    
    def get_current_stage(self) -> str:
        """Get current curriculum stage."""
        return self.stages[self.current_stage]
    
    def update_performance(self, stage: str, quality_score: float):
        """Update performance for a stage."""
        if stage in self.stages:
            self.stage_performance[stage].append(quality_score)
    
    def should_advance_stage(self) -> bool:
        """Determine if we should advance to next stage."""
        current_stage_name = self.get_current_stage()
        
        if len(self.stage_performance[current_stage_name]) < self.min_samples_per_stage:
            return False
        
        # Check if performance meets threshold
        recent_scores = self.stage_performance[current_stage_name][-20:]  # Last 20 samples
        avg_performance = np.mean(recent_scores)
        
        return avg_performance >= self.progression_threshold
    
    def advance_stage(self) -> bool:
        """Advance to next curriculum stage."""
        if self.current_stage < len(self.stages) - 1:
            self.current_stage += 1
            logger.info(f"Advanced to curriculum stage: {self.get_current_stage()}")
            return True
        return False
    
    def get_stage_distribution(self, total_questions: int) -> Dict[str, int]:
        """Get question distribution across stages for curriculum learning."""
        # Progressive distribution: more questions in earlier stages
        distribution = {
            'easy': int(total_questions * 0.4),
            'medium': int(total_questions * 0.3),
            'hard': int(total_questions * 0.2),
            'expert': int(total_questions * 0.1)
        }
        
        # Adjust for any rounding errors
        total_assigned = sum(distribution.values())
        if total_assigned < total_questions:
            distribution['medium'] += total_questions - total_assigned
        
        return distribution


class EnhancedQuestioningAgent(object):
    """
    Enhanced Question Agent with advanced synthetic data generation.
    
    Integrates curriculum learning, quality validation, systematic problem
    generation, and performance monitoring while maintaining backward compatibility.
    """
    
    def __init__(self, **kwargs):
        # Initialize enhanced agent with advanced capabilities
        self.agent = EnhancedQAgent(**kwargs)
        
        # Advanced components
        self.quality_validator = QualityValidator()
        self.curriculum_manager = CurriculumManager()
        
        # Enhanced features
        self.enable_curriculum_learning = kwargs.get('enable_curriculum_learning', True)
        self.enable_quality_validation = kwargs.get('enable_quality_validation', True)
        self.enable_adaptive_generation = kwargs.get('enable_adaptive_generation', True)
        
        # Performance tracking
        self.generation_metrics = {
            'total_generated': 0,
            'total_valid': 0,
            'quality_scores': [],
            'generation_times': [],
            'stage_progression': []
        }
        
        logger.info("Enhanced Questioning Agent initialized with advanced capabilities")
    
    def build_inc_samples(self, inc_samples: List[Dict[str, str]], topic: str) -> str:
        """
        Enhanced in-context sample building with quality optimization.
        """
        if not inc_samples:
            return ""
        
        # Enhanced format with reasoning cues
        fmt = (
            'EXAMPLE: {}\n'
            '{{\n'
            '  "topic": "{}",\n'
            '  "question": "{}",\n'
            '  "choices": ["A) {}", "B) {}", "C) {}", "D) {}"],\n'
            '  "answer": "{}",\n'
            '  "explanation": "{}"\n'
            '}}\n'
            '// This example demonstrates proper logical structure and reasoning\n'
        )
        
        sample_str = ""
        for sample in inc_samples:
            question = sample.get("question", "")
            choices = sample.get("choices", [""] * 4)
            answer = sample.get("answer", "")
            explanation = sample.get("explanation", "")
            sample_str += fmt.format(topic, topic.split('/')[-1], question, *choices, answer, explanation) + "\n"
        
        return sample_str.strip()
    
    def build_prompt(self, 
                    topic: str, 
                    wadvsys: bool = True, 
                    wicl: bool = True, 
                    inc_samples: List[Dict[str, str]] = None,
                    difficulty: str = 'medium') -> Tuple[str, str]:
        """
        Enhanced prompt building with curriculum learning and quality optimization.
        """
        
        if wadvsys:
            # Enhanced system prompt with reasoning optimization
            sys_prompt = f"""
            You are an **expert-level examiner** specializing in **{difficulty.upper()}** difficulty logical reasoning questions for competitive exams.
            
            **Expertise Areas:**
            - Truth-teller and Liar Problems: Complex logical deduction with multiple agents
            - Seating Arrangements: Linear and circular arrangements with constraints
            - Blood Relations: Multi-generational family relationship analysis
            
            **Quality Standards for {difficulty.upper()} level:**
            - Questions must test deep conceptual understanding appropriate for {difficulty} level
            - All logical constraints must be satisfiable and lead to unique solutions
            - Avoid contradictions, paradoxes, and ambiguities
            - Use systematic reasoning approaches
            - Ensure mathematical and logical consistency
            
            **Generation Instructions:**
            - Think step-by-step through the logical reasoning
            - Verify all constraints are consistent before finalizing
            - Ensure the correct answer is definitively correct
            - Make distractors plausible but clearly incorrect
            - Provide clear, educational explanations
            
            **CRITICAL: Only output the final JSON result. Do not show reasoning steps.**
            """
        else:
            sys_prompt = f"You are an expert examiner creating {difficulty} difficulty multiple-choice questions with perfect logical consistency."
        
        # Enhanced template with difficulty-specific requirements
        difficulty_requirements = {
            'easy': {
                'complexity': 'straightforward with 2-3 entities',
                'constraints': '2-3 simple constraints',
                'reasoning': 'direct logical deduction'
            },
            'medium': {
                'complexity': 'moderate complexity with 3-4 entities',
                'constraints': '3-4 interconnected constraints',
                'reasoning': 'multi-step logical reasoning'
            },
            'hard': {
                'complexity': 'high complexity with 4-6 entities',
                'constraints': '4-6 complex constraints with dependencies',
                'reasoning': 'advanced logical deduction with multiple paths'
            },
            'expert': {
                'complexity': 'very high complexity with 5+ entities',
                'constraints': '5+ intricate constraints with conditional logic',
                'reasoning': 'expert-level reasoning with nested logical structures'
            }
        }
        
        req = difficulty_requirements.get(difficulty, difficulty_requirements['medium'])
        
        tmpl = (
            'Generate an **{0} DIFFICULTY** MCQ on topic: {1}.\n\n'
            
            '**DIFFICULTY REQUIREMENTS for {2}:**\n'
            '- Complexity: {3}\n'
            '- Constraints: {4}\n'
            '- Reasoning: {5}\n\n'

            '**CRITICAL REQUIREMENTS:**\n'
            '1. **Topic Alignment**: Question must be strictly relevant to: {6}\n'
            '2. **Difficulty Level**: Must match {7} difficulty exactly\n'
            '3. **Logical Consistency**: All constraints must be satisfiable with unique solution\n'
            '4. **Question Quality**: Clear, unambiguous, tests deep understanding\n'
            '5. **Choices (4 total)**: Exactly FOUR options labeled A), B), C), D)\n'
            '6. **Single Correct Answer**: Option {8} must be the only correct answer\n'
            '7. **Plausible Distractors**: Options {9} must be plausible but clearly incorrect\n'
            '8. **Answer Key**: "answer" field must contain only the letter {10}\n'
            '9. **Explanation**: Concise justification (under 100 words) for correct answer\n\n'

            '{11}'
            
            '**RESPONSE FORMAT**: Generate ONLY a valid JSON object with perfect syntax:\n\n'
            
            'EXAMPLE for {12}:\n'
            '{{\n'
            '  "topic": "{13}",\n'
            '  "question": "Your {14} difficulty question ending with question mark?",\n'
            '  "choices": ["A) First option", "B) Second option", "C) Third option", "D) Fourth option"],\n'
            '  "answer": "{15}",\n'
            '  "explanation": "Brief explanation why {16} is correct within 100 words."\n'
            '}}\n\n'
            
            '**VERIFICATION CHECKLIST:**\n'
            '- [ ] Question matches {17} difficulty level\n'
            '- [ ] All logical constraints are consistent\n'
            '- [ ] Exactly one correct answer exists\n'
            '- [ ] JSON format is perfect\n'
            '- [ ] Topic alignment is exact\n'
        )
        
        # Remove model's preferential bias for options
        correct_option = random.choice(['A', 'B', 'C', 'D'])
        distractors = ", ".join([opt for opt in ['A', 'B', 'C', 'D'] if opt != correct_option])
        
        # Build in-context samples
        if wicl and inc_samples:
            inc_samples_ex = self.build_inc_samples(inc_samples, topic)
        else:
            inc_samples_ex = ""
        
        # Format the complete prompt
        prompt = tmpl.format(
            difficulty.upper(),  # 0
            topic,  # 1
            difficulty.upper(),  # 2
            req['complexity'],  # 3
            req['constraints'],  # 4
            req['reasoning'],  # 5
            topic,  # 6
            difficulty.upper(),  # 7
            correct_option,  # 8
            distractors,  # 9
            correct_option,  # 10
            inc_samples_ex,  # 11
            topic,  # 12
            topic.split('/')[-1],  # 13
            difficulty,  # 14
            correct_option,  # 15
            correct_option,  # 16
            difficulty  # 17
        )
        
        return prompt, sys_prompt
    
    def generate_question(self, 
                         topic: Union[Tuple[str, str], List[Tuple[str, str]]], 
                         wadvsys: bool, 
                         wicl: bool, 
                         inc_samples: Optional[Dict[str, List[Dict[str, str]]]], 
                         **gen_kwargs) -> Tuple[List[str], Optional[int], Optional[float]]:
        """
        Enhanced question generation with curriculum learning and quality validation.
        """
        
        # Determine difficulty based on curriculum stage
        if self.enable_curriculum_learning:
            difficulty = self.curriculum_manager.get_current_stage()
        else:
            difficulty = gen_kwargs.get('difficulty', 'medium')
        
        # Set curriculum stage in agent
        self.agent.set_curriculum_stage(difficulty)
        
        start_time = time.time()
        
        if isinstance(topic, list):
            prompts = []
            for t in topic:
                p, sp = self.build_prompt(
                    f"{t[0]}/{t[1]}", 
                    wadvsys, 
                    wicl, 
                    inc_samples.get(t[1], []) if inc_samples else [], 
                    difficulty
                )
                prompts.append(p)
        else:
            prompt, sp = self.build_prompt(
                f"{topic[0]}/{topic[1]}", 
                wadvsys, 
                wicl, 
                inc_samples.get(topic[1], []) if inc_samples else [], 
                difficulty
            )
            prompts = prompt
        
        # Generate with enhanced parameters
        enhanced_kwargs = gen_kwargs.copy()
        enhanced_kwargs.update({
            'temperature': min(enhanced_kwargs.get('temperature', 0.1), 0.3),  # Lower temp for consistency
            'top_p': enhanced_kwargs.get('top_p', 0.9),
            'repetition_penalty': enhanced_kwargs.get('repetition_penalty', 1.1)
        })
        
        resp, tl, gt = self.agent.generate_response(prompts, sp, **enhanced_kwargs)
        
        generation_time = time.time() - start_time
        
        # Quality validation if enabled
        if self.enable_quality_validation:
            if isinstance(resp, list):
                validated_resp = []
                for r in resp:
                    is_valid, quality_score, issues = self.quality_validator.validate_question(r, difficulty)
                    if is_valid:
                        validated_resp.append(r)
                        self.curriculum_manager.update_performance(difficulty, quality_score)
                    else:
                        logger.debug(f"Question failed validation: {issues}")
                        # Attempt regeneration with stricter parameters
                        retry_resp = self._regenerate_with_fixes(prompts, sp, issues, enhanced_kwargs)
                        validated_resp.append(retry_resp)
                resp = validated_resp
            else:
                is_valid, quality_score, issues = self.quality_validator.validate_question(resp, difficulty)
                if not is_valid:
                    logger.debug(f"Question failed validation: {issues}")
                    resp = self._regenerate_with_fixes(prompts, sp, issues, enhanced_kwargs)
                else:
                    self.curriculum_manager.update_performance(difficulty, quality_score)
        
        # Update metrics
        self._update_generation_metrics(resp, generation_time, difficulty)
        
        # Check for curriculum advancement
        if self.enable_curriculum_learning and self.curriculum_manager.should_advance_stage():
            if self.curriculum_manager.advance_stage():
                self.generation_metrics['stage_progression'].append({
                    'timestamp': time.time(),
                    'new_stage': self.curriculum_manager.get_current_stage()
                })
        
        if (isinstance(resp, list) and all(isinstance(r, str) for r in resp)) or isinstance(resp, str):
            return resp, tl, gt
        else:
            return ('', tl, gt) if not isinstance(resp, list) else ([''] * len(resp), tl, gt)
    
    def _regenerate_with_fixes(self, 
                              prompts: Union[str, List[str]], 
                              system_prompt: str, 
                              issues: List[str], 
                              gen_kwargs: Dict) -> str:
        """Regenerate question with fixes based on validation issues."""
        
        # Create enhanced prompt with specific fixes
        fix_instructions = "\n\n**CRITICAL FIXES REQUIRED:**\n"
        for issue in issues:
            if "JSON" in issue:
                fix_instructions += "- Ensure perfect JSON format with proper quotes and brackets\n"
            elif "field" in issue:
                fix_instructions += "- Include all required fields: topic, question, choices, answer, explanation\n"
            elif "choices" in issue:
                fix_instructions += "- Format choices exactly as: ['A) ...', 'B) ...', 'C) ...', 'D) ...']\n"
            elif "answer" in issue:
                fix_instructions += "- Answer must be exactly one letter: A, B, C, or D\n"
        
        enhanced_prompt = prompts + fix_instructions if isinstance(prompts, str) else [p + fix_instructions for p in prompts]
        
        # Regenerate with stricter parameters
        strict_kwargs = gen_kwargs.copy()
        strict_kwargs.update({
            'temperature': 0.05,  # Very low temperature for consistency
            'top_p': 0.8,
            'max_new_tokens': min(strict_kwargs.get('max_new_tokens', 1024), 800)
        })
        
        retry_resp, _, _ = self.agent.generate_response(enhanced_prompt, system_prompt, **strict_kwargs)
        return retry_resp if isinstance(retry_resp, str) else retry_resp[0] if retry_resp else ""
    
    def _update_generation_metrics(self, responses: Union[str, List[str]], generation_time: float, difficulty: str):
        """Update generation performance metrics."""
        
        response_count = 1 if isinstance(responses, str) else len(responses)
        
        self.generation_metrics['total_generated'] += response_count
        self.generation_metrics['generation_times'].append(generation_time)
        
        # Validate responses for metrics
        if isinstance(responses, str):
            responses = [responses]
        
        for resp in responses:
            if self.enable_quality_validation:
                is_valid, quality_score, _ = self.quality_validator.validate_question(resp, difficulty)
                if is_valid:
                    self.generation_metrics['total_valid'] += 1
                self.generation_metrics['quality_scores'].append(quality_score)
            else:
                # Basic validation for metrics
                try:
                    json.loads(resp)
                    self.generation_metrics['total_valid'] += 1
                    self.generation_metrics['quality_scores'].append(0.8)  # Default score
                except:
                    self.generation_metrics['quality_scores'].append(0.3)
    
    def generate_batches(self, 
                        num_questions: int, 
                        topics: Dict[str, List[str]], 
                        batch_size: int = 5, 
                        wadvsys: bool = True, 
                        wicl: bool = True, 
                        inc_samples: Optional[Dict[str, List[Dict[str, str]]]] = None, 
                        **kwargs) -> Tuple[List[str], List[Optional[int]], List[Optional[float]]]:
        """
        Enhanced batch generation with curriculum learning and quality optimization.
        """
        
        # Get curriculum-based topic distribution if enabled
        if self.enable_curriculum_learning:
            stage_distribution = self.curriculum_manager.get_stage_distribution(num_questions)
            logger.info(f"Curriculum distribution: {stage_distribution}")
        
        # Generate extended topics with curriculum consideration
        extended_topics = self.populate_topics(topics, num_questions)
        
        questions = []
        tls, gts = [], []
        
        # Calculate total batches
        total_batches = (len(extended_topics) + batch_size - 1) // batch_size
        pbar = tqdm(total=total_batches, desc="Enhanced Generation")
        
        for i in range(0, len(extended_topics), batch_size):
            batch_topics = extended_topics[i:i + batch_size]
            
            # Generate batch with enhanced parameters
            batch_questions = self.generate_question(
                batch_topics, wadvsys, wicl, inc_samples, **kwargs
            )
            
            questions.extend(batch_questions[0])
            tls.append(batch_questions[1])
            gts.append(batch_questions[2])
            
            pbar.update(1)
            
            # Log progress periodically
            if i % (batch_size * 10) == 0:
                current_metrics = self.get_generation_metrics()
                logger.info(f"Progress: {len(questions)}/{num_questions} questions, "
                          f"Quality: {current_metrics['average_quality_score']:.3f}")
        
        pbar.close()
        
        # Final metrics report
        final_metrics = self.get_generation_metrics()
        logger.info(f"Generation complete: {final_metrics}")
        
        return questions, tls, gts
    
    def generate_curriculum_dataset(self, 
                                  total_questions: int = 1000,
                                  topics: Dict[str, List[str]] = None,
                                  **kwargs) -> List[Dict[str, Any]]:
        """
        Generate a complete curriculum dataset with systematic progression.
        """
        
        if not topics:
            # Default topics for logical reasoning
            topics = {
                "Logical Reasoning": [
                    "Truth-teller and Liar Problems",
                    "Seating Arrangements",
                    "Blood Relations"
                ]
            }
        
        # Use synthetic data generator for systematic curriculum
        curriculum_data = self.agent.generate_curriculum_dataset(total_questions)
        
        # Convert to question format
        formatted_questions = []
        for problem in curriculum_data:
            # Convert synthetic problem to MCQ format
            mcq = self._convert_problem_to_mcq(problem)
            formatted_questions.append(mcq)
        
        logger.info(f"Generated {len(formatted_questions)} curriculum questions")
        return formatted_questions
    
    def _convert_problem_to_mcq(self, problem: Dict[str, Any]) -> Dict[str, Any]:
        """Convert synthetic problem to MCQ format."""
        
        # Generate plausible distractors based on problem type
        correct_answer = problem['answer']
        choices = self._generate_choices(problem, correct_answer)
        
        # Shuffle choices and determine correct option
        random.shuffle(choices)
        correct_option = None
        for i, choice in enumerate(choices):
            if correct_answer.lower() in choice.lower():
                correct_option = ['A', 'B', 'C', 'D'][i]
                break
        
        if not correct_option:
            correct_option = 'A'
            choices[0] = f"A) {correct_answer}"
        
        return {
            "topic": problem['type'].replace('_', ' ').title(),
            "question": problem['question'],
            "choices": [f"{['A', 'B', 'C', 'D'][i]}) {choice.split(') ', 1)[-1]}" 
                       for i, choice in enumerate(choices)],
            "answer": correct_option,
            "explanation": f"Step-by-step reasoning: {' '.join(problem.get('reasoning_steps', ['Direct logical deduction leads to this answer.'])[:3])}"
        }
    
    def _generate_choices(self, problem: Dict[str, Any], correct_answer: str) -> List[str]:
        """Generate plausible choices for MCQ."""
        
        choices = [f"A) {correct_answer}"]
        
        # Generate distractors based on problem type
        if problem['type'] == 'truth_liar':
            distractors = [
                "All are truth-tellers",
                "All are liars", 
                "Cannot be determined"
            ]
        elif problem['type'] == 'seating_arrangement':
            # Generate permutation-based distractors
            distractors = [
                "Arrangement cannot be uniquely determined",
                "Multiple valid arrangements exist",
                "Insufficient constraints provided"
            ]
        elif problem['type'] == 'blood_relations':
            distractors = [
                "No relation exists",
                "Distant relatives",
                "Relationship cannot be determined"
            ]
        else:
            distractors = [
                "Option B",
                "Option C", 
                "Option D"
            ]
        
        # Add distractors
        for i, distractor in enumerate(distractors[:3]):
            choices.append(f"{['B', 'C', 'D'][i]}) {distractor}")
        
        return choices
    
    # Maintain backward compatibility with original methods
    def count_tokens_q(self, text: str) -> int:
        """Count tokens using model tokenizer."""
        return self.agent.count_tokens_q(text) if hasattr(self.agent, 'count_tokens_q') else len(text.split())
    
    def filter_questions(self, questions: List[Union[str, Dict[str, Any]]]) -> List[Dict[str, Any]]:
        """
        Enhanced question filtering with quality validation.
        """
        
        def enhanced_checks(q: Dict[str, str]) -> Tuple[bool, float]:
            # Use quality validator if available
            if self.enable_quality_validation:
                is_valid, quality_score, _ = self.quality_validator.validate_question(q)
                return is_valid, quality_score
            
            # Fallback to basic checks
            required_keys = ['topic', 'question', 'choices', 'answer']
            if not all(key in q for key in required_keys):
                return False, 0.0
            
            # Check choices format
            if not (isinstance(q['choices'], list) and len(q['choices']) == 4):
                return False, 0.0
            
            choices_valid = all(
                isinstance(choice, str) and len(choice) > 2 and choice[0].upper() in 'ABCD' 
                for choice in q['choices']
            )
            
            if not choices_valid:
                return False, 0.0
            
            # Check answer format
            if not (isinstance(q['answer'], str) and q['answer'].upper() in 'ABCD'):
                return False, 0.0
            
            return True, 0.8  # Default quality score
        
        correct_format_questions = []
        quality_scores = []
        
        for i, q in enumerate(questions):
            if isinstance(q, dict):
                is_valid, quality_score = enhanced_checks(q)
                if is_valid:
                    correct_format_questions.append(q)
                    quality_scores.append(quality_score)
            elif isinstance(q, str):
                try:
                    q_dict = json.loads(q)
                    is_valid, quality_score = enhanced_checks(q_dict)
                    if is_valid:
                        correct_format_questions.append(q_dict)
                        quality_scores.append(quality_score)
                except json.JSONDecodeError:
                    logger.debug(f"Skipping invalid JSON at index {i}")
                    continue
        
        # Log filtering results
        logger.info(f"Filtered {len(correct_format_questions)}/{len(questions)} questions")
        if quality_scores:
            avg_quality = np.mean(quality_scores)
            logger.info(f"Average quality score: {avg_quality:.3f}")
        
        return correct_format_questions
    
    def save_questions(self, questions: Any, file_path: Union[str, Path]) -> None:
        """Enhanced question saving with metadata."""
        
        file_path = Path(file_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Add metadata
        save_data = {
            'questions': questions,
            'metadata': {
                'total_questions': len(questions) if isinstance(questions, list) else 1,
                'generation_timestamp': time.time(),
                'curriculum_stage': self.curriculum_manager.get_current_stage() if self.enable_curriculum_learning else 'N/A',
                'quality_validation_enabled': self.enable_quality_validation,
                'generation_metrics': self.get_generation_metrics()
            }
        }
        
        with open(file_path, 'w') as f:
            json.dump(save_data, f, indent=4)
        
        logger.info(f"Saved {len(questions) if isinstance(questions, list) else 1} questions to {file_path}")
    
    def populate_topics(self, topics: Dict[str, List[str]], num_questions: int) -> List[Tuple[str, str]]:
        """Enhanced topic population with curriculum consideration."""
        
        if not isinstance(topics, dict):
            raise ValueError("Topics must be a dictionary")
        
        all_subtopics = [(t, st) for t, sublist in topics.items() for st in sublist]
        if not all_subtopics:
            raise ValueError("No subtopics found")
        
        # Curriculum-aware selection
        if self.enable_curriculum_learning:
            # Weight topics based on curriculum stage
            current_stage = self.curriculum_manager.get_current_stage()
            
            # Prefer certain topics for different stages
            topic_weights = {}
            for topic, subtopic in all_subtopics:
                if current_stage == 'easy':
                    # Prefer simpler topics
                    weight = 2.0 if 'truth' in subtopic.lower() else 1.0
                elif current_stage == 'expert':
                    # Prefer complex topics
                    weight = 2.0 if 'arrangement' in subtopic.lower() else 1.0
                else:
                    weight = 1.0
                topic_weights[(topic, subtopic)] = weight
            
            # Weighted selection
            topics_list = list(topic_weights.keys())
            weights = list(topic_weights.values())
            selected_topics = random.choices(topics_list, weights=weights, k=num_questions)
        else:
            # Random selection (original behavior)
            selected_topics = random.choices(all_subtopics, k=num_questions)
        
        return selected_topics
    
    def get_generation_metrics(self) -> Dict[str, Any]:
        """Get comprehensive generation metrics."""
        
        metrics = self.generation_metrics.copy()
        
        # Calculate derived metrics
        if metrics['total_generated'] > 0:
            metrics['success_rate'] = metrics['total_valid'] / metrics['total_generated']
        else:
            metrics['success_rate'] = 0.0
        
        if metrics['quality_scores']:
            metrics['average_quality_score'] = np.mean(metrics['quality_scores'])
            metrics['quality_std'] = np.std(metrics['quality_scores'])
        else:
            metrics['average_quality_score'] = 0.0
            metrics['quality_std'] = 0.0
        
        if metrics['generation_times']:
            metrics['average_generation_time'] = np.mean(metrics['generation_times'])
            metrics['total_generation_time'] = sum(metrics['generation_times'])
        else:
            metrics['average_generation_time'] = 0.0
            metrics['total_generation_time'] = 0.0
        
        # Add curriculum information
        if self.enable_curriculum_learning:
            metrics['current_curriculum_stage'] = self.curriculum_manager.get_current_stage()
            metrics['stage_progressions'] = len(metrics['stage_progression'])
        
        return metrics
    
    @staticmethod
    def load_icl_samples(file_path: Union[str, Path]) -> Dict[str, List[Dict[str, str]]]:
        """Enhanced ICL sample loading with validation."""
        
        file_path = Path(file_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File {file_path} does not exist")
        
        with open(file_path, 'r') as f:
            samples = json.load(f)
        
        if not isinstance(samples, dict):
            raise ValueError("Samples must be in dictionary format")
        
        # Validate sample format
        for topic, topic_samples in samples.items():
            if not isinstance(topic_samples, list):
                logger.warning(f"Invalid samples format for topic: {topic}")
                continue
            
            for sample in topic_samples:
                required_fields = ['question', 'choices', 'answer', 'explanation']
                if not all(field in sample for field in required_fields):
                    logger.warning(f"Incomplete sample in topic {topic}: missing fields")
        
        logger.info(f"Loaded ICL samples for {len(samples)} topics")
        return samples


# Maintain backward compatibility
QuestioningAgent = EnhancedQuestioningAgent


# Example usage with enhanced features
if __name__ == "__main__":
    import argparse
    import yaml
    
    # Enhanced argument parser
    argparser = argparse.ArgumentParser(description="Enhanced Question Generation with Advanced Capabilities")
    argparser.add_argument("--num_questions", type=int, default=200, help="Total number of questions to generate")
    argparser.add_argument("--output_file", type=str, default="outputs/enhanced_questions.json", help="Output file for generated questions")
    argparser.add_argument("--batch_size", type=int, default=5, help="Batch size for generation")
    argparser.add_argument("--enable_curriculum", action="store_true", help="Enable curriculum learning")
    argparser.add_argument("--enable_validation", action="store_true", help="Enable quality validation")
    argparser.add_argument("--difficulty", type=str, choices=['easy', 'medium', 'hard', 'expert'], default='medium', help="Fixed difficulty level")
    argparser.add_argument("--verbose", action="store_true", help="Enable verbose output")
    args = argparser.parse_args()
    
    # Load configuration
    try:
        inc_samples = EnhancedQuestioningAgent.load_icl_samples("assets/topics_example.json")
    except FileNotFoundError:
        logger.warning("ICL samples not found, proceeding without examples")
        inc_samples = {}
    
    try:
        with open("assets/topics.json") as f:
            topics = json.load(f)
    except FileNotFoundError:
        logger.warning("Topics file not found, using default topics")
        topics = {
            "Logical Reasoning": [
                "Truth-teller and Liar Problems",
                "Seating Arrangements", 
                "Blood Relations"
            ]
        }
    
    # Initialize enhanced agent
    agent = EnhancedQuestioningAgent(
        enable_curriculum_learning=args.enable_curriculum,
        enable_quality_validation=args.enable_validation,
        enable_adaptive_generation=True
    )
    
    # Load generation parameters
    gen_kwargs = {"tgps_show": True}
    try:
        with open("qgen.yaml", "r") as f:
            gen_kwargs.update(yaml.safe_load(f))
    except FileNotFoundError:
        logger.warning("qgen.yaml not found, using default parameters")
    
    # Override difficulty if not using curriculum
    if not args.enable_curriculum:
        gen_kwargs['difficulty'] = args.difficulty
    
    print("=== Enhanced Question Generation ===")
    print(f"Questions to generate: {args.num_questions}")
    print(f"Curriculum learning: {args.enable_curriculum}")
    print(f"Quality validation: {args.enable_validation}")
    print(f"Batch size: {args.batch_size}")
    print("=" * 50)
    
    # Generate questions
    start_time = time.time()
    
    questions, tls, gts = agent.generate_batches(
        num_questions=args.num_questions,
        topics=topics,
        batch_size=args.batch_size,
        wadvsys=True,
        wicl=True,
        inc_samples=inc_samples,
        **gen_kwargs
    )
    
    total_time = time.time() - start_time
    
    print(f"\nGenerated {len(questions)} questions in {total_time:.2f} seconds!")
    
    # Display sample questions if verbose
    if args.verbose:
        print("\n=== Sample Generated Questions ===")
        for i, q in enumerate(questions[:3]):
            print(f"\nQuestion {i+1}:")
            print(q)
        print("\n" + "=" * 50)
    
    # Show generation metrics
    metrics = agent.get_generation_metrics()
    print("\n=== Generation Metrics ===")
    for key, value in metrics.items():
        if isinstance(value, float):
            print(f"{key}: {value:.3f}")
        else:
            print(f"{key}: {value}")
    
    # Performance statistics
    if gen_kwargs.get("tgps_show", False) and tls and gts:
        total_tokens = sum(tl for tl in tls if tl)
        total_gen_time = sum(gt for gt in gts if gt)
        if total_gen_time > 0:
            print(f"\nGeneration Performance:")
            print(f"Total tokens: {total_tokens}")
            print(f"Total generation time: {total_gen_time:.3f}s")
            print(f"Tokens per second: {total_tokens/total_gen_time:.3f}")
    
    # Process and save questions
    print("\n=== Processing Questions ===")
    
    # Convert string responses to JSON
    processed_questions = []
    for q in questions:
        if isinstance(q, str):
            try:
                q_dict = json.loads(q)
                processed_questions.append(q_dict)
            except json.JSONDecodeError:
                # Attempt JSON repair
                try:
                    prompt = (
                        'Extract and fix the JSON from this text, ensuring perfect format:\n\n'
                        f'{q}\n\n'
                        'Return only valid JSON with fields: topic, question, choices, answer, explanation'
                    )
                    fixed_q, _, _ = agent.agent.generate_response(
                        prompt, 
                        "You are a JSON repair expert.",
                        max_new_tokens=1024,
                        temperature=0.0,
                        do_sample=False
                    )
                    q_dict = json.loads(fixed_q)
                    processed_questions.append(q_dict)
                except:
                    logger.warning(f"Could not parse question: {q[:100]}...")
        else:
            processed_questions.append(q)
    
    # Filter questions
    filtered_questions = agent.filter_questions(processed_questions)
    
    print(f"Processed: {len(processed_questions)} questions")
    print(f"Filtered: {len(filtered_questions)} valid questions")
    print(f"Success rate: {len(filtered_questions)/len(questions)*100:.1f}%")
    
    # Save results
    agent.save_questions(processed_questions, args.output_file)
    
    filtered_file = args.output_file.replace(".json", "_filtered.json")
    agent.save_questions(filtered_questions, filtered_file)
    
    print(f"\nSaved results:")
    print(f"All questions: {args.output_file}")
    print(f"Filtered questions: {filtered_file}")
    
    print("\n=== Enhanced Question Generation Complete ===")
    print("Advanced features used:")
    print("- Curriculum learning progression" if args.enable_curriculum else "- Fixed difficulty generation")
    print("- Quality validation and filtering" if args.enable_validation else "- Basic validation")
    print("- Performance monitoring and metrics")
    print("- Synthetic data generation capabilities")
    print("- Backward compatibility maintained")

