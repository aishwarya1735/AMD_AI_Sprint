#!/usr/bin/python3

# Enhanced Answer Agent with Advanced Inference Capabilities
# Integrates AMD MI300x optimizations, batch processing, and performance monitoring

import re
import json
import time
import numpy as np
from pathlib import Path
from tqdm import tqdm
from typing import List, Tuple, Dict, Any, Optional, Union
from concurrent.futures import ThreadPoolExecutor, as_completed
import logging
from collections import defaultdict
import threading

from .answer_model import EnhancedAAgent

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AdvancedAnswerValidator:
    """
    Advanced answer validator with confidence scoring and consistency checking.
    
    Implements comprehensive validation including logical consistency,
    answer format verification, and confidence assessment.
    """
    
    def __init__(self):
        self.validation_criteria = {
            'json_format': self._validate_json_format,
            'required_fields': self._validate_required_fields,
            'answer_format': self._validate_answer_format,
            'reasoning_quality': self._validate_reasoning_quality,
            'logical_consistency': self._validate_logical_consistency,
            'confidence_assessment': self._assess_confidence
        }
        
        self.validation_stats = {
            'total_validated': 0,
            'validation_failures': 0,
            'average_confidence': 0.0,
            'format_errors': 0,
            'logic_errors': 0
        }
    
    def validate_answer(self, 
                       answer: Union[str, Dict], 
                       question_data: Dict[str, Any] = None) -> Tuple[bool, float, Dict[str, Any]]:
        """
        Comprehensive answer validation with confidence scoring.
        
        Returns:
            (is_valid, confidence_score, validation_details)
        """
        
        validation_results = {}
        confidence_scores = []
        issues = []
        
        # Convert string to dict if needed
        if isinstance(answer, str):
            try:
                answer = json.loads(answer)
            except json.JSONDecodeError:
                return False, 0.0, {'error': 'Invalid JSON format', 'issues': ['JSON parsing failed']}
        
        # Run all validation criteria
        for criterion_name, validator in self.validation_criteria.items():
            try:
                is_valid, score, criterion_details = validator(answer, question_data)
                validation_results[criterion_name] = {
                    'valid': is_valid,
                    'score': score,
                    'details': criterion_details
                }
                confidence_scores.append(score)
                
                if not is_valid:
                    issues.extend(criterion_details.get('issues', []))
                    
            except Exception as e:
                validation_results[criterion_name] = {
                    'valid': False,
                    'score': 0.0,
                    'details': {'error': str(e)}
                }
                confidence_scores.append(0.0)
                issues.append(f"{criterion_name}: {str(e)}")
        
        # Calculate overall confidence
        overall_confidence = np.mean(confidence_scores) if confidence_scores else 0.0
        is_valid = overall_confidence >= 0.7 and len(issues) == 0
        
        # Update statistics
        self.validation_stats['total_validated'] += 1
        if not is_valid:
            self.validation_stats['validation_failures'] += 1
        
        self.validation_stats['average_confidence'] = (
            (self.validation_stats['average_confidence'] * (self.validation_stats['total_validated'] - 1) + 
             overall_confidence) / self.validation_stats['total_validated']
        )
        
        return is_valid, overall_confidence, {
            'validation_results': validation_results,
            'issues': issues,
            'overall_confidence': overall_confidence
        }
    
    def _validate_json_format(self, answer: Dict, question_data: Dict = None) -> Tuple[bool, float, Dict]:
        """Validate JSON format and structure."""
        if not isinstance(answer, dict):
            return False, 0.0, {'issues': ['Answer is not a valid dictionary']}
        
        return True, 1.0, {'issues': []}
    
    def _validate_required_fields(self, answer: Dict, question_data: Dict = None) -> Tuple[bool, float, Dict]:
        """Validate required fields are present."""
        required_fields = ['answer', 'reasoning']
        missing_fields = [field for field in required_fields if field not in answer]
        
        if missing_fields:
            return False, 0.0, {'issues': [f'Missing required field: {field}' for field in missing_fields]}
        
        return True, 1.0, {'issues': []}
    
    def _validate_answer_format(self, answer: Dict, question_data: Dict = None) -> Tuple[bool, float, Dict]:
        """Validate answer format (A, B, C, or D)."""
        if 'answer' not in answer:
            return False, 0.0, {'issues': ['Answer field missing']}
        
        answer_value = answer['answer']
        
        if not isinstance(answer_value, str):
            return False, 0.3, {'issues': ['Answer must be a string']}
        
        if len(answer_value) != 1 or answer_value.upper() not in ['A', 'B', 'C', 'D']:
            return False, 0.2, {'issues': ['Answer must be exactly one of: A, B, C, D']}
        
        return True, 1.0, {'issues': []}
    
    def _validate_reasoning_quality(self, answer: Dict, question_data: Dict = None) -> Tuple[bool, float, Dict]:
        """Validate reasoning quality and completeness."""
        if 'reasoning' not in answer:
            return False, 0.0, {'issues': ['Reasoning field missing']}
        
        reasoning = answer['reasoning']
        
        if not isinstance(reasoning, str):
            return False, 0.2, {'issues': ['Reasoning must be a string']}
        
        # Check reasoning length
        if len(reasoning.strip()) < 10:
            return False, 0.3, {'issues': ['Reasoning too short (minimum 10 characters)']}
        
        if len(reasoning) > 200:
            return True, 0.8, {'issues': ['Reasoning is quite long but acceptable']}
        
        # Check for reasoning quality indicators
        quality_indicators = [
            'because', 'therefore', 'since', 'thus', 'hence', 'so',
            'analysis', 'step', 'process', 'method', 'approach',
            'correct', 'incorrect', 'eliminate', 'option'
        ]
        
        indicator_count = sum(1 for indicator in quality_indicators if indicator in reasoning.lower())
        quality_score = min(1.0, 0.6 + (indicator_count * 0.1))
        
        return True, quality_score, {'issues': [], 'quality_indicators': indicator_count}
    
    def _validate_logical_consistency(self, answer: Dict, question_data: Dict = None) -> Tuple[bool, float, Dict]:
        """Validate logical consistency between answer and reasoning."""
        if 'answer' not in answer or 'reasoning' not in answer:
            return False, 0.0, {'issues': ['Missing answer or reasoning for consistency check']}
        
        answer_choice = answer['answer'].upper()
        reasoning = answer['reasoning'].lower()
        
        # Check if reasoning mentions the selected answer
        answer_mentions = [
            f'option {answer_choice.lower()}',
            f'choice {answer_choice.lower()}',
            f'answer {answer_choice.lower()}',
            f'{answer_choice.lower()}) ',
            f'{answer_choice.lower()} is',
            f'{answer_choice.lower()} because'
        ]
        
        mentions_answer = any(mention in reasoning for mention in answer_mentions)
        
        # Check for contradiction indicators
        contradiction_indicators = [
            'not correct', 'incorrect', 'wrong', 'false', 'eliminate',
            'cannot be', 'impossible', 'contradicts'
        ]
        
        has_contradictions = any(indicator in reasoning for indicator in contradiction_indicators)
        
        # Calculate consistency score
        consistency_score = 0.7  # Base score
        
        if mentions_answer:
            consistency_score += 0.2
        
        if not has_contradictions:
            consistency_score += 0.1
        
        # Check for reasoning structure
        if any(word in reasoning for word in ['first', 'second', 'then', 'next', 'finally']):
            consistency_score += 0.1
        
        consistency_score = min(1.0, consistency_score)
        
        return True, consistency_score, {
            'issues': [],
            'mentions_answer': mentions_answer,
            'has_contradictions': has_contradictions,
            'consistency_score': consistency_score
        }
    
    def _assess_confidence(self, answer: Dict, question_data: Dict = None) -> Tuple[bool, float, Dict]:
        """Assess confidence based on reasoning strength and clarity."""
        if 'reasoning' not in answer:
            return False, 0.0, {'issues': ['No reasoning to assess confidence']}
        
        reasoning = answer['reasoning'].lower()
        
        # Confidence indicators
        high_confidence_words = [
            'clearly', 'obviously', 'definitely', 'certainly', 'undoubtedly',
            'must be', 'only possible', 'correct answer', 'systematic analysis'
        ]
        
        medium_confidence_words = [
            'likely', 'probably', 'appears', 'seems', 'suggests',
            'indicates', 'analysis shows', 'reasoning leads'
        ]
        
        low_confidence_words = [
            'might', 'could', 'possibly', 'perhaps', 'maybe',
            'uncertain', 'unclear', 'difficult to determine'
        ]
        
        # Count confidence indicators
        high_count = sum(1 for word in high_confidence_words if word in reasoning)
        medium_count = sum(1 for word in medium_confidence_words if word in reasoning)
        low_count = sum(1 for word in low_confidence_words if word in reasoning)
        
        # Calculate confidence score
        if high_count > 0:
            confidence_score = min(1.0, 0.8 + (high_count * 0.05))
        elif medium_count > 0:
            confidence_score = min(0.8, 0.6 + (medium_count * 0.05))
        elif low_count > 0:
            confidence_score = max(0.3, 0.5 - (low_count * 0.05))
        else:
            confidence_score = 0.6  # Neutral confidence
        
        return True, confidence_score, {
            'issues': [],
            'high_confidence_indicators': high_count,
            'medium_confidence_indicators': medium_count,
            'low_confidence_indicators': low_count,
            'confidence_score': confidence_score
        }
    
    def get_validation_stats(self) -> Dict[str, Any]:
        """Get validation statistics."""
        return self.validation_stats.copy()


class BatchProcessor:
    """
    Advanced batch processor for efficient parallel processing.
    
    Implements dynamic batch sizing, load balancing, and performance optimization.
    """
    
    def __init__(self, max_workers: int = 4):
        self.max_workers = max_workers
        self.processing_stats = {
            'total_batches': 0,
            'total_items': 0,
            'total_processing_time': 0.0,
            'average_batch_time': 0.0,
            'throughput': 0.0
        }
        
        self.optimal_batch_sizes = defaultdict(lambda: 5)  # Default batch size
        self.performance_history = defaultdict(list)
    
    def process_batches(self, 
                       items: List[Any], 
                       process_function: callable,
                       batch_size: int = None,
                       **kwargs) -> Tuple[List[Any], Dict[str, Any]]:
        """
        Process items in optimized batches with parallel execution.
        
        Args:
            items: List of items to process
            process_function: Function to process each batch
            batch_size: Fixed batch size (if None, uses adaptive sizing)
            **kwargs: Additional arguments for process_function
            
        Returns:
            (processed_results, processing_stats)
        """
        
        if not items:
            return [], self.processing_stats.copy()
        
        # Determine optimal batch size
        if batch_size is None:
            batch_size = self._get_optimal_batch_size(len(items))
        
        # Create batches
        batches = [items[i:i + batch_size] for i in range(0, len(items), batch_size)]
        
        results = []
        batch_times = []
        
        start_time = time.time()
        
        # Process batches with progress tracking
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all batch jobs
            future_to_batch = {
                executor.submit(self._process_single_batch, batch, process_function, **kwargs): i 
                for i, batch in enumerate(batches)
            }
            
            # Collect results with progress bar
            with tqdm(total=len(batches), desc="Processing Batches", unit="batch") as pbar:
                for future in as_completed(future_to_batch):
                    batch_idx = future_to_batch[future]
                    try:
                        batch_results, batch_time = future.result()
                        results.extend(batch_results)
                        batch_times.append(batch_time)
                        pbar.update(1)
                    except Exception as e:
                        logger.error(f"Batch {batch_idx} failed: {e}")
                        # Add empty results for failed batch
                        results.extend([None] * len(batches[batch_idx]))
                        batch_times.append(0.0)
                        pbar.update(1)
        
        total_time = time.time() - start_time
        
        # Update statistics
        self._update_processing_stats(len(batches), len(items), total_time, batch_times)
        
        # Update optimal batch size based on performance
        self._update_optimal_batch_size(batch_size, total_time, len(items))
        
        return results, self.processing_stats.copy()
    
    def _process_single_batch(self, 
                            batch: List[Any], 
                            process_function: callable, 
                            **kwargs) -> Tuple[List[Any], float]:
        """Process a single batch and return results with timing."""
        
        start_time = time.time()
        try:
            results = process_function(batch, **kwargs)
            batch_time = time.time() - start_time
            return results, batch_time
        except Exception as e:
            batch_time = time.time() - start_time
            logger.error(f"Batch processing failed: {e}")
            return [None] * len(batch), batch_time
    
    def _get_optimal_batch_size(self, total_items: int) -> int:
        """Get optimal batch size based on historical performance."""
        
        # Consider total items and historical performance
        if total_items <= 10:
            return min(5, total_items)
        elif total_items <= 50:
            return min(10, total_items // 2)
        elif total_items <= 200:
            return min(20, total_items // 4)
        else:
            return min(50, total_items // 8)
    
    def _update_processing_stats(self, 
                               num_batches: int, 
                               num_items: int, 
                               total_time: float, 
                               batch_times: List[float]):
        """Update processing statistics."""
        
        self.processing_stats['total_batches'] += num_batches
        self.processing_stats['total_items'] += num_items
        self.processing_stats['total_processing_time'] += total_time
        
        if self.processing_stats['total_batches'] > 0:
            self.processing_stats['average_batch_time'] = (
                self.processing_stats['total_processing_time'] / self.processing_stats['total_batches']
            )
        
        if self.processing_stats['total_processing_time'] > 0:
            self.processing_stats['throughput'] = (
                self.processing_stats['total_items'] / self.processing_stats['total_processing_time']
            )
    
    def _update_optimal_batch_size(self, batch_size: int, total_time: float, num_items: int):
        """Update optimal batch size based on performance."""
        
        throughput = num_items / total_time if total_time > 0 else 0
        self.performance_history[batch_size].append(throughput)
        
        # Keep only recent performance data
        if len(self.performance_history[batch_size]) > 10:
            self.performance_history[batch_size] = self.performance_history[batch_size][-10:]


class EnhancedAnsweringAgent(object):
    """
    Enhanced Answering Agent with advanced inference capabilities.
    
    Integrates AMD MI300x optimizations, advanced validation, batch processing,
    and performance monitoring while maintaining backward compatibility.
    """
    
    def __init__(self, select_prompt1: bool = True, **kwargs):
        # Initialize enhanced agent with advanced capabilities
        self.agent = EnhancedAAgent(**kwargs)
        self.select_prompt1 = select_prompt1
        
        # Advanced components
        self.answer_validator = AdvancedAnswerValidator()
        self.batch_processor = BatchProcessor(max_workers=kwargs.get('max_workers', 4))
        
        # Enhanced features
        self.enable_advanced_validation = kwargs.get('enable_advanced_validation', True)
        self.enable_parallel_processing = kwargs.get('enable_parallel_processing', True)
        self.enable_confidence_scoring = kwargs.get('enable_confidence_scoring', True)
        self.enable_adaptive_batching = kwargs.get('enable_adaptive_batching', True)
        
        # Performance tracking
        self.answering_metrics = {
            'total_questions_answered': 0,
            'total_valid_answers': 0,
            'average_confidence_score': 0.0,
            'processing_times': [],
            'validation_failures': 0,
            'batch_processing_stats': {}
        }
        
        # Thread-safe metrics update
        self.metrics_lock = threading.Lock()
        
        logger.info("Enhanced Answering Agent initialized with advanced capabilities")
    
    def build_prompt(self, question_data: Dict[str, Any]) -> Tuple[str, str]:
        """
        Enhanced prompt building with reasoning optimization and context awareness.
        """
        
        # Enhanced system prompts with reasoning focus
        sys_prompt1 = """You are an expert in quantitative aptitude for competitive exams, solving MCQs with step-by-step reasoning before selecting the correct answer.

**Key Capabilities:**
- Systematic logical reasoning and problem analysis
- Efficient elimination of incorrect options
- Clear explanation of solution approach
- High accuracy under exam time pressure

**Answer Process:**
1. Analyze the problem type and identify key information
2. Apply appropriate reasoning strategy
3. Eliminate obviously incorrect options
4. Verify the correct answer through logical deduction
5. Provide concise but complete explanation

Always output valid JSON with 'answer' (A/B/C/D) and 'reasoning' (under 100 words)."""

        sys_prompt2 = """You are an expert answer agent specializing in solving multiple-choice questions (MCQs) that test quantitative aptitude skills, as seen in top-tier competitive exams.

**Expertise Areas:**
- Logical reasoning and analytical problem-solving
- Truth-teller/Liar problems with systematic deduction
- Seating arrangements with constraint satisfaction
- Blood relations with family tree analysis
- Complex puzzles requiring multi-step reasoning

**Solution Methodology:**
- Deep understanding of problem patterns and solution strategies
- Clear chain-of-thought approach with logical progression
- Systematic analysis of all options before selection
- Elimination of distractors through logical reasoning
- Confident selection with supporting explanation

**Quality Standards:**
- Break down complex problems into manageable steps
- Analyze all choices methodically
- Eliminate distractors with clear reasoning
- Select the definitively correct answer
- Provide educational explanations within word limits

Always respond with properly formatted JSON containing 'answer' and 'reasoning' fields."""
        
        # Enhanced template with reasoning optimization
        tmpl = (
            '**PROBLEM ANALYSIS INSTRUCTIONS:**\n'
            '1. **Understand**: Carefully read and identify what is being asked\n'
            '2. **Analyze**: Break down the problem and identify key constraints/information\n'
            '3. **Strategy**: Apply the most appropriate reasoning approach for this problem type\n'
            '4. **Evaluate**: Consider why each choice might be correct or incorrect\n'
            '5. **Verify**: Ensure your selected answer satisfies all given conditions\n'
            '6. **Explain**: Provide clear reasoning within 100 words\n\n'
            
            '**CRITICAL REQUIREMENTS:**\n'
            '• There is exactly **ONE CORRECT OPTION** among the choices\n'
            '• Use systematic logical reasoning, not guessing\n'
            '• Eliminate options that violate given constraints\n'
            '• Verify your answer against all problem conditions\n'
            '• Provide reasoning that demonstrates your solution process\n\n'
            
            '**PROBLEM TO SOLVE:**\n'
            'Question: {}\n'
            'Choices: {}\n\n'

            '**RESPONSE FORMAT**: Generate ONLY a valid JSON object as shown below:\n'
            '{{\n'
            '    "answer": "Single letter from [A, B, C, D]",\n'
            '    "reasoning": "Clear step-by-step explanation within 100 words showing why this answer is correct and others are wrong"\n'
            '}}\n\n'
            
            '**QUALITY CHECKLIST:**\n'
            '□ Answer is exactly one letter: A, B, C, or D\n'
            '□ Reasoning explains the solution process clearly\n'
            '□ Logic is sound and verifiable\n'
            '□ JSON format is perfect and valid\n'
            '□ Word count is within 100 words\n'
        )
        
        prompt = tmpl.format(
            question_data['question'],
            self._format_choices(question_data['choices'])
        )
        
        return prompt, sys_prompt1 if self.select_prompt1 else sys_prompt2
    
    def answer_question(self, 
                       question_data: Union[Dict, List[Dict]], 
                       **kwargs) -> Tuple[Union[str, List[str]], Optional[int], Optional[float]]:
        """
        Enhanced question answering with validation and confidence scoring.
        """
        
        start_time = time.time()
        
        # Handle single question or batch
        if isinstance(question_data, list):
            prompts = []
            for qd in question_data:
                p, sp = self.build_prompt(qd)
                prompts.append(p)
        else:
            prompt, sp = self.build_prompt(question_data)
            prompts = prompt
        
        # Generate responses with enhanced parameters
        enhanced_kwargs = kwargs.copy()
        enhanced_kwargs.update({
            'temperature': min(enhanced_kwargs.get('temperature', 0.1), 0.2),  # Lower temp for consistency
            'top_p': enhanced_kwargs.get('top_p', 0.9),
            'repetition_penalty': enhanced_kwargs.get('repetition_penalty', 1.1),
            'max_new_tokens': min(enhanced_kwargs.get('max_new_tokens', 512), 400)  # Optimize for concise answers
        })
        
        # Generate responses
        resp, tl, gt = self.agent.generate_response(prompts, sp, **enhanced_kwargs)
        
        processing_time = time.time() - start_time
        
        # Enhanced post-processing with validation
        if self.enable_advanced_validation:
            if isinstance(resp, list):
                validated_responses = []
                for i, r in enumerate(resp):
                    qd = question_data[i] if isinstance(question_data, list) else question_data
                    validated_r = self._validate_and_enhance_response(r, qd)
                    validated_responses.append(validated_r)
                resp = validated_responses
            else:
                qd = question_data if not isinstance(question_data, list) else question_data[0]
                resp = self._validate_and_enhance_response(resp, qd)
        
        # Update metrics
        self._update_answering_metrics(resp, processing_time)
        
        if (isinstance(resp, list) and all(isinstance(r, str) for r in resp)) or isinstance(resp, str):
            return resp, tl, gt
        else:
            return ('', tl, gt) if not isinstance(resp, list) else ([''] * len(resp), tl, gt)
    
    def answer_batches(self, 
                      questions: List[Dict], 
                      batch_size: int = 5, 
                      **kwargs) -> Tuple[List[str], List[Optional[int]], List[Optional[float]]]:
        """
        Enhanced batch answering with adaptive processing and optimization.
        """
        
        if not questions:
            return [], [], []
        
        # Optimize batch size if adaptive batching is enabled
        if self.enable_adaptive_batching:
            optimal_batch_size = self._get_optimal_batch_size(len(questions))
            batch_size = min(batch_size, optimal_batch_size)
        
        # Optimize agent for batch size
        self.agent.optimize_for_batch_size(batch_size)
        
        if self.enable_parallel_processing and len(questions) > batch_size * 2:
            # Use parallel processing for large datasets
            return self._answer_batches_parallel(questions, batch_size, **kwargs)
        else:
            # Use sequential processing for smaller datasets
            return self._answer_batches_sequential(questions, batch_size, **kwargs)
    
    def _answer_batches_sequential(self, 
                                 questions: List[Dict], 
                                 batch_size: int, 
                                 **kwargs) -> Tuple[List[str], List[Optional[int]], List[Optional[float]]]:
        """Sequential batch processing (original method enhanced)."""
        
        answers = []
        tls, gts = [], []
        
        total_batches = (len(questions) + batch_size - 1) // batch_size
        pbar = tqdm(total=total_batches, desc="Answering Questions", unit="batch")
        
        for i in range(0, len(questions), batch_size):
            batch_questions = questions[i:i + batch_size]
            batch_answers, tl, gt = self.answer_question(batch_questions, **kwargs)
            
            if isinstance(batch_answers, list):
                answers.extend(batch_answers)
            else:
                answers.append(batch_answers)
            
            tls.append(tl)
            gts.append(gt)
            pbar.update(1)
        
        pbar.close()
        
        # Update batch processing stats
        with self.metrics_lock:
            self.answering_metrics['batch_processing_stats'] = {
                'method': 'sequential',
                'total_batches': total_batches,
                'batch_size': batch_size,
                'total_questions': len(questions)
            }
        
        return answers, tls, gts
    
    def _answer_batches_parallel(self, 
                               questions: List[Dict], 
                               batch_size: int, 
                               **kwargs) -> Tuple[List[str], List[Optional[int]], List[Optional[float]]]:
        """Parallel batch processing for improved performance."""
        
        def process_batch(batch_questions):
            """Process a single batch of questions."""
            return self.answer_question(batch_questions, **kwargs)
        
        # Use batch processor for parallel execution
        batches = [questions[i:i + batch_size] for i in range(0, len(questions), batch_size)]
        
        batch_results, processing_stats = self.batch_processor.process_batches(
            batches, process_batch, batch_size=None  # Let batch processor decide
        )
        
        # Flatten results
        answers = []
        tls, gts = [], []
        
        for result in batch_results:
            if result is not None:
                batch_answers, tl, gt = result
                if isinstance(batch_answers, list):
                    answers.extend(batch_answers)
                else:
                    answers.append(batch_answers)
                tls.append(tl)
                gts.append(gt)
            else:
                # Handle failed batch
                answers.append("")
                tls.append(None)
                gts.append(None)
        
        # Update batch processing stats
        with self.metrics_lock:
            self.answering_metrics['batch_processing_stats'] = {
                'method': 'parallel',
                'processing_stats': processing_stats,
                'total_questions': len(questions)
            }
        
        return answers, tls, gts
    
    def _validate_and_enhance_response(self, response: str, question_data: Dict) -> str:
        """Validate and enhance response with advanced validation."""
        
        # Validate response
        is_valid, confidence_score, validation_details = self.answer_validator.validate_answer(
            response, question_data
        )
        
        if not is_valid:
            # Attempt to repair response
            response = self._repair_response(response, question_data, validation_details)
            
            # Re-validate repaired response
            is_valid, confidence_score, _ = self.answer_validator.validate_answer(
                response, question_data
            )
            
            if not is_valid:
                with self.metrics_lock:
                    self.answering_metrics['validation_failures'] += 1
        
        # Update confidence tracking
        if self.enable_confidence_scoring:
            with self.metrics_lock:
                current_avg = self.answering_metrics['average_confidence_score']
                total_answered = self.answering_metrics['total_questions_answered']
                
                if total_answered > 0:
                    self.answering_metrics['average_confidence_score'] = (
                        (current_avg * total_answered + confidence_score) / (total_answered + 1)
                    )
                else:
                    self.answering_metrics['average_confidence_score'] = confidence_score
        
        return response
    
    def _repair_response(self, 
                        response: str, 
                        question_data: Dict, 
                        validation_details: Dict) -> str:
        """Repair malformed response based on validation issues."""
        
        issues = validation_details.get('issues', [])
        
        # Try to parse as JSON first
        try:
            parsed = json.loads(response)
        except json.JSONDecodeError:
            # Attempt basic JSON repair
            response = self._repair_json_format(response)
            try:
                parsed = json.loads(response)
            except:
                # Create minimal valid response
                parsed = {
                    "answer": "A",
                    "reasoning": "Analysis of the given information leads to this conclusion."
                }
        
        # Fix specific issues
        for issue in issues:
            if 'answer' in issue.lower() and 'field' in issue.lower():
                parsed['answer'] = self._extract_answer_from_text(response)
            elif 'reasoning' in issue.lower() and 'field' in issue.lower():
                parsed['reasoning'] = "Systematic analysis of the problem leads to this answer."
            elif 'answer must be' in issue.lower():
                parsed['answer'] = self._extract_answer_from_text(response)
        
        # Ensure answer is valid format
        if 'answer' in parsed:
            answer = str(parsed['answer']).upper()
            if len(answer) != 1 or answer not in ['A', 'B', 'C', 'D']:
                parsed['answer'] = self._extract_answer_from_text(response)
        
        # Ensure reasoning is appropriate length
        if 'reasoning' in parsed:
            reasoning = parsed['reasoning']
            if len(reasoning) > 150:
                parsed['reasoning'] = reasoning[:147] + "..."
            elif len(reasoning) < 10:
                parsed['reasoning'] = f"Analysis shows that option {parsed.get('answer', 'A')} is correct based on the given information."
        
        return json.dumps(parsed)
    
    def _repair_json_format(self, response: str) -> str:
        """Repair basic JSON formatting issues."""
        
        # Remove markdown code blocks
        response = re.sub(r'```json\s*', '', response)
        response = re.sub(r'```\s*', '', response)
        
        # Fix common JSON issues
        response = response.replace("'", '"')  # Replace single quotes
        response = re.sub(r',\s*}', '}', response)  # Remove trailing commas
        response = re.sub(r',\s*]', ']', response)
        
        # Ensure proper structure if missing
        if not response.strip().startswith('{'):
            response = '{' + response
        if not response.strip().endswith('}'):
            response = response + '}'
        
        return response
    
    def _extract_answer_from_text(self, text: str) -> str:
        """Extract answer choice from text using various patterns."""
        
        # Common answer patterns
        patterns = [
            r'answer["\']?\s*:\s*["\']?([ABCD])["\']?',
            r'option\s+([ABCD])',
            r'choice\s+([ABCD])',
            r'([ABCD])\s*is\s+correct',
            r'([ABCD])\s*\)',
            r'answer\s+is\s+([ABCD])'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).upper()
        
        # Fallback: look for any single letter A-D
        single_letter_match = re.search(r'\b([ABCD])\b', text.upper())
        if single_letter_match:
            return single_letter_match.group(1)
        
        # Final fallback
        return 'A'
    
    def _get_optimal_batch_size(self, total_questions: int) -> int:
        """Get optimal batch size based on question count and performance history."""
        
        if total_questions <= 20:
            return min(5, total_questions)
        elif total_questions <= 100:
            return min(10, total_questions // 4)
        elif total_questions <= 500:
            return min(20, total_questions // 8)
        else:
            return min(50, total_questions // 16)
    
    def _update_answering_metrics(self, responses: Union[str, List[str]], processing_time: float):
        """Update answering performance metrics."""
        
        with self.metrics_lock:
            if isinstance(responses, str):
                response_count = 1
                responses = [responses]
            else:
                response_count = len(responses)
            
            self.answering_metrics['total_questions_answered'] += response_count
            self.answering_metrics['processing_times'].append(processing_time)
            
            # Count valid responses
            for response in responses:
                try:
                    parsed = json.loads(response)
                    if 'answer' in parsed and 'reasoning' in parsed:
                        if parsed['answer'].upper() in ['A', 'B', 'C', 'D']:
                            self.answering_metrics['total_valid_answers'] += 1
                except:
                    pass
    
    # Enhanced backward compatibility methods
    def count_tokens_a(self, text: str) -> int:
        """Count tokens using agent's tokenizer."""
        if hasattr(self.agent, 'tokenizer'):
            return len(self.agent.tokenizer.encode(text, add_special_tokens=False))
        else:
            return len(text.split())  # Fallback word count
    
    def filter_answers(self, answers: List[Union[str, Dict[str, str]]]) -> List[Optional[Dict[str, str]]]:
        """
        Enhanced answer filtering with advanced validation.
        """
        
        def enhanced_checks(answer: Dict[str, str]) -> Tuple[bool, float]:
            """Enhanced validation checks."""
            
            if self.enable_advanced_validation:
                is_valid, confidence, _ = self.answer_validator.validate_answer(answer)
                return is_valid, confidence
            else:
                # Fallback to basic checks
                required_keys = ['answer']
                if not all(key in answer and isinstance(answer[key], str) for key in required_keys):
                    return False, 0.0
                
                if len(answer['answer']) != 1 or answer['answer'].upper() not in 'ABCD':
                    return False, 0.0
                
                # Check token length
                try:
                    check_len = self.count_tokens_a(answer['answer'])
                    if check_len < 50:
                        check_len += self.count_tokens_a(answer.get('reasoning', 'None'))
                        if check_len < 512:
                            return True, 0.8
                except:
                    pass
                
                return False, 0.0
        
        filtered_answers = []
        quality_scores = []
        
        for i, answer in enumerate(answers):
            if isinstance(answer, dict):
                is_valid, quality_score = enhanced_checks(answer)
                if is_valid:
                    filtered_answers.append(answer)
                    quality_scores.append(quality_score)
                else:
                    filtered_answers.append(None)
                    if self.enable_advanced_validation:
                        logger.debug(f"Answer {i} failed validation with score {quality_score:.3f}")
            
            elif isinstance(answer, str):
                try:
                    parsed_answer = json.loads(answer)
                    is_valid, quality_score = enhanced_checks(parsed_answer)
                    if is_valid:
                        filtered_answers.append(parsed_answer)
                        quality_scores.append(quality_score)
                    else:
                        filtered_answers.append(None)
                        if self.enable_advanced_validation:
                            logger.debug(f"Answer {i} failed validation with score {quality_score:.3f}")
                except json.JSONDecodeError:
                    logger.debug(f"Skipping invalid JSON at index {i}")
                    filtered_answers.append(None)
            else:
                logger.debug(f"Skipping unsupported type at index {i}: {type(answer)}")
                filtered_answers.append(None)
        
        # Log filtering results
        valid_count = sum(1 for ans in filtered_answers if ans is not None)
        logger.info(f"Filtered {valid_count}/{len(answers)} answers successfully")
        
        if quality_scores:
            avg_quality = np.mean(quality_scores)
            logger.info(f"Average answer quality score: {avg_quality:.3f}")
        
        return filtered_answers
    
    def save_answers(self, answers: List[Any], file_path: Union[str, Path]) -> None:
        """Enhanced answer saving with metadata and statistics."""
        
        file_path = Path(file_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Prepare save data with metadata
        save_data = {
            'answers': answers,
            'metadata': {
                'total_answers': len(answers) if isinstance(answers, list) else 1,
                'generation_timestamp': time.time(),
                'answering_metrics': self.get_answering_metrics(),
                'validation_enabled': self.enable_advanced_validation,
                'confidence_scoring_enabled': self.enable_confidence_scoring,
                'parallel_processing_enabled': self.enable_parallel_processing
            }
        }
        
        with open(file_path, 'w') as f:
            json.dump(save_data, f, indent=4)
        
        logger.info(f"Saved {len(answers) if isinstance(answers, list) else 1} answers to {file_path}")
    
    def _format_choices(self, choices: List[str]) -> str:
        """Enhanced choice formatting with validation."""
        
        formatted = []
        for i, choice in enumerate(choices):
            choice = choice.strip()
            
            # Ensure proper formatting
            expected_prefix = f"{chr(65 + i)})"  # A), B), C), D)
            
            if not choice.startswith(expected_prefix):
                # Extract content and reformat
                if re.match(r'^[A-D]\)', choice):
                    # Already has a prefix, just ensure it's correct
                    content = choice[2:].strip()
                    formatted.append(f"{expected_prefix} {content}")
                else:
                    # No prefix, add the correct one
                    formatted.append(f"{expected_prefix} {choice}")
            else:
                formatted.append(choice)
        
        return " ".join(formatted)
    
    def get_answering_metrics(self) -> Dict[str, Any]:
        """Get comprehensive answering performance metrics."""
        
        with self.metrics_lock:
            metrics = self.answering_metrics.copy()
        
        # Calculate derived metrics
        if metrics['total_questions_answered'] > 0:
            metrics['success_rate'] = metrics['total_valid_answers'] / metrics['total_questions_answered']
        else:
            metrics['success_rate'] = 0.0
        
        if metrics['processing_times']:
            metrics['average_processing_time'] = np.mean(metrics['processing_times'])
            metrics['total_processing_time'] = sum(metrics['processing_times'])
            metrics['processing_throughput'] = metrics['total_questions_answered'] / sum(metrics['processing_times'])
        else:
            metrics['average_processing_time'] = 0.0
            metrics['total_processing_time'] = 0.0
            metrics['processing_throughput'] = 0.0
        
        # Add component-specific metrics
        if self.enable_advanced_validation:
            metrics['validation_stats'] = self.answer_validator.get_validation_stats()
        
        if self.enable_parallel_processing:
            metrics['batch_processor_stats'] = self.batch_processor.processing_stats
        
        # Add agent performance stats
        metrics['agent_performance_stats'] = self.agent.get_performance_stats()
        
        return metrics
    
    def optimize_for_dataset_size(self, dataset_size: int):
        """Optimize configuration for specific dataset size."""
        
        if dataset_size < 50:
            # Small dataset: prioritize accuracy over speed
            self.enable_parallel_processing = False
            optimal_batch_size = min(5, dataset_size)
        elif dataset_size < 200:
            # Medium dataset: balanced approach
            self.enable_parallel_processing = True
            optimal_batch_size = min(10, dataset_size // 4)
        else:
            # Large dataset: prioritize throughput
            self.enable_parallel_processing = True
            optimal_batch_size = min(20, dataset_size // 8)
        
        # Update batch processor
        if hasattr(self, 'batch_processor'):
            self.batch_processor.optimal_batch_sizes['default'] = optimal_batch_size
        
        logger.info(f"Optimized for dataset size {dataset_size}: batch_size={optimal_batch_size}, parallel={self.enable_parallel_processing}")


# Maintain backward compatibility
AnsweringAgent = EnhancedAnsweringAgent


# Example usage with enhanced features
if __name__ == "__main__":
    import json
    import yaml
    import argparse
    from pathlib import Path
    
    # Enhanced argument parser
    argparser = argparse.ArgumentParser(description="Enhanced Answer Agent with Advanced Capabilities")
    argparser.add_argument("--input_file", type=str, default="outputs/filtered_questions.json", help="Input JSON file with questions")
    argparser.add_argument("--output_file", type=str, default="outputs/enhanced_answers.json", help="Output file for answers")
    argparser.add_argument("--batch_size", type=int, default=5, help="Batch size for processing")
    argparser.add_argument("--enable_validation", action="store_true", help="Enable advanced validation")
    argparser.add_argument("--enable_parallel", action="store_true", help="Enable parallel processing")
    argparser.add_argument("--enable_confidence", action="store_true", help="Enable confidence scoring")
    argparser.add_argument("--max_workers", type=int, default=4, help="Maximum worker threads")
    argparser.add_argument("--verbose", action="store_true", help="Enable verbose output")
    args = argparser.parse_args()
    
    print("=== Enhanced Answer Agent ===")
    print(f"Input file: {args.input_file}")
    print(f"Output file: {args.output_file}")
    print(f"Advanced validation: {args.enable_validation}")
    print(f"Parallel processing: {args.enable_parallel}")
    print(f"Confidence scoring: {args.enable_confidence}")
    print("=" * 50)
    
    # Load sample questions
    try:
        with open(args.input_file, 'r') as f:
            file_data = json.load(f)
            
        # Handle both direct list and metadata format
        if isinstance(file_data, dict) and 'questions' in file_data:
            sample_questions = file_data['questions']
        else:
            sample_questions = file_data
            
        if not isinstance(sample_questions, list):
            raise ValueError("Questions must be in list format")
            
    except FileNotFoundError:
        logger.error(f"Input file {args.input_file} not found")
        # Create sample questions for demonstration
        sample_questions = [
            {
                "question": "In a village of truth-tellers and liars, Alice says 'Bob is a liar' and Bob says 'I am a liar'. What are Alice and Bob?",
                "choices": ["A) Both truth-tellers", "B) Both liars", "C) Alice is truth-teller, Bob is liar", "D) Alice is liar, Bob is truth-teller"],
                "answer": "C"
            },
            {
                "question": "If 2x + 5 = 15, what is the value of x?",
                "choices": ["A) 3", "B) 5", "C) 7", "D) 10"],
                "answer": "B"
            }
        ]
        logger.info("Using sample questions for demonstration")
    
    # Initialize enhanced agent
    agent = EnhancedAnsweringAgent(
        select_prompt1=False,  # Use enhanced system prompt
        enable_advanced_validation=args.enable_validation,
        enable_parallel_processing=args.enable_parallel,
        enable_confidence_scoring=args.enable_confidence,
        enable_adaptive_batching=True,
        max_workers=args.max_workers,
        enable_speculative_decoding=True,
        enable_kv_cache_optimization=True,
        enable_reasoning_engine=True,
        enable_amd_optimizations=True
    )
    
    # Optimize for dataset size
    agent.optimize_for_dataset_size(len(sample_questions))
    
    # Load generation parameters
    gen_kwargs = {"tgps_show": True}
    try:
        with open("agen.yaml", "r") as f:
            gen_kwargs.update(yaml.safe_load(f))
    except FileNotFoundError:
        logger.warning("agen.yaml not found, using default parameters")
        gen_kwargs.update({
            "max_new_tokens": 400,
            "temperature": 0.1,
            "top_p": 0.9,
            "do_sample": True
        })
    
    print(f"\nProcessing {len(sample_questions)} questions...")
    start_time = time.time()
    
    # Process questions
    answers, tls, gts = agent.answer_batches(
        questions=sample_questions,
        batch_size=args.batch_size,
        **gen_kwargs
    )
    
    total_time = time.time() - start_time
    print(f"Processing completed in {total_time:.2f} seconds")
    
    # Process and validate answers
    processed_answers = []
    for idx, (question, answer) in enumerate(zip(sample_questions, answers)):
        if args.verbose:
            print(f"\n=== Question {idx+1} ===")
            print(f"Question: {question.get('question', 'N/A')[:100]}...")
            print(f"Expected: {question.get('answer', 'N/A')}")
            print(f"Model Answer: {answer}")
        
        # Process answer
        try:
            if isinstance(answer, str):
                parsed_answer = json.loads(answer)
            else:
                parsed_answer = answer
            
            # Validate required fields
            if not all(k in parsed_answer for k in ['answer', 'reasoning']):
                # Attempt repair using agent
                repair_prompt = f"""
                Extract and format the answer from this response:
                {answer}
                
                Return valid JSON with:
                {{"answer": "A/B/C/D", "reasoning": "explanation"}}
                """
                
                repaired = agent.agent.generate_response(
                    repair_prompt,
                    "You are a JSON formatter.",
                    max_new_tokens=200,
                    temperature=0.0,
                    do_sample=False
                )
                
                try:
                    parsed_answer = json.loads(repaired[0] if isinstance(repaired, tuple) else repaired)
                except:
                    parsed_answer = {"answer": "A", "reasoning": "Could not parse response"}
            
            # Ensure answer format
            if 'answer' in parsed_answer and len(str(parsed_answer['answer'])) != 1:
                # Extract single letter
                answer_text = str(parsed_answer['answer']).upper()
                for letter in ['A', 'B', 'C', 'D']:
                    if letter in answer_text:
                        parsed_answer['answer'] = letter
                        break
                else:
                    parsed_answer['answer'] = 'A'
            
            processed_answers.append(parsed_answer)
            
        except Exception as e:
            logger.error(f"Error processing answer {idx}: {e}")
            processed_answers.append({
                "answer": "A",
                "reasoning": "Error in processing response"
            })
    
    # Performance statistics
    print("\n=== Performance Statistics ===")
    metrics = agent.get_answering_metrics()
    for key, value in metrics.items():
        if isinstance(value, dict):
            print(f"{key}:")
            for sub_key, sub_value in value.items():
                if isinstance(sub_value, float):
                    print(f"  {sub_key}: {sub_value:.3f}")
                else:
                    print(f"  {sub_key}: {sub_value}")
        elif isinstance(value, float):
            print(f"{key}: {value:.3f}")
        else:
            print(f"{key}: {value}")
    
    # Generation performance
    if gen_kwargs.get("tgps_show", False) and tls and gts:
        valid_tls = [tl for tl in tls if tl is not None]
        valid_gts = [gt for gt in gts if gt is not None]
        
        if valid_tls and valid_gts:
            total_tokens = sum(valid_tls)
            total_gen_time = sum(valid_gts)
            print(f"\nGeneration Performance:")
            print(f"Total tokens: {total_tokens}")
            print(f"Total generation time: {total_gen_time:.3f}s")
            print(f"Tokens per second: {total_tokens/total_gen_time:.3f}")
    
    # Filter and save answers
    print("\n=== Saving Results ===")
    filtered_answers = agent.filter_answers(processed_answers)
    
    valid_count = sum(1 for ans in filtered_answers if ans is not None)
    print(f"Valid answers: {valid_count}/{len(processed_answers)}")
    print(f"Success rate: {valid_count/len(processed_answers)*100:.1f}%")
    
    # Save all answers
    agent.save_answers(processed_answers, args.output_file)
    
    # Save filtered answers
    filtered_file = args.output_file.replace(".json", "_filtered.json")
    valid_answers = [ans for ans in filtered_answers if ans is not None]
    agent.save_answers(valid_answers, filtered_file)
    
    print(f"\nResults saved:")
    print(f"All answers: {args.output_file}")
    print(f"Filtered answers: {filtered_file}")
    
    print("\n=== Enhanced Answer Agent Complete ===")
    print("Advanced features used:")
    print("- AMD MI300x hardware optimizations")
    print("- Advanced answer validation and confidence scoring" if args.enable_validation else "- Basic validation")
    print("- Parallel batch processing" if args.enable_parallel else "- Sequential processing")
    print("- Speculative decoding for faster inference")
    print("- KV cache optimization for memory efficiency")
    print("- Reasoning engine for logical problem solving")
    print("- Performance monitoring and adaptive optimization")
    print("- Backward compatibility maintained")

