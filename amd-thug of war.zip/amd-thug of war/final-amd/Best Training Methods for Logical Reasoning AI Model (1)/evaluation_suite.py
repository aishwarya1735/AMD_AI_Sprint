#!/usr/bin/python3

# Comprehensive Evaluation Suite for Enhanced AAIPL System
# Tests question generation, answer accuracy, and overall system performance

import json
import time
import argparse
import logging
from pathlib import Path
from typing import Dict, List, Any, Tuple, Optional
from collections import defaultdict
import numpy as np
from dataclasses import dataclass
import matplotlib.pyplot as plt
import seaborn as sns

# Import enhanced agents
import sys
sys.path.append(str(Path(__file__).parent.parent))

from agents.question_agent import EnhancedQuestioningAgent
from agents.answer_agent import EnhancedAnsweringAgent

logger = logging.getLogger(__name__)


@dataclass
class EvaluationMetrics:
    """Data class for storing evaluation metrics."""
    accuracy: float
    format_correctness: float
    reasoning_quality: float
    confidence_score: float
    processing_time: float
    throughput: float
    memory_usage: float
    
    def to_dict(self) -> Dict[str, float]:
        return {
            'accuracy': self.accuracy,
            'format_correctness': self.format_correctness,
            'reasoning_quality': self.reasoning_quality,
            'confidence_score': self.confidence_score,
            'processing_time': self.processing_time,
            'throughput': self.throughput,
            'memory_usage': self.memory_usage
        }


class EnhancedEvaluationSuite:
    """
    Comprehensive evaluation suite for the enhanced AAIPL system.
    """
    
    def __init__(self, config_path: Optional[str] = None):
        self.config = self._load_config(config_path)
        self.results = defaultdict(dict)
        self.question_agent = None
        self.answer_agent = None
        
        # Setup logging
        logging.basicConfig(
            level=getattr(logging, self.config.get('log_level', 'INFO')),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """Load evaluation configuration."""
        default_config = {
            'topics': ['truth_teller_liar', 'seating_arrangements', 'blood_relations'],
            'difficulty_levels': ['easy', 'medium', 'hard', 'expert'],
            'sample_sizes': [10, 25, 50, 100],
            'evaluation_metrics': [
                'accuracy', 'format_correctness', 'reasoning_quality',
                'confidence_score', 'processing_time', 'throughput'
            ],
            'output_dir': './evaluation_results',
            'save_detailed_results': True,
            'generate_plots': True,
            'log_level': 'INFO'
        }
        
        if config_path and Path(config_path).exists():
            with open(config_path, 'r') as f:
                user_config = json.load(f)
                default_config.update(user_config)
        
        return default_config
    
    def setup_agents(self, question_config: Dict = None, answer_config: Dict = None):
        """Setup question and answer agents for evaluation."""
        logger.info("Setting up evaluation agents...")
        
        # Setup question agent
        q_config = question_config or {}
        self.question_agent = EnhancedQuestioningAgent(
            enable_synthetic_generation=True,
            enable_curriculum_learning=True,
            enable_quality_validation=True,
            **q_config
        )
        
        # Setup answer agent
        a_config = answer_config or {}
        self.answer_agent = EnhancedAnsweringAgent(
            enable_advanced_validation=True,
            enable_parallel_processing=True,
            enable_confidence_scoring=True,
            enable_amd_optimizations=True,
            **a_config
        )
        
        logger.info("Agents setup completed successfully")
    
    def evaluate_question_generation(self, 
                                   topic: str, 
                                   difficulty: str, 
                                   sample_size: int) -> Dict[str, Any]:
        """Evaluate question generation quality and performance."""
        logger.info(f"Evaluating question generation: {topic}, {difficulty}, {sample_size} samples")
        
        start_time = time.time()
        
        # Generate questions
        questions = self.question_agent.generate_questions_batch(
            topic=topic,
            difficulty=difficulty,
            count=sample_size,
            enable_validation=True
        )
        
        generation_time = time.time() - start_time
        
        # Evaluate generated questions
        quality_scores = []
        format_correct = 0
        difficulty_appropriate = 0
        
        for question in questions:
            if question is not None:
                # Check format correctness
                if self._validate_question_format(question):
                    format_correct += 1
                
                # Assess quality
                quality_score = self._assess_question_quality(question, topic, difficulty)
                quality_scores.append(quality_score)
                
                # Check difficulty appropriateness
                if self._assess_difficulty_appropriateness(question, difficulty):
                    difficulty_appropriate += 1
        
        # Calculate metrics
        valid_questions = len([q for q in questions if q is not None])
        
        metrics = {
            'total_generated': len(questions),
            'valid_questions': valid_questions,
            'format_correctness': format_correct / len(questions) if questions else 0,
            'average_quality': np.mean(quality_scores) if quality_scores else 0,
            'difficulty_appropriateness': difficulty_appropriate / len(questions) if questions else 0,
            'generation_time': generation_time,
            'throughput': len(questions) / generation_time if generation_time > 0 else 0,
            'success_rate': valid_questions / len(questions) if questions else 0
        }
        
        logger.info(f"Question generation evaluation completed: {metrics['success_rate']:.2%} success rate")
        return metrics
    
    def evaluate_answer_generation(self, 
                                 questions: List[Dict], 
                                 topic: str) -> Dict[str, Any]:
        """Evaluate answer generation accuracy and performance."""
        logger.info(f"Evaluating answer generation: {len(questions)} questions")
        
        if not questions:
            return {'error': 'No questions provided for evaluation'}
        
        start_time = time.time()
        
        # Generate answers
        answers, token_lengths, generation_times = self.answer_agent.answer_batches(
            questions=questions,
            batch_size=self.config.get('answer_batch_size', 5)
        )
        
        total_time = time.time() - start_time
        
        # Evaluate answers
        correct_answers = 0
        format_correct = 0
        reasoning_scores = []
        confidence_scores = []
        
        for i, (question, answer) in enumerate(zip(questions, answers)):
            if answer and isinstance(answer, str):
                try:
                    parsed_answer = json.loads(answer)
                    
                    # Check format
                    if self._validate_answer_format(parsed_answer):
                        format_correct += 1
                    
                    # Check correctness
                    if 'answer' in question and parsed_answer.get('answer') == question['answer']:
                        correct_answers += 1
                    
                    # Assess reasoning quality
                    reasoning_score = self._assess_reasoning_quality(
                        parsed_answer.get('reasoning', ''), 
                        question, 
                        topic
                    )
                    reasoning_scores.append(reasoning_score)
                    
                    # Get confidence score if available
                    if hasattr(self.answer_agent, 'get_confidence_score'):
                        confidence = self.answer_agent.get_confidence_score(answer)
                        confidence_scores.append(confidence)
                
                except json.JSONDecodeError:
                    logger.warning(f"Failed to parse answer {i}: {answer[:100]}...")
        
        # Calculate metrics
        metrics = {
            'total_questions': len(questions),
            'accuracy': correct_answers / len(questions) if questions else 0,
            'format_correctness': format_correct / len(questions) if questions else 0,
            'average_reasoning_quality': np.mean(reasoning_scores) if reasoning_scores else 0,
            'average_confidence': np.mean(confidence_scores) if confidence_scores else 0,
            'total_processing_time': total_time,
            'average_processing_time': total_time / len(questions) if questions else 0,
            'throughput': len(questions) / total_time if total_time > 0 else 0
        }
        
        # Add token and generation time statistics if available
        if token_lengths and any(tl is not None for tl in token_lengths):
            valid_token_lengths = [tl for tl in token_lengths if tl is not None]
            metrics['average_tokens'] = np.mean(valid_token_lengths) if valid_token_lengths else 0
        
        if generation_times and any(gt is not None for gt in generation_times):
            valid_gen_times = [gt for gt in generation_times if gt is not None]
            metrics['average_generation_time'] = np.mean(valid_gen_times) if valid_gen_times else 0
            if metrics['average_tokens'] > 0 and metrics['average_generation_time'] > 0:
                metrics['tokens_per_second'] = metrics['average_tokens'] / metrics['average_generation_time']
        
        logger.info(f"Answer generation evaluation completed: {metrics['accuracy']:.2%} accuracy")
        return metrics
    
    def evaluate_end_to_end_performance(self, 
                                      topic: str, 
                                      difficulty: str, 
                                      sample_size: int) -> Dict[str, Any]:
        """Evaluate complete end-to-end system performance."""
        logger.info(f"Running end-to-end evaluation: {topic}, {difficulty}, {sample_size} samples")
        
        total_start_time = time.time()
        
        # Step 1: Generate questions
        logger.info("Step 1: Generating questions...")
        question_metrics = self.evaluate_question_generation(topic, difficulty, sample_size)
        
        # Get generated questions for answer evaluation
        questions = self.question_agent.generate_questions_batch(
            topic=topic,
            difficulty=difficulty,
            count=sample_size,
            enable_validation=True
        )
        
        valid_questions = [q for q in questions if q is not None and self._validate_question_format(q)]
        
        if not valid_questions:
            logger.error("No valid questions generated for end-to-end evaluation")
            return {'error': 'No valid questions generated'}
        
        # Step 2: Generate answers
        logger.info(f"Step 2: Generating answers for {len(valid_questions)} questions...")
        answer_metrics = self.evaluate_answer_generation(valid_questions, topic)
        
        total_time = time.time() - total_start_time
        
        # Combine metrics
        end_to_end_metrics = {
            'topic': topic,
            'difficulty': difficulty,
            'sample_size': sample_size,
            'total_evaluation_time': total_time,
            'question_generation': question_metrics,
            'answer_generation': answer_metrics,
            'overall_success_rate': (
                question_metrics.get('success_rate', 0) * 
                answer_metrics.get('accuracy', 0)
            ),
            'system_throughput': len(valid_questions) / total_time if total_time > 0 else 0
        }
        
        logger.info(f"End-to-end evaluation completed in {total_time:.2f}s")
        return end_to_end_metrics
    
    def run_comprehensive_evaluation(self) -> Dict[str, Any]:
        """Run comprehensive evaluation across all topics, difficulties, and sample sizes."""
        logger.info("Starting comprehensive evaluation...")
        
        comprehensive_results = {
            'evaluation_config': self.config,
            'start_time': time.time(),
            'results': {}
        }
        
        total_evaluations = (
            len(self.config['topics']) * 
            len(self.config['difficulty_levels']) * 
            len(self.config['sample_sizes'])
        )
        
        evaluation_count = 0
        
        for topic in self.config['topics']:
            comprehensive_results['results'][topic] = {}
            
            for difficulty in self.config['difficulty_levels']:
                comprehensive_results['results'][topic][difficulty] = {}
                
                for sample_size in self.config['sample_sizes']:
                    evaluation_count += 1
                    logger.info(f"Evaluation {evaluation_count}/{total_evaluations}: {topic}, {difficulty}, {sample_size}")
                    
                    try:
                        result = self.evaluate_end_to_end_performance(topic, difficulty, sample_size)
                        comprehensive_results['results'][topic][difficulty][sample_size] = result
                        
                    except Exception as e:
                        logger.error(f"Evaluation failed for {topic}, {difficulty}, {sample_size}: {e}")
                        comprehensive_results['results'][topic][difficulty][sample_size] = {
                            'error': str(e),
                            'status': 'failed'
                        }
        
        comprehensive_results['end_time'] = time.time()
        comprehensive_results['total_evaluation_time'] = (
            comprehensive_results['end_time'] - comprehensive_results['start_time']
        )
        
        logger.info(f"Comprehensive evaluation completed in {comprehensive_results['total_evaluation_time']:.2f}s")
        return comprehensive_results
    
    def generate_evaluation_report(self, results: Dict[str, Any]) -> str:
        """Generate comprehensive evaluation report."""
        report_lines = []
        
        report_lines.append("# Enhanced AAIPL System Evaluation Report")
        report_lines.append(f"Generated on: {time.strftime('%Y-%m-%d %H:%M:%S')}")
        report_lines.append(f"Total evaluation time: {results.get('total_evaluation_time', 0):.2f} seconds")
        report_lines.append("")
        
        # Summary statistics
        report_lines.append("## Summary Statistics")
        
        all_accuracies = []
        all_throughputs = []
        all_success_rates = []
        
        for topic, topic_results in results.get('results', {}).items():
            for difficulty, difficulty_results in topic_results.items():
                for sample_size, eval_result in difficulty_results.items():
                    if 'error' not in eval_result:
                        answer_gen = eval_result.get('answer_generation', {})
                        all_accuracies.append(answer_gen.get('accuracy', 0))
                        all_throughputs.append(eval_result.get('system_throughput', 0))
                        all_success_rates.append(eval_result.get('overall_success_rate', 0))
        
        if all_accuracies:
            report_lines.append(f"- Average accuracy: {np.mean(all_accuracies):.2%}")
            report_lines.append(f"- Average system throughput: {np.mean(all_throughputs):.2f} questions/second")
            report_lines.append(f"- Average success rate: {np.mean(all_success_rates):.2%}")
        
        report_lines.append("")
        
        # Detailed results by topic
        for topic in self.config['topics']:
            report_lines.append(f"## {topic.replace('_', ' ').title()} Results")
            
            topic_results = results.get('results', {}).get(topic, {})
            
            for difficulty in self.config['difficulty_levels']:
                difficulty_results = topic_results.get(difficulty, {})
                
                if difficulty_results:
                    report_lines.append(f"### {difficulty.title()} Difficulty")
                    
                    for sample_size in self.config['sample_sizes']:
                        eval_result = difficulty_results.get(sample_size, {})
                        
                        if 'error' not in eval_result:
                            answer_gen = eval_result.get('answer_generation', {})
                            question_gen = eval_result.get('question_generation', {})
                            
                            report_lines.append(f"**Sample Size: {sample_size}**")
                            report_lines.append(f"- Question generation success: {question_gen.get('success_rate', 0):.2%}")
                            report_lines.append(f"- Answer accuracy: {answer_gen.get('accuracy', 0):.2%}")
                            report_lines.append(f"- Format correctness: {answer_gen.get('format_correctness', 0):.2%}")
                            report_lines.append(f"- System throughput: {eval_result.get('system_throughput', 0):.2f} q/s")
                            report_lines.append("")
        
        # Performance analysis
        report_lines.append("## Performance Analysis")
        
        # Add performance insights based on results
        if all_accuracies:
            best_accuracy = max(all_accuracies)
            worst_accuracy = min(all_accuracies)
            report_lines.append(f"- Best accuracy achieved: {best_accuracy:.2%}")
            report_lines.append(f"- Worst accuracy: {worst_accuracy:.2%}")
            report_lines.append(f"- Accuracy variance: {np.var(all_accuracies):.4f}")
        
        if all_throughputs:
            best_throughput = max(all_throughputs)
            report_lines.append(f"- Peak throughput: {best_throughput:.2f} questions/second")
        
        report_lines.append("")
        
        # Recommendations
        report_lines.append("## Recommendations")
        
        if all_accuracies and np.mean(all_accuracies) < 0.8:
            report_lines.append("- Consider additional training or fine-tuning to improve accuracy")
        
        if all_throughputs and np.mean(all_throughputs) < 1.0:
            report_lines.append("- Consider optimizing batch processing for better throughput")
        
        report_lines.append("- Monitor performance across different topics and difficulties")
        report_lines.append("- Consider curriculum learning for improved training efficiency")
        
        return "\n".join(report_lines)
    
    def save_results(self, results: Dict[str, Any], output_dir: str = None):
        """Save evaluation results to files."""
        output_dir = Path(output_dir or self.config['output_dir'])
        output_dir.mkdir(parents=True, exist_ok=True)
        
        timestamp = time.strftime('%Y%m%d_%H%M%S')
        
        # Save raw results
        results_file = output_dir / f"evaluation_results_{timestamp}.json"
        with open(results_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        # Save evaluation report
        report = self.generate_evaluation_report(results)
        report_file = output_dir / f"evaluation_report_{timestamp}.md"
        with open(report_file, 'w') as f:
            f.write(report)
        
        logger.info(f"Results saved to {output_dir}")
        logger.info(f"- Raw results: {results_file}")
        logger.info(f"- Report: {report_file}")
        
        return results_file, report_file
    
    # Helper methods for validation and assessment
    def _validate_question_format(self, question: Dict) -> bool:
        """Validate question format."""
        required_fields = ['question', 'choices', 'answer']
        return all(field in question for field in required_fields)
    
    def _validate_answer_format(self, answer: Dict) -> bool:
        """Validate answer format."""
        required_fields = ['answer', 'reasoning']
        return all(field in answer for field in required_fields)
    
    def _assess_question_quality(self, question: Dict, topic: str, difficulty: str) -> float:
        """Assess question quality (placeholder implementation)."""
        # This would implement actual quality assessment logic
        score = 0.8  # Placeholder
        
        # Basic checks
        if len(question.get('question', '')) > 20:
            score += 0.1
        
        if len(question.get('choices', [])) == 4:
            score += 0.1
        
        return min(1.0, score)
    
    def _assess_difficulty_appropriateness(self, question: Dict, target_difficulty: str) -> bool:
        """Assess if question difficulty matches target (placeholder implementation)."""
        # This would implement actual difficulty assessment logic
        return True  # Placeholder
    
    def _assess_reasoning_quality(self, reasoning: str, question: Dict, topic: str) -> float:
        """Assess reasoning quality (placeholder implementation)."""
        # This would implement actual reasoning quality assessment
        score = 0.7  # Placeholder
        
        # Basic checks
        if len(reasoning) > 20:
            score += 0.1
        
        if any(word in reasoning.lower() for word in ['because', 'therefore', 'since']):
            score += 0.1
        
        return min(1.0, score)


def main():
    """Main function for running evaluations."""
    parser = argparse.ArgumentParser(description="Enhanced AAIPL Evaluation Suite")
    parser.add_argument("--config", type=str, help="Path to evaluation configuration file")
    parser.add_argument("--output_dir", type=str, default="./evaluation_results", help="Output directory")
    parser.add_argument("--topics", nargs="+", default=["truth_teller_liar"], help="Topics to evaluate")
    parser.add_argument("--difficulties", nargs="+", default=["medium"], help="Difficulties to evaluate")
    parser.add_argument("--sample_sizes", nargs="+", type=int, default=[10], help="Sample sizes to test")
    parser.add_argument("--quick_test", action="store_true", help="Run quick test with minimal samples")
    
    args = parser.parse_args()
    
    # Setup evaluation suite
    evaluator = EnhancedEvaluationSuite(args.config)
    
    # Override config with command line arguments
    if args.topics:
        evaluator.config['topics'] = args.topics
    if args.difficulties:
        evaluator.config['difficulty_levels'] = args.difficulties
    if args.sample_sizes:
        evaluator.config['sample_sizes'] = args.sample_sizes
    if args.output_dir:
        evaluator.config['output_dir'] = args.output_dir
    
    # Quick test mode
    if args.quick_test:
        evaluator.config['topics'] = ['truth_teller_liar']
        evaluator.config['difficulty_levels'] = ['easy']
        evaluator.config['sample_sizes'] = [5]
    
    # Setup agents
    evaluator.setup_agents()
    
    # Run evaluation
    logger.info("Starting evaluation...")
    results = evaluator.run_comprehensive_evaluation()
    
    # Save results
    results_file, report_file = evaluator.save_results(results, args.output_dir)
    
    print(f"\nEvaluation completed!")
    print(f"Results saved to: {results_file}")
    print(f"Report saved to: {report_file}")


if __name__ == "__main__":
    main()

